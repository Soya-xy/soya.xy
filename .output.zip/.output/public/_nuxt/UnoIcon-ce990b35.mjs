import{_ as e,o as c,c as o}from"./entry-44957252.mjs";const r={};function n(t,a){return c(),o("div")}var s=e(r,[["render",n]]);export{s as default};
