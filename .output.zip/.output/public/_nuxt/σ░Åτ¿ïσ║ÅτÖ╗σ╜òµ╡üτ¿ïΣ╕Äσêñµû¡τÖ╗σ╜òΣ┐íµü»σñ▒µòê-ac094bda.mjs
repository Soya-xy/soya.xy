import{_ as k,Y as p,z as r,o as f,e as d,w as h,a as n,G as s}from"./entry-44957252.mjs";const m={title:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",date:"2020-10-06 10:56",tags:["\u5C0F\u7A0B\u5E8F"],meta:[{property:"og:title",content:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548"}]},g={setup(u,{expose:t}){const a={title:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",meta:[{property:"og:title",content:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548"}]};p(a),t({frontmatter:{title:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",date:"2020-10-06 10:56",tags:["\u5C0F\u7A0B\u5E8F"],meta:[{property:"og:title",content:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548"}]}});const e={frontmatter:m,head:a,title:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",date:"2020-10-06 10:56",tags:["\u5C0F\u7A0B\u5E8F"],excerpt:void 0,meta:[{property:"og:title",content:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548"}],useHead:p};return Object.defineProperty(e,"__isScriptSetup",{enumerable:!1,value:!0}),e}},y=n("div",{class:"container post-content"},[n("h1",{id:"\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406",tabindex:"-1"},[s("\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406 "),n("a",{class:"anchor before",href:"#\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406","aria-hidden":"true"},[n("svg",{"aria-hidden":"true",focusable:"false",height:"16",version:"1.1",viewBox:"0 0 16 16",width:"16"},[n("path",{"fill-rule":"evenodd",d:"M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"})])])]),n("h2",{id:"\u6D41\u7A0B\u56FE",tabindex:"-1"},[s("\u6D41\u7A0B\u56FE "),n("a",{class:"anchor before",href:"#\u6D41\u7A0B\u56FE","aria-hidden":"true"},[n("svg",{"aria-hidden":"true",focusable:"false",height:"16",version:"1.1",viewBox:"0 0 16 16",width:"16"},[n("path",{"fill-rule":"evenodd",d:"M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"})])])]),n("p",null,"![\u6D41\u7A0B\u56FE.jpg][/post/images/xcx-login.png]"),n("h2",{id:"\u4EE3\u7801\u793A\u4F8B",tabindex:"-1"},[s("\u4EE3\u7801\u793A\u4F8B "),n("a",{class:"anchor before",href:"#\u4EE3\u7801\u793A\u4F8B","aria-hidden":"true"},[n("svg",{"aria-hidden":"true",focusable:"false",height:"16",version:"1.1",viewBox:"0 0 16 16",width:"16"},[n("path",{"fill-rule":"evenodd",d:"M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"})])])]),n("pre",{class:"language-js"},[n("code",{class:"language-js"},[n("span",{class:"token keyword"},"function"),s(),n("span",{class:"token function"},"wxLogin"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token comment"},"// \u8C03\u7528wx.login"),s(`
  wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"login"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token function-variable function"},"success"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
      `),n("span",{class:"token comment"},"// \u83B7\u53D6\u5230code"),s(`
      `),n("span",{class:"token keyword"},"const"),s(),n("span",{class:"token constant"},"CODE"),s(),n("span",{class:"token operator"},"="),s(" res"),n("span",{class:"token punctuation"},"."),s(`code
      wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"showToast"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u6570\u636E\u52A0\u8F7D\u4E2D'"),n("span",{class:"token punctuation"},","),s(`
        `),n("span",{class:"token literal-property property"},"icon"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'loading'"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token comment"},"// \u4F7F\u7528code\u548C\u540E\u7AEF\u6362\u53D6openid\uFF0CsessionKey"),s(`
      `),n("span",{class:"token function"},"request"),n("span",{class:"token punctuation"},"("),s(`
        `),n("span",{class:"token string"},"'\u540E\u7AEF\u63D0\u4F9B\u7684\u63A5\u53E3'"),n("span",{class:"token punctuation"},","),s(`
        `),n("span",{class:"token string"},"'POST'"),n("span",{class:"token punctuation"},","),s(`
        `),n("span",{class:"token punctuation"},"{"),s(`
          `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token constant"},"CODE"),n("span",{class:"token punctuation"},","),s(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
        `),n("span",{class:"token punctuation"},"{"),s(`
          `),n("span",{class:"token string-property property"},"'content-type'"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'application/json'"),n("span",{class:"token punctuation"},","),s(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},")"),s(`
        `),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"then"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
          wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"hideToast"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(`
          `),n("span",{class:"token keyword"},"if"),s(),n("span",{class:"token punctuation"},"("),s("res"),n("span",{class:"token punctuation"},"."),s("data"),n("span",{class:"token punctuation"},"."),s("InfoState "),n("span",{class:"token operator"},"==="),s(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
            `),n("span",{class:"token function"},"getUserInfo"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(`
              `),n("span",{class:"token punctuation"},"."),s(`then
              `),n("span",{class:"token comment"},"// \u6210\u529F\u540E\u7684\u5904\u7406"),s(`
              `),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(`
              `),n("span",{class:"token punctuation"},"."),s(`catch
              `),n("span",{class:"token comment"},"// \u5931\u8D25\u540E\u7684\u5904\u7406"),s(`
              `),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(`
          `),n("span",{class:"token punctuation"},"}"),s(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
        `),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"catch"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"result"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
          `),n("span",{class:"token comment"},"// \u8BF7\u6C42\u5931\u8D25\u91CD\u65B0\u5904\u7406"),s(`
          wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"showModal"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
            `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u63D0\u793A'"),n("span",{class:"token punctuation"},","),s(`
            `),n("span",{class:"token literal-property property"},"content"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u8BF7\u6C42\u5931\u8D25'"),n("span",{class:"token punctuation"},","),s(`
            `),n("span",{class:"token literal-property property"},"confirmText"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u91CD\u65B0\u8BF7\u6C42'"),n("span",{class:"token punctuation"},","),s(`
            `),n("span",{class:"token function"},"success"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
              `),n("span",{class:"token keyword"},"if"),s(),n("span",{class:"token punctuation"},"("),s("res"),n("span",{class:"token punctuation"},"."),s("confirm"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
                `),n("span",{class:"token function"},"request"),n("span",{class:"token punctuation"},"("),s(`
                  `),n("span",{class:"token string"},"'\u540E\u7AEF\u63D0\u4F9B\u7684\u63A5\u53E3'"),n("span",{class:"token punctuation"},","),s(`
                  `),n("span",{class:"token string"},"'POST'"),n("span",{class:"token punctuation"},","),s(`
                  `),n("span",{class:"token punctuation"},"{"),s(`
                    `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token constant"},"CODE"),n("span",{class:"token punctuation"},","),s(`
                  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
                  `),n("span",{class:"token punctuation"},"{"),s(`
                    `),n("span",{class:"token string-property property"},"'content-type'"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'application/json'"),n("span",{class:"token punctuation"},","),s(`
                  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
                `),n("span",{class:"token punctuation"},")"),s(`
              `),n("span",{class:"token punctuation"},"}"),s(`
              `),n("span",{class:"token keyword"},"else"),s(),n("span",{class:"token keyword"},"if"),s(),n("span",{class:"token punctuation"},"("),s("res"),n("span",{class:"token punctuation"},"."),s("cancel"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
                console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'\u7528\u6237\u70B9\u51FB\u53D6\u6D88'"),n("span",{class:"token punctuation"},")"),s(`
              `),n("span",{class:"token punctuation"},"}"),s(`
            `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`

`),n("span",{class:"token comment"},"// \u5224\u65AD\u7528\u6237\u662F\u5426\u6388\u6743"),s(`
`),n("span",{class:"token keyword"},"function"),s(),n("span",{class:"token function"},"getUserInfo"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token keyword"},"new"),s(),n("span",{class:"token class-name"},"Promise"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[s("resolve"),n("span",{class:"token punctuation"},","),s(" reject")]),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
    wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"getUserInfo"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
      `),n("span",{class:"token function"},"success"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token function"},"resolve"),n("span",{class:"token punctuation"},"("),s("res"),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token function"},"fail"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token comment"},"// eslint-disable-next-line prefer-promise-reject-errors"),s(`
        `),n("span",{class:"token function"},"reject"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'\u6211\u8FD8\u6CA1\u6709\u6388\u6743'"),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`

`),n("span",{class:"token comment"},"// \u5C01\u88C5\u8BF7\u6C42"),s(`
`),n("span",{class:"token keyword"},"function"),s(),n("span",{class:"token function"},"request"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[s("url"),n("span",{class:"token punctuation"},","),s(" method"),n("span",{class:"token punctuation"},","),s(" data"),n("span",{class:"token punctuation"},","),s(" header")]),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token keyword"},"new"),s(),n("span",{class:"token class-name"},"Promise"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[s("resolve"),n("span",{class:"token punctuation"},","),s(" reject")]),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
    wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"request"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
      url`),n("span",{class:"token punctuation"},","),s(`
      data`),n("span",{class:"token punctuation"},","),s(`
      header`),n("span",{class:"token punctuation"},","),s(`
      method`),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token literal-property property"},"timeout"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token function-variable function"},"success"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"result"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token function"},"resolve"),n("span",{class:"token punctuation"},"("),s("result"),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token function-variable function"},"fail"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token function"},"reject"),n("span",{class:"token punctuation"},"("),s("res"),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])]),n("h2",{id:"\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",tabindex:"-1"},[s("\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548 "),n("a",{class:"anchor before",href:"#\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548","aria-hidden":"true"},[n("svg",{"aria-hidden":"true",focusable:"false",height:"16",version:"1.1",viewBox:"0 0 16 16",width:"16"},[n("path",{"fill-rule":"evenodd",d:"M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"})])])]),n("pre",{class:"language-js"},[n("code",{class:"language-js"},[n("span",{class:"token comment"},"// \u9A8C\u8BC1\u767B\u5F55\u662F\u5426\u8FC7\u671F"),s(`
`),n("span",{class:"token keyword"},"function"),s(),n("span",{class:"token function"},"checksession"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
  wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"checkSession"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token function"},"success"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'\u767B\u5F55\u672A\u8FC7\u671F'"),n("span",{class:"token punctuation"},")"),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token function"},"fail"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'\u767B\u5F55\u8FC7\u671F'"),n("span",{class:"token punctuation"},")"),s(`
      wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"showModal"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u63D0\u793A'"),n("span",{class:"token punctuation"},","),s(`
        `),n("span",{class:"token literal-property property"},"content"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u4F60\u7684\u767B\u5F55\u4FE1\u606F\u8FC7\u671F\u4E86\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55'"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token comment"},"// \u518D\u6B21\u8C03\u7528wxLogin()"),s(`
      `),n("span",{class:"token function"},"wxLogin"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"then"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token comment"},"// \u767B\u5F55\u6210\u529F\u5B58\u50A8\u7528\u6237\u4FE1\u606F"),s(`
        `),n("span",{class:"token function"},"getUserInfo"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`

`),n("span",{class:"token comment"},"// \u83B7\u53D6\u7528\u6237\u7684\u4FE1\u606F"),s(`
`),n("span",{class:"token keyword"},"function"),s(),n("span",{class:"token function"},"getUserInfo"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
  wx`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"getUserInfo"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token function"},"success"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"res"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),s("res"),n("span",{class:"token punctuation"},"."),s("userInfo"),n("span",{class:"token punctuation"},")"),s(`
      `),n("span",{class:"token function"},"getApp"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),s("globalData"),n("span",{class:"token punctuation"},"."),s("city "),n("span",{class:"token operator"},"="),s(" res"),n("span",{class:"token punctuation"},"."),s("userInfo"),n("span",{class:"token punctuation"},"."),s(`city
      `),n("span",{class:"token function"},"getApp"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),s("globalData"),n("span",{class:"token punctuation"},"."),s("country "),n("span",{class:"token operator"},"="),s(" res"),n("span",{class:"token punctuation"},"."),s("userInfo"),n("span",{class:"token punctuation"},"."),s(`country
      `),n("span",{class:"token function"},"getApp"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),s("globalData"),n("span",{class:"token punctuation"},"."),s("nickName "),n("span",{class:"token operator"},"="),s(" res"),n("span",{class:"token punctuation"},"."),s("userInfo"),n("span",{class:"token punctuation"},"."),s(`nickName
      `),n("span",{class:"token function"},"getApp"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),s("globalData"),n("span",{class:"token punctuation"},"."),s("province "),n("span",{class:"token operator"},"="),s(" res"),n("span",{class:"token punctuation"},"."),s("userInfo"),n("span",{class:"token punctuation"},"."),s(`province
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])])],-1);function w(u,t,a,o,l,i){const c=r("post");return f(),d(c,{frontmatter:o.frontmatter},{default:h(()=>[y]),_:1})}var x=k(g,[["render",w]]);export{x as default,m as frontmatter};
