const client_manifest = {
  "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-44957252.mjs",
    "src": "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "components/Footer.vue",
      "components/Header.vue",
      "components/Introduce.vue",
      "components/Post.vue",
      "components/Posts.vue",
      "components/Search.vue",
      "components/ToggleTheme.vue",
      "node_modules/.pnpm/@unocss+nuxt@0.33.4/node_modules/@unocss/nuxt/runtime/UnoIcon.vue",
      "pages/404.vue",
      "pages/about.md",
      "pages/articles.vue",
      "pages/index.vue",
      "pages/posts/JavaScript-监听截图.md",
      "pages/posts/New-Blog.md",
      "pages/posts/Vue-Class的显示.md",
      "pages/posts/px自动转换成rem.md",
      "pages/posts/test.md",
      "pages/posts/小程序登录流程与判断登录信息失效.md",
      "pages/projects.vue",
      "layouts/README.md",
      "layouts/default.vue"
    ],
    "css": [
      "entry.ab6b0efa.css"
    ]
  },
  "components/Footer.vue": {
    "file": "Footer-022a218e.mjs",
    "src": "components/Footer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "components/Header.vue": {
    "file": "Header-e6136707.mjs",
    "src": "components/Header.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "components/ToggleTheme.vue"
    ]
  },
  "components/ToggleTheme.vue": {
    "file": "ToggleTheme-0058d7b3.mjs",
    "src": "components/ToggleTheme.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "components/Introduce.vue": {
    "file": "Introduce-26ea1d33.mjs",
    "src": "components/Introduce.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "components/Posts.vue",
      "_fetch-66960b4e.mjs",
      "_index-11903976.mjs",
      "_date-42f38aba.mjs"
    ]
  },
  "components/Posts.vue": {
    "file": "Posts-36de7baf.mjs",
    "src": "components/Posts.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "_date-42f38aba.mjs",
      "_index-11903976.mjs"
    ]
  },
  "_fetch-66960b4e.mjs": {
    "file": "fetch-66960b4e.mjs",
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_index-11903976.mjs": {
    "file": "index-11903976.mjs",
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_date-42f38aba.mjs": {
    "file": "date-42f38aba.mjs",
    "imports": [
      "_index-11903976.mjs"
    ]
  },
  "components/Post.vue": {
    "file": "Post-ba8620d1.mjs",
    "src": "components/Post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "_date-42f38aba.mjs",
      "_index-11903976.mjs"
    ]
  },
  "components/Search.vue": {
    "file": "Search-fde8b616.mjs",
    "src": "components/Search.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/.pnpm/@unocss+nuxt@0.33.4/node_modules/@unocss/nuxt/runtime/UnoIcon.vue": {
    "file": "UnoIcon-ce990b35.mjs",
    "src": "node_modules/.pnpm/@unocss+nuxt@0.33.4/node_modules/@unocss/nuxt/runtime/UnoIcon.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/404.vue": {
    "file": "404-f937806d.mjs",
    "src": "pages/404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/about.md": {
    "file": "about-d793e699.mjs",
    "src": "pages/about.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/articles.vue": {
    "file": "articles-3d53325a.mjs",
    "src": "pages/articles.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "components/Search.vue",
      "components/Posts.vue",
      "_date-42f38aba.mjs",
      "_index-11903976.mjs"
    ]
  },
  "pages/index.vue": {
    "file": "index-15be988b.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "components/Introduce.vue",
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "components/Posts.vue",
      "_date-42f38aba.mjs",
      "_index-11903976.mjs",
      "_fetch-66960b4e.mjs"
    ]
  },
  "pages/posts/JavaScript-监听截图.md": {
    "file": "JavaScript-监听截图-b55bc302.mjs",
    "src": "pages/posts/JavaScript-监听截图.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/New-Blog.md": {
    "file": "New-Blog-a5bb647a.mjs",
    "src": "pages/posts/New-Blog.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/Vue-Class的显示.md": {
    "file": "Vue-Class的显示-662485b8.mjs",
    "src": "pages/posts/Vue-Class的显示.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/px自动转换成rem.md": {
    "file": "px自动转换成rem-56dad86f.mjs",
    "src": "pages/posts/px自动转换成rem.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/test.md": {
    "file": "test-73476286.mjs",
    "src": "pages/posts/test.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/小程序登录流程与判断登录信息失效.md": {
    "file": "小程序登录流程与判断登录信息失效-ac094bda.mjs",
    "src": "pages/posts/小程序登录流程与判断登录信息失效.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/projects.vue": {
    "file": "projects-9c9b7cca.mjs",
    "src": "pages/projects.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "_fetch-66960b4e.mjs"
    ]
  },
  "layouts/README.md": {
    "file": "README-8a710be8.mjs",
    "src": "layouts/README.md",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "layouts/default.vue": {
    "file": "default-325a9743.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "components/Header.vue",
      "components/Footer.vue",
      "node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/entry.mjs",
      "_index-11903976.mjs",
      "components/ToggleTheme.vue"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
