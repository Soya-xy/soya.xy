import { v as vue_cjs_prod, s as serverRenderer, r as require$$0 } from '../handlers/renderer.mjs';
import { hasProtocol, joinURL, isEqual, withBase, withQuery } from 'ufo';
import Fuse from 'fuse.js';
import { u as useRuntimeConfig$1 } from '../nitro/node-server.mjs';
import 'h3';
import 'unenv/runtime/mock/proxy';
import 'stream';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'ohmyfetch';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
const suspectProtoRx = /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^["{[]|^-?[0-9][0-9.]{0,14}$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor") {
    return;
  }
  return value;
}
function destr(val) {
  if (typeof val !== "string") {
    return val;
  }
  const _lval = val.toLowerCase();
  if (_lval === "true") {
    return true;
  }
  if (_lval === "false") {
    return false;
  }
  if (_lval === "null") {
    return null;
  }
  if (_lval === "nan") {
    return NaN;
  }
  if (_lval === "infinity") {
    return Infinity;
  }
  if (_lval === "undefined") {
    return void 0;
  }
  if (!JsonSigRx.test(val)) {
    return val;
  }
  try {
    if (suspectProtoRx.test(val) || suspectConstructorRx.test(val)) {
      return JSON.parse(val, jsonParseTransform);
    }
    return JSON.parse(val);
  } catch (_e) {
    return val;
  }
}
class FetchError extends Error {
  constructor() {
    super(...arguments);
    this.name = "FetchError";
  }
}
function createFetchError(request, error, response) {
  let message = "";
  if (request && response) {
    message = `${response.status} ${response.statusText} (${request.toString()})`;
  }
  if (error) {
    message = `${error.message} (${message})`;
  }
  const fetchError = new FetchError(message);
  Object.defineProperty(fetchError, "request", { get() {
    return request;
  } });
  Object.defineProperty(fetchError, "response", { get() {
    return response;
  } });
  Object.defineProperty(fetchError, "data", { get() {
    return response && response._data;
  } });
  return fetchError;
}
const payloadMethods = new Set(Object.freeze(["PATCH", "POST", "PUT", "DELETE"]));
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(val) {
  if (val === void 0) {
    return false;
  }
  const t = typeof val;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(val)) {
    return true;
  }
  return val.constructor && val.constructor.name === "Object" || typeof val.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*`\-.^~]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift();
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  409,
  425,
  429,
  500,
  502,
  503,
  504
]);
function createFetch(globalOptions) {
  const { fetch: fetch2, Headers: Headers2 } = globalOptions;
  function onError(ctx) {
    if (ctx.options.retry !== false) {
      const retries = typeof ctx.options.retry === "number" ? ctx.options.retry : isPayloadMethod(ctx.options.method) ? 0 : 1;
      const responseCode = ctx.response && ctx.response.status || 500;
      if (retries > 0 && retryStatusCodes.has(responseCode)) {
        return $fetchRaw(ctx.request, __spreadProps(__spreadValues({}, ctx.options), {
          retry: retries - 1
        }));
      }
    }
    const err = createFetchError(ctx.request, ctx.error, ctx.response);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(err, $fetchRaw);
    }
    throw err;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _opts = {}) {
    const ctx = {
      request: _request,
      options: __spreadValues(__spreadValues({}, globalOptions.defaults), _opts),
      response: void 0,
      error: void 0
    };
    if (ctx.options.onRequest) {
      await ctx.options.onRequest(ctx);
    }
    if (typeof ctx.request === "string") {
      if (ctx.options.baseURL) {
        ctx.request = withBase(ctx.request, ctx.options.baseURL);
      }
      if (ctx.options.params) {
        ctx.request = withQuery(ctx.request, ctx.options.params);
      }
      if (ctx.options.body && isPayloadMethod(ctx.options.method)) {
        if (isJSONSerializable(ctx.options.body)) {
          ctx.options.body = JSON.stringify(ctx.options.body);
          ctx.options.headers = new Headers2(ctx.options.headers);
          if (!ctx.options.headers.has("content-type")) {
            ctx.options.headers.set("content-type", "application/json");
          }
          if (!ctx.options.headers.has("accept")) {
            ctx.options.headers.set("accept", "application/json");
          }
        }
      }
    }
    ctx.response = await fetch2(ctx.request, ctx.options).catch(async (error) => {
      ctx.error = error;
      if (ctx.options.onRequestError) {
        await ctx.options.onRequestError(ctx);
      }
      return onError(ctx);
    });
    const responseType = (ctx.options.parseResponse ? "json" : ctx.options.responseType) || detectResponseType(ctx.response.headers.get("content-type") || "");
    if (responseType === "json") {
      const data = await ctx.response.text();
      const parseFn = ctx.options.parseResponse || destr;
      ctx.response._data = parseFn(data);
    } else {
      ctx.response._data = await ctx.response[responseType]();
    }
    if (ctx.options.onResponse) {
      await ctx.options.onResponse(ctx);
    }
    if (!ctx.response.ok) {
      if (ctx.options.onResponseError) {
        await ctx.options.onResponseError(ctx);
      }
    }
    return ctx.response.ok ? ctx.response : onError(ctx);
  };
  const $fetch2 = function $fetch22(request, opts) {
    return $fetchRaw(request, opts).then((r) => r._data);
  };
  $fetch2.raw = $fetchRaw;
  $fetch2.create = (defaultOptions = {}) => createFetch(__spreadProps(__spreadValues({}, globalOptions), {
    defaults: __spreadValues(__spreadValues({}, globalOptions.defaults), defaultOptions)
  }));
  return $fetch2;
}
const _globalThis$2 = function() {
  if (typeof globalThis !== "undefined") {
    return globalThis;
  }
  if (typeof self !== "undefined") {
    return self;
  }
  if (typeof global !== "undefined") {
    return global;
  }
  throw new Error("unable to locate global object");
}();
const fetch = _globalThis$2.fetch || (() => Promise.reject(new Error("[ohmyfetch] global.fetch is not supported!")));
const Headers = _globalThis$2.Headers;
const $fetch$1 = createFetch({ fetch, Headers });
const appConfig = useRuntimeConfig$1().app;
const baseURL = () => appConfig.baseURL;
const publicAssetsURL = (...path) => {
  const publicBase = appConfig.cdnURL || appConfig.baseURL;
  return path.length ? joinURL(publicBase, ...path) : publicBase;
};
function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
function serialCaller(hooks, args) {
  return hooks.reduce((promise, hookFn) => promise.then(() => hookFn.apply(void 0, args)), Promise.resolve(null));
}
function parallelCaller(hooks, args) {
  return Promise.all(hooks.map((hook) => hook.apply(void 0, args)));
}
class Hookable {
  constructor() {
    this._hooks = {};
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, fn) {
    if (!name || typeof fn !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let deprecatedHookObj;
    while (this._deprecatedHooks[name]) {
      const deprecatedHook = this._deprecatedHooks[name];
      if (typeof deprecatedHook === "string") {
        deprecatedHookObj = { to: deprecatedHook };
      } else {
        deprecatedHookObj = deprecatedHook;
      }
      name = deprecatedHookObj.to;
    }
    if (deprecatedHookObj) {
      if (!deprecatedHookObj.message) {
        console.warn(`${originalName} hook has been deprecated` + (deprecatedHookObj.to ? `, please use ${deprecatedHookObj.to}` : ""));
      } else {
        console.warn(deprecatedHookObj.message);
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(fn);
    return () => {
      if (fn) {
        this.removeHook(name, fn);
        fn = null;
      }
    };
  }
  hookOnce(name, fn) {
    let _unreg;
    let _fn = (...args) => {
      _unreg();
      _unreg = null;
      _fn = null;
      return fn(...args);
    };
    _unreg = this.hook(name, _fn);
    return _unreg;
  }
  removeHook(name, fn) {
    if (this._hooks[name]) {
      const idx = this._hooks[name].indexOf(fn);
      if (idx !== -1) {
        this._hooks[name].splice(idx, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = deprecated;
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map((key) => this.hook(key, hooks[key]));
    return () => {
      removeFns.splice(0, removeFns.length).forEach((unreg) => unreg());
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  callHook(name, ...args) {
    return serialCaller(this._hooks[name] || [], args);
  }
  callHookParallel(name, ...args) {
    return parallelCaller(this._hooks[name] || [], args);
  }
  callHookWith(caller, name, ...args) {
    return caller(this._hooks[name] || [], args);
  }
}
function createHooks() {
  return new Hookable();
}
function createContext() {
  let currentInstance = null;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  return {
    use: () => currentInstance,
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = null;
      isSingleton = false;
    },
    call: (instance, cb) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return cb();
      } finally {
        if (!isSingleton) {
          currentInstance = null;
        }
      }
    },
    async callAsync(instance, cb) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = cb();
        if (!isSingleton) {
          currentInstance = null;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace() {
  const contexts = {};
  return {
    get(key) {
      if (!contexts[key]) {
        contexts[key] = createContext();
      }
      contexts[key];
      return contexts[key];
    }
  };
}
const _globalThis$1 = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey$1 = "__unctx__";
const defaultNamespace = _globalThis$1[globalKey$1] || (_globalThis$1[globalKey$1] = createNamespace());
const getContext = (key) => defaultNamespace.get(key);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis$1[asyncHandlersKey] || (_globalThis$1[asyncHandlersKey] = /* @__PURE__ */ new Set());
function createMock(name, overrides = {}) {
  const fn = function() {
  };
  fn.prototype.name = name;
  const props = {};
  return new Proxy(fn, {
    get(_target, prop) {
      if (prop === "caller") {
        return null;
      }
      if (prop === "__createMock__") {
        return createMock;
      }
      if (prop in overrides) {
        return overrides[prop];
      }
      return props[prop] = props[prop] || createMock(`${name}.${prop.toString()}`);
    },
    apply(_target, _this, _args) {
      return createMock(`${name}()`);
    },
    construct(_target, _args, _newT) {
      return createMock(`[${name}]`);
    },
    enumerate(_target) {
      return [];
    }
  });
}
const mockContext = createMock("mock");
function mock(warning) {
  console.warn(warning);
  return mockContext;
}
const unsupported = /* @__PURE__ */ new Set([
  "store",
  "spa",
  "fetchCounters"
]);
const todo = /* @__PURE__ */ new Set([
  "isHMR",
  "base",
  "payload",
  "from",
  "next",
  "error",
  "redirect",
  "redirected",
  "enablePreview",
  "$preview",
  "beforeNuxtRender",
  "beforeSerialize"
]);
const routerKeys = ["route", "params", "query"];
const staticFlags = {
  isClient: false,
  isServer: true,
  isDev: false,
  isStatic: void 0,
  target: "server",
  modern: false
};
const legacyPlugin = (nuxtApp) => {
  nuxtApp._legacyContext = new Proxy(nuxtApp, {
    get(nuxt, p) {
      if (unsupported.has(p)) {
        return mock(`Accessing ${p} is not supported in Nuxt 3.`);
      }
      if (todo.has(p)) {
        return mock(`Accessing ${p} is not yet supported in Nuxt 3.`);
      }
      if (routerKeys.includes(p)) {
        if (!("$router" in nuxtApp)) {
          return mock("vue-router is not being used in this project.");
        }
        switch (p) {
          case "route":
            return nuxt.$router.currentRoute.value;
          case "params":
          case "query":
            return nuxt.$router.currentRoute.value[p];
        }
      }
      if (p === "$config" || p === "env") {
        return useRuntimeConfig();
      }
      if (p in staticFlags) {
        return staticFlags[p];
      }
      if (p === "ssrContext") {
        return nuxt._legacyContext;
      }
      if (nuxt.ssrContext && p in nuxt.ssrContext) {
        return nuxt.ssrContext[p];
      }
      if (p === "nuxt") {
        return nuxt.payload;
      }
      if (p === "nuxtState") {
        return nuxt.payload.data;
      }
      if (p in nuxtApp.vueApp) {
        return nuxtApp.vueApp[p];
      }
      if (p in nuxtApp) {
        return nuxtApp[p];
      }
      return mock(`Accessing ${p} is not supported in Nuxt3.`);
    }
  });
};
const nuxtAppCtx = getContext("nuxt-app");
const NuxtPluginIndicator = "__nuxt_plugin";
function createNuxtApp(options) {
  const nuxtApp = __spreadValues({
    provide: void 0,
    globalName: "nuxt",
    payload: vue_cjs_prod.reactive(__spreadValues({
      data: {},
      state: {},
      _errors: {}
    }, { serverRendered: true })),
    isHydrating: false,
    _asyncDataPromises: {}
  }, options);
  nuxtApp.hooks = createHooks();
  nuxtApp.hook = nuxtApp.hooks.hook;
  nuxtApp.callHook = nuxtApp.hooks.callHook;
  nuxtApp.provide = (name, value) => {
    const $name = "$" + name;
    defineGetter(nuxtApp, $name, value);
    defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
  };
  defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
  defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
  if (nuxtApp.ssrContext) {
    nuxtApp.ssrContext.nuxt = nuxtApp;
  }
  {
    nuxtApp.ssrContext = nuxtApp.ssrContext || {};
    nuxtApp.ssrContext.payload = nuxtApp.payload;
  }
  {
    nuxtApp.payload.config = {
      public: options.ssrContext.runtimeConfig.public,
      app: options.ssrContext.runtimeConfig.app
    };
  }
  const runtimeConfig = options.ssrContext.runtimeConfig;
  const compatibilityConfig = new Proxy(runtimeConfig, {
    get(target, prop) {
      var _a2;
      if (prop === "public") {
        return target.public;
      }
      return (_a2 = target[prop]) != null ? _a2 : target.public[prop];
    },
    set(target, prop, value) {
      {
        return false;
      }
    }
  });
  nuxtApp.provide("config", compatibilityConfig);
  return nuxtApp;
}
async function applyPlugin(nuxtApp, plugin) {
  if (typeof plugin !== "function") {
    return;
  }
  const { provide: provide2 } = await callWithNuxt(nuxtApp, plugin, [nuxtApp]) || {};
  if (provide2 && typeof provide2 === "object") {
    for (const key in provide2) {
      nuxtApp.provide(key, provide2[key]);
    }
  }
}
async function applyPlugins(nuxtApp, plugins2) {
  for (const plugin of plugins2) {
    await applyPlugin(nuxtApp, plugin);
  }
}
function normalizePlugins(_plugins2) {
  let needsLegacyContext = false;
  const plugins2 = _plugins2.map((plugin) => {
    if (typeof plugin !== "function") {
      return () => {
      };
    }
    if (isLegacyPlugin(plugin)) {
      needsLegacyContext = true;
      return (nuxtApp) => plugin(nuxtApp._legacyContext, nuxtApp.provide);
    }
    return plugin;
  });
  if (needsLegacyContext) {
    plugins2.unshift(legacyPlugin);
  }
  return plugins2;
}
function defineNuxtPlugin(plugin) {
  plugin[NuxtPluginIndicator] = true;
  return plugin;
}
function isLegacyPlugin(plugin) {
  return !plugin[NuxtPluginIndicator];
}
function callWithNuxt(nuxt, setup, args) {
  const fn = () => args ? setup(...args) : setup();
  {
    return nuxtAppCtx.callAsync(nuxt, fn);
  }
}
function useNuxtApp() {
  const vm = vue_cjs_prod.getCurrentInstance();
  if (!vm) {
    const nuxtAppInstance = nuxtAppCtx.use();
    if (!nuxtAppInstance) {
      throw new Error("nuxt instance unavailable");
    }
    return nuxtAppInstance;
  }
  return vm.appContext.app.$nuxt;
}
function useRuntimeConfig() {
  return useNuxtApp().$config;
}
function defineGetter(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
var vueRouter_cjs_prod = {};
/*!
  * vue-router v4.0.15
  * (c) 2022 Eduardo San Martin Morote
  * @license MIT
  */
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  var vue = require$$0;
  const hasSymbol = typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol";
  const PolySymbol = (name) => hasSymbol ? Symbol(name) : "_vr_" + name;
  const matchedRouteKey = /* @__PURE__ */ PolySymbol("rvlm");
  const viewDepthKey = /* @__PURE__ */ PolySymbol("rvd");
  const routerKey = /* @__PURE__ */ PolySymbol("r");
  const routeLocationKey = /* @__PURE__ */ PolySymbol("rl");
  const routerViewLocationKey = /* @__PURE__ */ PolySymbol("rvl");
  function isESModule(obj) {
    return obj.__esModule || hasSymbol && obj[Symbol.toStringTag] === "Module";
  }
  const assign = Object.assign;
  function applyToParams(fn, params) {
    const newParams = {};
    for (const key in params) {
      const value = params[key];
      newParams[key] = Array.isArray(value) ? value.map(fn) : fn(value);
    }
    return newParams;
  }
  const noop2 = () => {
  };
  const TRAILING_SLASH_RE = /\/$/;
  const removeTrailingSlash = (path) => path.replace(TRAILING_SLASH_RE, "");
  function parseURL(parseQuery2, location2, currentLocation = "/") {
    let path, query2 = {}, searchString = "", hash2 = "";
    const searchPos = location2.indexOf("?");
    const hashPos = location2.indexOf("#", searchPos > -1 ? searchPos : 0);
    if (searchPos > -1) {
      path = location2.slice(0, searchPos);
      searchString = location2.slice(searchPos + 1, hashPos > -1 ? hashPos : location2.length);
      query2 = parseQuery2(searchString);
    }
    if (hashPos > -1) {
      path = path || location2.slice(0, hashPos);
      hash2 = location2.slice(hashPos, location2.length);
    }
    path = resolveRelativePath(path != null ? path : location2, currentLocation);
    return {
      fullPath: path + (searchString && "?") + searchString + hash2,
      path,
      query: query2,
      hash: hash2
    };
  }
  function stringifyURL(stringifyQuery2, location2) {
    const query2 = location2.query ? stringifyQuery2(location2.query) : "";
    return location2.path + (query2 && "?") + query2 + (location2.hash || "");
  }
  function stripBase(pathname, base) {
    if (!base || !pathname.toLowerCase().startsWith(base.toLowerCase()))
      return pathname;
    return pathname.slice(base.length) || "/";
  }
  function isSameRouteLocation(stringifyQuery2, a, b) {
    const aLastIndex = a.matched.length - 1;
    const bLastIndex = b.matched.length - 1;
    return aLastIndex > -1 && aLastIndex === bLastIndex && isSameRouteRecord(a.matched[aLastIndex], b.matched[bLastIndex]) && isSameRouteLocationParams(a.params, b.params) && stringifyQuery2(a.query) === stringifyQuery2(b.query) && a.hash === b.hash;
  }
  function isSameRouteRecord(a, b) {
    return (a.aliasOf || a) === (b.aliasOf || b);
  }
  function isSameRouteLocationParams(a, b) {
    if (Object.keys(a).length !== Object.keys(b).length)
      return false;
    for (const key in a) {
      if (!isSameRouteLocationParamsValue(a[key], b[key]))
        return false;
    }
    return true;
  }
  function isSameRouteLocationParamsValue(a, b) {
    return Array.isArray(a) ? isEquivalentArray(a, b) : Array.isArray(b) ? isEquivalentArray(b, a) : a === b;
  }
  function isEquivalentArray(a, b) {
    return Array.isArray(b) ? a.length === b.length && a.every((value, i) => value === b[i]) : a.length === 1 && a[0] === b;
  }
  function resolveRelativePath(to, from) {
    if (to.startsWith("/"))
      return to;
    if (!to)
      return from;
    const fromSegments = from.split("/");
    const toSegments = to.split("/");
    let position = fromSegments.length - 1;
    let toPosition;
    let segment;
    for (toPosition = 0; toPosition < toSegments.length; toPosition++) {
      segment = toSegments[toPosition];
      if (position === 1 || segment === ".")
        continue;
      if (segment === "..")
        position--;
      else
        break;
    }
    return fromSegments.slice(0, position).join("/") + "/" + toSegments.slice(toPosition - (toPosition === toSegments.length ? 1 : 0)).join("/");
  }
  var NavigationType;
  (function(NavigationType2) {
    NavigationType2["pop"] = "pop";
    NavigationType2["push"] = "push";
  })(NavigationType || (NavigationType = {}));
  var NavigationDirection;
  (function(NavigationDirection2) {
    NavigationDirection2["back"] = "back";
    NavigationDirection2["forward"] = "forward";
    NavigationDirection2["unknown"] = "";
  })(NavigationDirection || (NavigationDirection = {}));
  const START = "";
  function normalizeBase(base) {
    if (!base) {
      {
        base = "/";
      }
    }
    if (base[0] !== "/" && base[0] !== "#")
      base = "/" + base;
    return removeTrailingSlash(base);
  }
  const BEFORE_HASH_RE = /^[^#]+#/;
  function createHref(base, location2) {
    return base.replace(BEFORE_HASH_RE, "#") + location2;
  }
  const computeScrollPosition = () => ({
    left: window.pageXOffset,
    top: window.pageYOffset
  });
  let createBaseLocation = () => location.protocol + "//" + location.host;
  function createCurrentLocation(base, location2) {
    const { pathname, search, hash: hash2 } = location2;
    const hashPos = base.indexOf("#");
    if (hashPos > -1) {
      let slicePos = hash2.includes(base.slice(hashPos)) ? base.slice(hashPos).length : 1;
      let pathFromHash = hash2.slice(slicePos);
      if (pathFromHash[0] !== "/")
        pathFromHash = "/" + pathFromHash;
      return stripBase(pathFromHash, "");
    }
    const path = stripBase(pathname, base);
    return path + search + hash2;
  }
  function useHistoryListeners(base, historyState, currentLocation, replace) {
    let listeners = [];
    let teardowns = [];
    let pauseState = null;
    const popStateHandler = ({ state }) => {
      const to = createCurrentLocation(base, location);
      const from = currentLocation.value;
      const fromState = historyState.value;
      let delta = 0;
      if (state) {
        currentLocation.value = to;
        historyState.value = state;
        if (pauseState && pauseState === from) {
          pauseState = null;
          return;
        }
        delta = fromState ? state.position - fromState.position : 0;
      } else {
        replace(to);
      }
      listeners.forEach((listener) => {
        listener(currentLocation.value, from, {
          delta,
          type: NavigationType.pop,
          direction: delta ? delta > 0 ? NavigationDirection.forward : NavigationDirection.back : NavigationDirection.unknown
        });
      });
    };
    function pauseListeners() {
      pauseState = currentLocation.value;
    }
    function listen(callback) {
      listeners.push(callback);
      const teardown = () => {
        const index2 = listeners.indexOf(callback);
        if (index2 > -1)
          listeners.splice(index2, 1);
      };
      teardowns.push(teardown);
      return teardown;
    }
    function beforeUnloadListener() {
      const { history: history2 } = window;
      if (!history2.state)
        return;
      history2.replaceState(assign({}, history2.state, { scroll: computeScrollPosition() }), "");
    }
    function destroy() {
      for (const teardown of teardowns)
        teardown();
      teardowns = [];
      window.removeEventListener("popstate", popStateHandler);
      window.removeEventListener("beforeunload", beforeUnloadListener);
    }
    window.addEventListener("popstate", popStateHandler);
    window.addEventListener("beforeunload", beforeUnloadListener);
    return {
      pauseListeners,
      listen,
      destroy
    };
  }
  function buildState(back, current, forward, replaced = false, computeScroll = false) {
    return {
      back,
      current,
      forward,
      replaced,
      position: window.history.length,
      scroll: computeScroll ? computeScrollPosition() : null
    };
  }
  function useHistoryStateNavigation(base) {
    const { history: history2, location: location2 } = window;
    const currentLocation = {
      value: createCurrentLocation(base, location2)
    };
    const historyState = { value: history2.state };
    if (!historyState.value) {
      changeLocation(currentLocation.value, {
        back: null,
        current: currentLocation.value,
        forward: null,
        position: history2.length - 1,
        replaced: true,
        scroll: null
      }, true);
    }
    function changeLocation(to, state, replace2) {
      const hashIndex = base.indexOf("#");
      const url = hashIndex > -1 ? (location2.host && document.querySelector("base") ? base : base.slice(hashIndex)) + to : createBaseLocation() + base + to;
      try {
        history2[replace2 ? "replaceState" : "pushState"](state, "", url);
        historyState.value = state;
      } catch (err) {
        {
          console.error(err);
        }
        location2[replace2 ? "replace" : "assign"](url);
      }
    }
    function replace(to, data) {
      const state = assign({}, history2.state, buildState(historyState.value.back, to, historyState.value.forward, true), data, { position: historyState.value.position });
      changeLocation(to, state, true);
      currentLocation.value = to;
    }
    function push(to, data) {
      const currentState = assign({}, historyState.value, history2.state, {
        forward: to,
        scroll: computeScrollPosition()
      });
      changeLocation(currentState.current, currentState, true);
      const state = assign({}, buildState(currentLocation.value, to, null), { position: currentState.position + 1 }, data);
      changeLocation(to, state, false);
      currentLocation.value = to;
    }
    return {
      location: currentLocation,
      state: historyState,
      push,
      replace
    };
  }
  function createWebHistory(base) {
    base = normalizeBase(base);
    const historyNavigation = useHistoryStateNavigation(base);
    const historyListeners = useHistoryListeners(base, historyNavigation.state, historyNavigation.location, historyNavigation.replace);
    function go(delta, triggerListeners = true) {
      if (!triggerListeners)
        historyListeners.pauseListeners();
      history.go(delta);
    }
    const routerHistory = assign({
      location: "",
      base,
      go,
      createHref: createHref.bind(null, base)
    }, historyNavigation, historyListeners);
    Object.defineProperty(routerHistory, "location", {
      enumerable: true,
      get: () => historyNavigation.location.value
    });
    Object.defineProperty(routerHistory, "state", {
      enumerable: true,
      get: () => historyNavigation.state.value
    });
    return routerHistory;
  }
  function createMemoryHistory(base = "") {
    let listeners = [];
    let queue = [START];
    let position = 0;
    base = normalizeBase(base);
    function setLocation(location2) {
      position++;
      if (position === queue.length) {
        queue.push(location2);
      } else {
        queue.splice(position);
        queue.push(location2);
      }
    }
    function triggerListeners(to, from, { direction, delta }) {
      const info = {
        direction,
        delta,
        type: NavigationType.pop
      };
      for (const callback of listeners) {
        callback(to, from, info);
      }
    }
    const routerHistory = {
      location: START,
      state: {},
      base,
      createHref: createHref.bind(null, base),
      replace(to) {
        queue.splice(position--, 1);
        setLocation(to);
      },
      push(to, data) {
        setLocation(to);
      },
      listen(callback) {
        listeners.push(callback);
        return () => {
          const index2 = listeners.indexOf(callback);
          if (index2 > -1)
            listeners.splice(index2, 1);
        };
      },
      destroy() {
        listeners = [];
        queue = [START];
        position = 0;
      },
      go(delta, shouldTrigger = true) {
        const from = this.location;
        const direction = delta < 0 ? NavigationDirection.back : NavigationDirection.forward;
        position = Math.max(0, Math.min(position + delta, queue.length - 1));
        if (shouldTrigger) {
          triggerListeners(this.location, from, {
            direction,
            delta
          });
        }
      }
    };
    Object.defineProperty(routerHistory, "location", {
      enumerable: true,
      get: () => queue[position]
    });
    return routerHistory;
  }
  function createWebHashHistory(base) {
    base = location.host ? base || location.pathname + location.search : "";
    if (!base.includes("#"))
      base += "#";
    return createWebHistory(base);
  }
  function isRouteLocation(route) {
    return typeof route === "string" || route && typeof route === "object";
  }
  function isRouteName(name) {
    return typeof name === "string" || typeof name === "symbol";
  }
  const START_LOCATION_NORMALIZED = {
    path: "/",
    name: void 0,
    params: {},
    query: {},
    hash: "",
    fullPath: "/",
    matched: [],
    meta: {},
    redirectedFrom: void 0
  };
  const NavigationFailureSymbol = /* @__PURE__ */ PolySymbol("nf");
  exports.NavigationFailureType = void 0;
  (function(NavigationFailureType) {
    NavigationFailureType[NavigationFailureType["aborted"] = 4] = "aborted";
    NavigationFailureType[NavigationFailureType["cancelled"] = 8] = "cancelled";
    NavigationFailureType[NavigationFailureType["duplicated"] = 16] = "duplicated";
  })(exports.NavigationFailureType || (exports.NavigationFailureType = {}));
  const ErrorTypeMessages = {
    [1]({ location: location2, currentLocation }) {
      return `No match for
 ${JSON.stringify(location2)}${currentLocation ? "\nwhile being at\n" + JSON.stringify(currentLocation) : ""}`;
    },
    [2]({ from, to }) {
      return `Redirected from "${from.fullPath}" to "${stringifyRoute(to)}" via a navigation guard.`;
    },
    [4]({ from, to }) {
      return `Navigation aborted from "${from.fullPath}" to "${to.fullPath}" via a navigation guard.`;
    },
    [8]({ from, to }) {
      return `Navigation cancelled from "${from.fullPath}" to "${to.fullPath}" with a new navigation.`;
    },
    [16]({ from, to }) {
      return `Avoided redundant navigation to current location: "${from.fullPath}".`;
    }
  };
  function createRouterError(type, params) {
    {
      return assign(new Error(ErrorTypeMessages[type](params)), {
        type,
        [NavigationFailureSymbol]: true
      }, params);
    }
  }
  function isNavigationFailure(error, type) {
    return error instanceof Error && NavigationFailureSymbol in error && (type == null || !!(error.type & type));
  }
  const propertiesToLog = ["params", "query", "hash"];
  function stringifyRoute(to) {
    if (typeof to === "string")
      return to;
    if ("path" in to)
      return to.path;
    const location2 = {};
    for (const key of propertiesToLog) {
      if (key in to)
        location2[key] = to[key];
    }
    return JSON.stringify(location2, null, 2);
  }
  const BASE_PARAM_PATTERN = "[^/]+?";
  const BASE_PATH_PARSER_OPTIONS = {
    sensitive: false,
    strict: false,
    start: true,
    end: true
  };
  const REGEX_CHARS_RE = /[.+*?^${}()[\]/\\]/g;
  function tokensToParser(segments, extraOptions) {
    const options = assign({}, BASE_PATH_PARSER_OPTIONS, extraOptions);
    const score = [];
    let pattern = options.start ? "^" : "";
    const keys = [];
    for (const segment of segments) {
      const segmentScores = segment.length ? [] : [90];
      if (options.strict && !segment.length)
        pattern += "/";
      for (let tokenIndex = 0; tokenIndex < segment.length; tokenIndex++) {
        const token = segment[tokenIndex];
        let subSegmentScore = 40 + (options.sensitive ? 0.25 : 0);
        if (token.type === 0) {
          if (!tokenIndex)
            pattern += "/";
          pattern += token.value.replace(REGEX_CHARS_RE, "\\$&");
          subSegmentScore += 40;
        } else if (token.type === 1) {
          const { value, repeatable, optional, regexp } = token;
          keys.push({
            name: value,
            repeatable,
            optional
          });
          const re2 = regexp ? regexp : BASE_PARAM_PATTERN;
          if (re2 !== BASE_PARAM_PATTERN) {
            subSegmentScore += 10;
            try {
              new RegExp(`(${re2})`);
            } catch (err) {
              throw new Error(`Invalid custom RegExp for param "${value}" (${re2}): ` + err.message);
            }
          }
          let subPattern = repeatable ? `((?:${re2})(?:/(?:${re2}))*)` : `(${re2})`;
          if (!tokenIndex)
            subPattern = optional && segment.length < 2 ? `(?:/${subPattern})` : "/" + subPattern;
          if (optional)
            subPattern += "?";
          pattern += subPattern;
          subSegmentScore += 20;
          if (optional)
            subSegmentScore += -8;
          if (repeatable)
            subSegmentScore += -20;
          if (re2 === ".*")
            subSegmentScore += -50;
        }
        segmentScores.push(subSegmentScore);
      }
      score.push(segmentScores);
    }
    if (options.strict && options.end) {
      const i = score.length - 1;
      score[i][score[i].length - 1] += 0.7000000000000001;
    }
    if (!options.strict)
      pattern += "/?";
    if (options.end)
      pattern += "$";
    else if (options.strict)
      pattern += "(?:/|$)";
    const re = new RegExp(pattern, options.sensitive ? "" : "i");
    function parse(path) {
      const match = path.match(re);
      const params = {};
      if (!match)
        return null;
      for (let i = 1; i < match.length; i++) {
        const value = match[i] || "";
        const key = keys[i - 1];
        params[key.name] = value && key.repeatable ? value.split("/") : value;
      }
      return params;
    }
    function stringify(params) {
      let path = "";
      let avoidDuplicatedSlash = false;
      for (const segment of segments) {
        if (!avoidDuplicatedSlash || !path.endsWith("/"))
          path += "/";
        avoidDuplicatedSlash = false;
        for (const token of segment) {
          if (token.type === 0) {
            path += token.value;
          } else if (token.type === 1) {
            const { value, repeatable, optional } = token;
            const param = value in params ? params[value] : "";
            if (Array.isArray(param) && !repeatable)
              throw new Error(`Provided param "${value}" is an array but it is not repeatable (* or + modifiers)`);
            const text = Array.isArray(param) ? param.join("/") : param;
            if (!text) {
              if (optional) {
                if (segment.length < 2 && segments.length > 1) {
                  if (path.endsWith("/"))
                    path = path.slice(0, -1);
                  else
                    avoidDuplicatedSlash = true;
                }
              } else
                throw new Error(`Missing required param "${value}"`);
            }
            path += text;
          }
        }
      }
      return path;
    }
    return {
      re,
      score,
      keys,
      parse,
      stringify
    };
  }
  function compareScoreArray(a, b) {
    let i = 0;
    while (i < a.length && i < b.length) {
      const diff = b[i] - a[i];
      if (diff)
        return diff;
      i++;
    }
    if (a.length < b.length) {
      return a.length === 1 && a[0] === 40 + 40 ? -1 : 1;
    } else if (a.length > b.length) {
      return b.length === 1 && b[0] === 40 + 40 ? 1 : -1;
    }
    return 0;
  }
  function comparePathParserScore(a, b) {
    let i = 0;
    const aScore = a.score;
    const bScore = b.score;
    while (i < aScore.length && i < bScore.length) {
      const comp = compareScoreArray(aScore[i], bScore[i]);
      if (comp)
        return comp;
      i++;
    }
    return bScore.length - aScore.length;
  }
  const ROOT_TOKEN = {
    type: 0,
    value: ""
  };
  const VALID_PARAM_RE = /[a-zA-Z0-9_]/;
  function tokenizePath(path) {
    if (!path)
      return [[]];
    if (path === "/")
      return [[ROOT_TOKEN]];
    if (!path.startsWith("/")) {
      throw new Error(`Invalid path "${path}"`);
    }
    function crash(message) {
      throw new Error(`ERR (${state})/"${buffer}": ${message}`);
    }
    let state = 0;
    let previousState = state;
    const tokens = [];
    let segment;
    function finalizeSegment() {
      if (segment)
        tokens.push(segment);
      segment = [];
    }
    let i = 0;
    let char;
    let buffer = "";
    let customRe = "";
    function consumeBuffer() {
      if (!buffer)
        return;
      if (state === 0) {
        segment.push({
          type: 0,
          value: buffer
        });
      } else if (state === 1 || state === 2 || state === 3) {
        if (segment.length > 1 && (char === "*" || char === "+"))
          crash(`A repeatable param (${buffer}) must be alone in its segment. eg: '/:ids+.`);
        segment.push({
          type: 1,
          value: buffer,
          regexp: customRe,
          repeatable: char === "*" || char === "+",
          optional: char === "*" || char === "?"
        });
      } else {
        crash("Invalid state to consume buffer");
      }
      buffer = "";
    }
    function addCharToBuffer() {
      buffer += char;
    }
    while (i < path.length) {
      char = path[i++];
      if (char === "\\" && state !== 2) {
        previousState = state;
        state = 4;
        continue;
      }
      switch (state) {
        case 0:
          if (char === "/") {
            if (buffer) {
              consumeBuffer();
            }
            finalizeSegment();
          } else if (char === ":") {
            consumeBuffer();
            state = 1;
          } else {
            addCharToBuffer();
          }
          break;
        case 4:
          addCharToBuffer();
          state = previousState;
          break;
        case 1:
          if (char === "(") {
            state = 2;
          } else if (VALID_PARAM_RE.test(char)) {
            addCharToBuffer();
          } else {
            consumeBuffer();
            state = 0;
            if (char !== "*" && char !== "?" && char !== "+")
              i--;
          }
          break;
        case 2:
          if (char === ")") {
            if (customRe[customRe.length - 1] == "\\")
              customRe = customRe.slice(0, -1) + char;
            else
              state = 3;
          } else {
            customRe += char;
          }
          break;
        case 3:
          consumeBuffer();
          state = 0;
          if (char !== "*" && char !== "?" && char !== "+")
            i--;
          customRe = "";
          break;
        default:
          crash("Unknown state");
          break;
      }
    }
    if (state === 2)
      crash(`Unfinished custom RegExp for param "${buffer}"`);
    consumeBuffer();
    finalizeSegment();
    return tokens;
  }
  function createRouteRecordMatcher(record, parent, options) {
    const parser = tokensToParser(tokenizePath(record.path), options);
    const matcher = assign(parser, {
      record,
      parent,
      children: [],
      alias: []
    });
    if (parent) {
      if (!matcher.record.aliasOf === !parent.record.aliasOf)
        parent.children.push(matcher);
    }
    return matcher;
  }
  function createRouterMatcher(routes2, globalOptions) {
    const matchers = [];
    const matcherMap = /* @__PURE__ */ new Map();
    globalOptions = mergeOptions({ strict: false, end: true, sensitive: false }, globalOptions);
    function getRecordMatcher(name) {
      return matcherMap.get(name);
    }
    function addRoute(record, parent, originalRecord) {
      const isRootAdd = !originalRecord;
      const mainNormalizedRecord = normalizeRouteRecord(record);
      mainNormalizedRecord.aliasOf = originalRecord && originalRecord.record;
      const options = mergeOptions(globalOptions, record);
      const normalizedRecords = [
        mainNormalizedRecord
      ];
      if ("alias" in record) {
        const aliases = typeof record.alias === "string" ? [record.alias] : record.alias;
        for (const alias of aliases) {
          normalizedRecords.push(assign({}, mainNormalizedRecord, {
            components: originalRecord ? originalRecord.record.components : mainNormalizedRecord.components,
            path: alias,
            aliasOf: originalRecord ? originalRecord.record : mainNormalizedRecord
          }));
        }
      }
      let matcher;
      let originalMatcher;
      for (const normalizedRecord of normalizedRecords) {
        const { path } = normalizedRecord;
        if (parent && path[0] !== "/") {
          const parentPath = parent.record.path;
          const connectingSlash = parentPath[parentPath.length - 1] === "/" ? "" : "/";
          normalizedRecord.path = parent.record.path + (path && connectingSlash + path);
        }
        matcher = createRouteRecordMatcher(normalizedRecord, parent, options);
        if (originalRecord) {
          originalRecord.alias.push(matcher);
        } else {
          originalMatcher = originalMatcher || matcher;
          if (originalMatcher !== matcher)
            originalMatcher.alias.push(matcher);
          if (isRootAdd && record.name && !isAliasRecord(matcher))
            removeRoute(record.name);
        }
        if ("children" in mainNormalizedRecord) {
          const children = mainNormalizedRecord.children;
          for (let i = 0; i < children.length; i++) {
            addRoute(children[i], matcher, originalRecord && originalRecord.children[i]);
          }
        }
        originalRecord = originalRecord || matcher;
        insertMatcher(matcher);
      }
      return originalMatcher ? () => {
        removeRoute(originalMatcher);
      } : noop2;
    }
    function removeRoute(matcherRef) {
      if (isRouteName(matcherRef)) {
        const matcher = matcherMap.get(matcherRef);
        if (matcher) {
          matcherMap.delete(matcherRef);
          matchers.splice(matchers.indexOf(matcher), 1);
          matcher.children.forEach(removeRoute);
          matcher.alias.forEach(removeRoute);
        }
      } else {
        const index2 = matchers.indexOf(matcherRef);
        if (index2 > -1) {
          matchers.splice(index2, 1);
          if (matcherRef.record.name)
            matcherMap.delete(matcherRef.record.name);
          matcherRef.children.forEach(removeRoute);
          matcherRef.alias.forEach(removeRoute);
        }
      }
    }
    function getRoutes() {
      return matchers;
    }
    function insertMatcher(matcher) {
      let i = 0;
      while (i < matchers.length && comparePathParserScore(matcher, matchers[i]) >= 0 && (matcher.record.path !== matchers[i].record.path || !isRecordChildOf(matcher, matchers[i])))
        i++;
      matchers.splice(i, 0, matcher);
      if (matcher.record.name && !isAliasRecord(matcher))
        matcherMap.set(matcher.record.name, matcher);
    }
    function resolve(location2, currentLocation) {
      let matcher;
      let params = {};
      let path;
      let name;
      if ("name" in location2 && location2.name) {
        matcher = matcherMap.get(location2.name);
        if (!matcher)
          throw createRouterError(1, {
            location: location2
          });
        name = matcher.record.name;
        params = assign(paramsFromLocation(currentLocation.params, matcher.keys.filter((k) => !k.optional).map((k) => k.name)), location2.params);
        path = matcher.stringify(params);
      } else if ("path" in location2) {
        path = location2.path;
        matcher = matchers.find((m) => m.re.test(path));
        if (matcher) {
          params = matcher.parse(path);
          name = matcher.record.name;
        }
      } else {
        matcher = currentLocation.name ? matcherMap.get(currentLocation.name) : matchers.find((m) => m.re.test(currentLocation.path));
        if (!matcher)
          throw createRouterError(1, {
            location: location2,
            currentLocation
          });
        name = matcher.record.name;
        params = assign({}, currentLocation.params, location2.params);
        path = matcher.stringify(params);
      }
      const matched = [];
      let parentMatcher = matcher;
      while (parentMatcher) {
        matched.unshift(parentMatcher.record);
        parentMatcher = parentMatcher.parent;
      }
      return {
        name,
        path,
        params,
        matched,
        meta: mergeMetaFields(matched)
      };
    }
    routes2.forEach((route) => addRoute(route));
    return { addRoute, resolve, removeRoute, getRoutes, getRecordMatcher };
  }
  function paramsFromLocation(params, keys) {
    const newParams = {};
    for (const key of keys) {
      if (key in params)
        newParams[key] = params[key];
    }
    return newParams;
  }
  function normalizeRouteRecord(record) {
    return {
      path: record.path,
      redirect: record.redirect,
      name: record.name,
      meta: record.meta || {},
      aliasOf: void 0,
      beforeEnter: record.beforeEnter,
      props: normalizeRecordProps(record),
      children: record.children || [],
      instances: {},
      leaveGuards: /* @__PURE__ */ new Set(),
      updateGuards: /* @__PURE__ */ new Set(),
      enterCallbacks: {},
      components: "components" in record ? record.components || {} : { default: record.component }
    };
  }
  function normalizeRecordProps(record) {
    const propsObject = {};
    const props = record.props || false;
    if ("component" in record) {
      propsObject.default = props;
    } else {
      for (const name in record.components)
        propsObject[name] = typeof props === "boolean" ? props : props[name];
    }
    return propsObject;
  }
  function isAliasRecord(record) {
    while (record) {
      if (record.record.aliasOf)
        return true;
      record = record.parent;
    }
    return false;
  }
  function mergeMetaFields(matched) {
    return matched.reduce((meta2, record) => assign(meta2, record.meta), {});
  }
  function mergeOptions(defaults2, partialOptions) {
    const options = {};
    for (const key in defaults2) {
      options[key] = key in partialOptions ? partialOptions[key] : defaults2[key];
    }
    return options;
  }
  function isRecordChildOf(record, parent) {
    return parent.children.some((child) => child === record || isRecordChildOf(record, child));
  }
  const HASH_RE = /#/g;
  const AMPERSAND_RE = /&/g;
  const SLASH_RE = /\//g;
  const EQUAL_RE = /=/g;
  const IM_RE = /\?/g;
  const PLUS_RE = /\+/g;
  const ENC_BRACKET_OPEN_RE = /%5B/g;
  const ENC_BRACKET_CLOSE_RE = /%5D/g;
  const ENC_CARET_RE = /%5E/g;
  const ENC_BACKTICK_RE = /%60/g;
  const ENC_CURLY_OPEN_RE = /%7B/g;
  const ENC_PIPE_RE = /%7C/g;
  const ENC_CURLY_CLOSE_RE = /%7D/g;
  const ENC_SPACE_RE = /%20/g;
  function commonEncode(text) {
    return encodeURI("" + text).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]");
  }
  function encodeHash(text) {
    return commonEncode(text).replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
  }
  function encodeQueryValue(text) {
    return commonEncode(text).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
  }
  function encodeQueryKey(text) {
    return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
  }
  function encodePath(text) {
    return commonEncode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F");
  }
  function encodeParam(text) {
    return text == null ? "" : encodePath(text).replace(SLASH_RE, "%2F");
  }
  function decode(text) {
    try {
      return decodeURIComponent("" + text);
    } catch (err) {
    }
    return "" + text;
  }
  function parseQuery(search) {
    const query2 = {};
    if (search === "" || search === "?")
      return query2;
    const hasLeadingIM = search[0] === "?";
    const searchParams = (hasLeadingIM ? search.slice(1) : search).split("&");
    for (let i = 0; i < searchParams.length; ++i) {
      const searchParam = searchParams[i].replace(PLUS_RE, " ");
      const eqPos = searchParam.indexOf("=");
      const key = decode(eqPos < 0 ? searchParam : searchParam.slice(0, eqPos));
      const value = eqPos < 0 ? null : decode(searchParam.slice(eqPos + 1));
      if (key in query2) {
        let currentValue = query2[key];
        if (!Array.isArray(currentValue)) {
          currentValue = query2[key] = [currentValue];
        }
        currentValue.push(value);
      } else {
        query2[key] = value;
      }
    }
    return query2;
  }
  function stringifyQuery(query2) {
    let search = "";
    for (let key in query2) {
      const value = query2[key];
      key = encodeQueryKey(key);
      if (value == null) {
        if (value !== void 0) {
          search += (search.length ? "&" : "") + key;
        }
        continue;
      }
      const values = Array.isArray(value) ? value.map((v) => v && encodeQueryValue(v)) : [value && encodeQueryValue(value)];
      values.forEach((value2) => {
        if (value2 !== void 0) {
          search += (search.length ? "&" : "") + key;
          if (value2 != null)
            search += "=" + value2;
        }
      });
    }
    return search;
  }
  function normalizeQuery(query2) {
    const normalizedQuery = {};
    for (const key in query2) {
      const value = query2[key];
      if (value !== void 0) {
        normalizedQuery[key] = Array.isArray(value) ? value.map((v) => v == null ? null : "" + v) : value == null ? value : "" + value;
      }
    }
    return normalizedQuery;
  }
  function useCallbacks() {
    let handlers = [];
    function add(handler) {
      handlers.push(handler);
      return () => {
        const i = handlers.indexOf(handler);
        if (i > -1)
          handlers.splice(i, 1);
      };
    }
    function reset() {
      handlers = [];
    }
    return {
      add,
      list: () => handlers,
      reset
    };
  }
  function registerGuard(record, name, guard) {
    const removeFromList = () => {
      record[name].delete(guard);
    };
    vue.onUnmounted(removeFromList);
    vue.onDeactivated(removeFromList);
    vue.onActivated(() => {
      record[name].add(guard);
    });
    record[name].add(guard);
  }
  function onBeforeRouteLeave(leaveGuard) {
    const activeRecord = vue.inject(matchedRouteKey, {}).value;
    if (!activeRecord) {
      return;
    }
    registerGuard(activeRecord, "leaveGuards", leaveGuard);
  }
  function onBeforeRouteUpdate(updateGuard) {
    const activeRecord = vue.inject(matchedRouteKey, {}).value;
    if (!activeRecord) {
      return;
    }
    registerGuard(activeRecord, "updateGuards", updateGuard);
  }
  function guardToPromiseFn(guard, to, from, record, name) {
    const enterCallbackArray = record && (record.enterCallbacks[name] = record.enterCallbacks[name] || []);
    return () => new Promise((resolve, reject) => {
      const next = (valid) => {
        if (valid === false)
          reject(createRouterError(4, {
            from,
            to
          }));
        else if (valid instanceof Error) {
          reject(valid);
        } else if (isRouteLocation(valid)) {
          reject(createRouterError(2, {
            from: to,
            to: valid
          }));
        } else {
          if (enterCallbackArray && record.enterCallbacks[name] === enterCallbackArray && typeof valid === "function")
            enterCallbackArray.push(valid);
          resolve();
        }
      };
      const guardReturn = guard.call(record && record.instances[name], to, from, next);
      let guardCall = Promise.resolve(guardReturn);
      if (guard.length < 3)
        guardCall = guardCall.then(next);
      guardCall.catch((err) => reject(err));
    });
  }
  function extractComponentsGuards(matched, guardType, to, from) {
    const guards = [];
    for (const record of matched) {
      for (const name in record.components) {
        let rawComponent = record.components[name];
        if (guardType !== "beforeRouteEnter" && !record.instances[name])
          continue;
        if (isRouteComponent(rawComponent)) {
          const options = rawComponent.__vccOpts || rawComponent;
          const guard = options[guardType];
          guard && guards.push(guardToPromiseFn(guard, to, from, record, name));
        } else {
          let componentPromise = rawComponent();
          guards.push(() => componentPromise.then((resolved) => {
            if (!resolved)
              return Promise.reject(new Error(`Couldn't resolve component "${name}" at "${record.path}"`));
            const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
            record.components[name] = resolvedComponent;
            const options = resolvedComponent.__vccOpts || resolvedComponent;
            const guard = options[guardType];
            return guard && guardToPromiseFn(guard, to, from, record, name)();
          }));
        }
      }
    }
    return guards;
  }
  function isRouteComponent(component) {
    return typeof component === "object" || "displayName" in component || "props" in component || "__vccOpts" in component;
  }
  function useLink(props) {
    const router = vue.inject(routerKey);
    const currentRoute = vue.inject(routeLocationKey);
    const route = vue.computed(() => router.resolve(vue.unref(props.to)));
    const activeRecordIndex = vue.computed(() => {
      const { matched } = route.value;
      const { length } = matched;
      const routeMatched = matched[length - 1];
      const currentMatched = currentRoute.matched;
      if (!routeMatched || !currentMatched.length)
        return -1;
      const index2 = currentMatched.findIndex(isSameRouteRecord.bind(null, routeMatched));
      if (index2 > -1)
        return index2;
      const parentRecordPath = getOriginalPath(matched[length - 2]);
      return length > 1 && getOriginalPath(routeMatched) === parentRecordPath && currentMatched[currentMatched.length - 1].path !== parentRecordPath ? currentMatched.findIndex(isSameRouteRecord.bind(null, matched[length - 2])) : index2;
    });
    const isActive = vue.computed(() => activeRecordIndex.value > -1 && includesParams(currentRoute.params, route.value.params));
    const isExactActive = vue.computed(() => activeRecordIndex.value > -1 && activeRecordIndex.value === currentRoute.matched.length - 1 && isSameRouteLocationParams(currentRoute.params, route.value.params));
    function navigate(e = {}) {
      if (guardEvent(e)) {
        return router[vue.unref(props.replace) ? "replace" : "push"](vue.unref(props.to)).catch(noop2);
      }
      return Promise.resolve();
    }
    return {
      route,
      href: vue.computed(() => route.value.href),
      isActive,
      isExactActive,
      navigate
    };
  }
  const RouterLinkImpl = /* @__PURE__ */ vue.defineComponent({
    name: "RouterLink",
    props: {
      to: {
        type: [String, Object],
        required: true
      },
      replace: Boolean,
      activeClass: String,
      exactActiveClass: String,
      custom: Boolean,
      ariaCurrentValue: {
        type: String,
        default: "page"
      }
    },
    useLink,
    setup(props, { slots }) {
      const link = vue.reactive(useLink(props));
      const { options } = vue.inject(routerKey);
      const elClass = vue.computed(() => ({
        [getLinkClass(props.activeClass, options.linkActiveClass, "router-link-active")]: link.isActive,
        [getLinkClass(props.exactActiveClass, options.linkExactActiveClass, "router-link-exact-active")]: link.isExactActive
      }));
      return () => {
        const children = slots.default && slots.default(link);
        return props.custom ? children : vue.h("a", {
          "aria-current": link.isExactActive ? props.ariaCurrentValue : null,
          href: link.href,
          onClick: link.navigate,
          class: elClass.value
        }, children);
      };
    }
  });
  const RouterLink = RouterLinkImpl;
  function guardEvent(e) {
    if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
      return;
    if (e.defaultPrevented)
      return;
    if (e.button !== void 0 && e.button !== 0)
      return;
    if (e.currentTarget && e.currentTarget.getAttribute) {
      const target = e.currentTarget.getAttribute("target");
      if (/\b_blank\b/i.test(target))
        return;
    }
    if (e.preventDefault)
      e.preventDefault();
    return true;
  }
  function includesParams(outer, inner) {
    for (const key in inner) {
      const innerValue = inner[key];
      const outerValue = outer[key];
      if (typeof innerValue === "string") {
        if (innerValue !== outerValue)
          return false;
      } else {
        if (!Array.isArray(outerValue) || outerValue.length !== innerValue.length || innerValue.some((value, i) => value !== outerValue[i]))
          return false;
      }
    }
    return true;
  }
  function getOriginalPath(record) {
    return record ? record.aliasOf ? record.aliasOf.path : record.path : "";
  }
  const getLinkClass = (propClass, globalClass, defaultClass) => propClass != null ? propClass : globalClass != null ? globalClass : defaultClass;
  const RouterViewImpl = /* @__PURE__ */ vue.defineComponent({
    name: "RouterView",
    inheritAttrs: false,
    props: {
      name: {
        type: String,
        default: "default"
      },
      route: Object
    },
    compatConfig: { MODE: 3 },
    setup(props, { attrs, slots }) {
      const injectedRoute = vue.inject(routerViewLocationKey);
      const routeToDisplay = vue.computed(() => props.route || injectedRoute.value);
      const depth = vue.inject(viewDepthKey, 0);
      const matchedRouteRef = vue.computed(() => routeToDisplay.value.matched[depth]);
      vue.provide(viewDepthKey, depth + 1);
      vue.provide(matchedRouteKey, matchedRouteRef);
      vue.provide(routerViewLocationKey, routeToDisplay);
      const viewRef = vue.ref();
      vue.watch(() => [viewRef.value, matchedRouteRef.value, props.name], ([instance, to, name], [oldInstance, from, oldName]) => {
        if (to) {
          to.instances[name] = instance;
          if (from && from !== to && instance && instance === oldInstance) {
            if (!to.leaveGuards.size) {
              to.leaveGuards = from.leaveGuards;
            }
            if (!to.updateGuards.size) {
              to.updateGuards = from.updateGuards;
            }
          }
        }
        if (instance && to && (!from || !isSameRouteRecord(to, from) || !oldInstance)) {
          (to.enterCallbacks[name] || []).forEach((callback) => callback(instance));
        }
      }, { flush: "post" });
      return () => {
        const route = routeToDisplay.value;
        const matchedRoute = matchedRouteRef.value;
        const ViewComponent = matchedRoute && matchedRoute.components[props.name];
        const currentName = props.name;
        if (!ViewComponent) {
          return normalizeSlot(slots.default, { Component: ViewComponent, route });
        }
        const routePropsOption = matchedRoute.props[props.name];
        const routeProps = routePropsOption ? routePropsOption === true ? route.params : typeof routePropsOption === "function" ? routePropsOption(route) : routePropsOption : null;
        const onVnodeUnmounted = (vnode) => {
          if (vnode.component.isUnmounted) {
            matchedRoute.instances[currentName] = null;
          }
        };
        const component = vue.h(ViewComponent, assign({}, routeProps, attrs, {
          onVnodeUnmounted,
          ref: viewRef
        }));
        return normalizeSlot(slots.default, { Component: component, route }) || component;
      };
    }
  });
  function normalizeSlot(slot, data) {
    if (!slot)
      return null;
    const slotContent = slot(data);
    return slotContent.length === 1 ? slotContent[0] : slotContent;
  }
  const RouterView = RouterViewImpl;
  function createRouter(options) {
    const matcher = createRouterMatcher(options.routes, options);
    const parseQuery$1 = options.parseQuery || parseQuery;
    const stringifyQuery$1 = options.stringifyQuery || stringifyQuery;
    const routerHistory = options.history;
    const beforeGuards = useCallbacks();
    const beforeResolveGuards = useCallbacks();
    const afterGuards = useCallbacks();
    const currentRoute = vue.shallowRef(START_LOCATION_NORMALIZED);
    let pendingLocation = START_LOCATION_NORMALIZED;
    const normalizeParams = applyToParams.bind(null, (paramValue) => "" + paramValue);
    const encodeParams = applyToParams.bind(null, encodeParam);
    const decodeParams = applyToParams.bind(null, decode);
    function addRoute(parentOrRoute, route) {
      let parent;
      let record;
      if (isRouteName(parentOrRoute)) {
        parent = matcher.getRecordMatcher(parentOrRoute);
        record = route;
      } else {
        record = parentOrRoute;
      }
      return matcher.addRoute(record, parent);
    }
    function removeRoute(name) {
      const recordMatcher = matcher.getRecordMatcher(name);
      if (recordMatcher) {
        matcher.removeRoute(recordMatcher);
      }
    }
    function getRoutes() {
      return matcher.getRoutes().map((routeMatcher) => routeMatcher.record);
    }
    function hasRoute(name) {
      return !!matcher.getRecordMatcher(name);
    }
    function resolve(rawLocation, currentLocation) {
      currentLocation = assign({}, currentLocation || currentRoute.value);
      if (typeof rawLocation === "string") {
        const locationNormalized = parseURL(parseQuery$1, rawLocation, currentLocation.path);
        const matchedRoute2 = matcher.resolve({ path: locationNormalized.path }, currentLocation);
        const href2 = routerHistory.createHref(locationNormalized.fullPath);
        return assign(locationNormalized, matchedRoute2, {
          params: decodeParams(matchedRoute2.params),
          hash: decode(locationNormalized.hash),
          redirectedFrom: void 0,
          href: href2
        });
      }
      let matcherLocation;
      if ("path" in rawLocation) {
        matcherLocation = assign({}, rawLocation, {
          path: parseURL(parseQuery$1, rawLocation.path, currentLocation.path).path
        });
      } else {
        const targetParams = assign({}, rawLocation.params);
        for (const key in targetParams) {
          if (targetParams[key] == null) {
            delete targetParams[key];
          }
        }
        matcherLocation = assign({}, rawLocation, {
          params: encodeParams(rawLocation.params)
        });
        currentLocation.params = encodeParams(currentLocation.params);
      }
      const matchedRoute = matcher.resolve(matcherLocation, currentLocation);
      const hash2 = rawLocation.hash || "";
      matchedRoute.params = normalizeParams(decodeParams(matchedRoute.params));
      const fullPath = stringifyURL(stringifyQuery$1, assign({}, rawLocation, {
        hash: encodeHash(hash2),
        path: matchedRoute.path
      }));
      const href = routerHistory.createHref(fullPath);
      return assign({
        fullPath,
        hash: hash2,
        query: stringifyQuery$1 === stringifyQuery ? normalizeQuery(rawLocation.query) : rawLocation.query || {}
      }, matchedRoute, {
        redirectedFrom: void 0,
        href
      });
    }
    function locationAsObject(to) {
      return typeof to === "string" ? parseURL(parseQuery$1, to, currentRoute.value.path) : assign({}, to);
    }
    function checkCanceledNavigation(to, from) {
      if (pendingLocation !== to) {
        return createRouterError(8, {
          from,
          to
        });
      }
    }
    function push(to) {
      return pushWithRedirect(to);
    }
    function replace(to) {
      return push(assign(locationAsObject(to), { replace: true }));
    }
    function handleRedirectRecord(to) {
      const lastMatched = to.matched[to.matched.length - 1];
      if (lastMatched && lastMatched.redirect) {
        const { redirect } = lastMatched;
        let newTargetLocation = typeof redirect === "function" ? redirect(to) : redirect;
        if (typeof newTargetLocation === "string") {
          newTargetLocation = newTargetLocation.includes("?") || newTargetLocation.includes("#") ? newTargetLocation = locationAsObject(newTargetLocation) : { path: newTargetLocation };
          newTargetLocation.params = {};
        }
        return assign({
          query: to.query,
          hash: to.hash,
          params: to.params
        }, newTargetLocation);
      }
    }
    function pushWithRedirect(to, redirectedFrom) {
      const targetLocation = pendingLocation = resolve(to);
      const from = currentRoute.value;
      const data = to.state;
      const force = to.force;
      const replace2 = to.replace === true;
      const shouldRedirect = handleRedirectRecord(targetLocation);
      if (shouldRedirect)
        return pushWithRedirect(assign(locationAsObject(shouldRedirect), {
          state: data,
          force,
          replace: replace2
        }), redirectedFrom || targetLocation);
      const toLocation = targetLocation;
      toLocation.redirectedFrom = redirectedFrom;
      let failure;
      if (!force && isSameRouteLocation(stringifyQuery$1, from, targetLocation)) {
        failure = createRouterError(16, { to: toLocation, from });
        handleScroll();
      }
      return (failure ? Promise.resolve(failure) : navigate(toLocation, from)).catch((error) => isNavigationFailure(error) ? isNavigationFailure(error, 2) ? error : markAsReady(error) : triggerError(error, toLocation, from)).then((failure2) => {
        if (failure2) {
          if (isNavigationFailure(failure2, 2)) {
            return pushWithRedirect(assign(locationAsObject(failure2.to), {
              state: data,
              force,
              replace: replace2
            }), redirectedFrom || toLocation);
          }
        } else {
          failure2 = finalizeNavigation(toLocation, from, true, replace2, data);
        }
        triggerAfterEach(toLocation, from, failure2);
        return failure2;
      });
    }
    function checkCanceledNavigationAndReject(to, from) {
      const error = checkCanceledNavigation(to, from);
      return error ? Promise.reject(error) : Promise.resolve();
    }
    function navigate(to, from) {
      let guards;
      const [leavingRecords, updatingRecords, enteringRecords] = extractChangingRecords(to, from);
      guards = extractComponentsGuards(leavingRecords.reverse(), "beforeRouteLeave", to, from);
      for (const record of leavingRecords) {
        record.leaveGuards.forEach((guard) => {
          guards.push(guardToPromiseFn(guard, to, from));
        });
      }
      const canceledNavigationCheck = checkCanceledNavigationAndReject.bind(null, to, from);
      guards.push(canceledNavigationCheck);
      return runGuardQueue(guards).then(() => {
        guards = [];
        for (const guard of beforeGuards.list()) {
          guards.push(guardToPromiseFn(guard, to, from));
        }
        guards.push(canceledNavigationCheck);
        return runGuardQueue(guards);
      }).then(() => {
        guards = extractComponentsGuards(updatingRecords, "beforeRouteUpdate", to, from);
        for (const record of updatingRecords) {
          record.updateGuards.forEach((guard) => {
            guards.push(guardToPromiseFn(guard, to, from));
          });
        }
        guards.push(canceledNavigationCheck);
        return runGuardQueue(guards);
      }).then(() => {
        guards = [];
        for (const record of to.matched) {
          if (record.beforeEnter && !from.matched.includes(record)) {
            if (Array.isArray(record.beforeEnter)) {
              for (const beforeEnter of record.beforeEnter)
                guards.push(guardToPromiseFn(beforeEnter, to, from));
            } else {
              guards.push(guardToPromiseFn(record.beforeEnter, to, from));
            }
          }
        }
        guards.push(canceledNavigationCheck);
        return runGuardQueue(guards);
      }).then(() => {
        to.matched.forEach((record) => record.enterCallbacks = {});
        guards = extractComponentsGuards(enteringRecords, "beforeRouteEnter", to, from);
        guards.push(canceledNavigationCheck);
        return runGuardQueue(guards);
      }).then(() => {
        guards = [];
        for (const guard of beforeResolveGuards.list()) {
          guards.push(guardToPromiseFn(guard, to, from));
        }
        guards.push(canceledNavigationCheck);
        return runGuardQueue(guards);
      }).catch((err) => isNavigationFailure(err, 8) ? err : Promise.reject(err));
    }
    function triggerAfterEach(to, from, failure) {
      for (const guard of afterGuards.list())
        guard(to, from, failure);
    }
    function finalizeNavigation(toLocation, from, isPush, replace2, data) {
      const error = checkCanceledNavigation(toLocation, from);
      if (error)
        return error;
      const isFirstNavigation = from === START_LOCATION_NORMALIZED;
      const state = {};
      if (isPush) {
        if (replace2 || isFirstNavigation)
          routerHistory.replace(toLocation.fullPath, assign({
            scroll: isFirstNavigation && state && state.scroll
          }, data));
        else
          routerHistory.push(toLocation.fullPath, data);
      }
      currentRoute.value = toLocation;
      handleScroll();
      markAsReady();
    }
    let removeHistoryListener;
    function setupListeners() {
      if (removeHistoryListener)
        return;
      removeHistoryListener = routerHistory.listen((to, _from, info) => {
        const toLocation = resolve(to);
        const shouldRedirect = handleRedirectRecord(toLocation);
        if (shouldRedirect) {
          pushWithRedirect(assign(shouldRedirect, { replace: true }), toLocation).catch(noop2);
          return;
        }
        pendingLocation = toLocation;
        const from = currentRoute.value;
        navigate(toLocation, from).catch((error) => {
          if (isNavigationFailure(error, 4 | 8)) {
            return error;
          }
          if (isNavigationFailure(error, 2)) {
            pushWithRedirect(error.to, toLocation).then((failure) => {
              if (isNavigationFailure(failure, 4 | 16) && !info.delta && info.type === NavigationType.pop) {
                routerHistory.go(-1, false);
              }
            }).catch(noop2);
            return Promise.reject();
          }
          if (info.delta)
            routerHistory.go(-info.delta, false);
          return triggerError(error, toLocation, from);
        }).then((failure) => {
          failure = failure || finalizeNavigation(toLocation, from, false);
          if (failure) {
            if (info.delta) {
              routerHistory.go(-info.delta, false);
            } else if (info.type === NavigationType.pop && isNavigationFailure(failure, 4 | 16)) {
              routerHistory.go(-1, false);
            }
          }
          triggerAfterEach(toLocation, from, failure);
        }).catch(noop2);
      });
    }
    let readyHandlers = useCallbacks();
    let errorHandlers = useCallbacks();
    let ready;
    function triggerError(error, to, from) {
      markAsReady(error);
      const list = errorHandlers.list();
      if (list.length) {
        list.forEach((handler) => handler(error, to, from));
      } else {
        console.error(error);
      }
      return Promise.reject(error);
    }
    function isReady() {
      if (ready && currentRoute.value !== START_LOCATION_NORMALIZED)
        return Promise.resolve();
      return new Promise((resolve2, reject) => {
        readyHandlers.add([resolve2, reject]);
      });
    }
    function markAsReady(err) {
      if (!ready) {
        ready = !err;
        setupListeners();
        readyHandlers.list().forEach(([resolve2, reject]) => err ? reject(err) : resolve2());
        readyHandlers.reset();
      }
      return err;
    }
    function handleScroll(to, from, isPush, isFirstNavigation) {
      return Promise.resolve();
    }
    const go = (delta) => routerHistory.go(delta);
    const installedApps = /* @__PURE__ */ new Set();
    const router = {
      currentRoute,
      addRoute,
      removeRoute,
      hasRoute,
      getRoutes,
      resolve,
      options,
      push,
      replace,
      go,
      back: () => go(-1),
      forward: () => go(1),
      beforeEach: beforeGuards.add,
      beforeResolve: beforeResolveGuards.add,
      afterEach: afterGuards.add,
      onError: errorHandlers.add,
      isReady,
      install(app) {
        const router2 = this;
        app.component("RouterLink", RouterLink);
        app.component("RouterView", RouterView);
        app.config.globalProperties.$router = router2;
        Object.defineProperty(app.config.globalProperties, "$route", {
          enumerable: true,
          get: () => vue.unref(currentRoute)
        });
        const reactiveRoute = {};
        for (const key in START_LOCATION_NORMALIZED) {
          reactiveRoute[key] = vue.computed(() => currentRoute.value[key]);
        }
        app.provide(routerKey, router2);
        app.provide(routeLocationKey, vue.reactive(reactiveRoute));
        app.provide(routerViewLocationKey, currentRoute);
        const unmountApp = app.unmount;
        installedApps.add(app);
        app.unmount = function() {
          installedApps.delete(app);
          if (installedApps.size < 1) {
            pendingLocation = START_LOCATION_NORMALIZED;
            removeHistoryListener && removeHistoryListener();
            removeHistoryListener = null;
            currentRoute.value = START_LOCATION_NORMALIZED;
            ready = false;
          }
          unmountApp();
        };
      }
    };
    return router;
  }
  function runGuardQueue(guards) {
    return guards.reduce((promise, guard) => promise.then(() => guard()), Promise.resolve());
  }
  function extractChangingRecords(to, from) {
    const leavingRecords = [];
    const updatingRecords = [];
    const enteringRecords = [];
    const len = Math.max(from.matched.length, to.matched.length);
    for (let i = 0; i < len; i++) {
      const recordFrom = from.matched[i];
      if (recordFrom) {
        if (to.matched.find((record) => isSameRouteRecord(record, recordFrom)))
          updatingRecords.push(recordFrom);
        else
          leavingRecords.push(recordFrom);
      }
      const recordTo = to.matched[i];
      if (recordTo) {
        if (!from.matched.find((record) => isSameRouteRecord(record, recordTo))) {
          enteringRecords.push(recordTo);
        }
      }
    }
    return [leavingRecords, updatingRecords, enteringRecords];
  }
  function useRouter2() {
    return vue.inject(routerKey);
  }
  function useRoute2() {
    return vue.inject(routeLocationKey);
  }
  exports.RouterLink = RouterLink;
  exports.RouterView = RouterView;
  exports.START_LOCATION = START_LOCATION_NORMALIZED;
  exports.createMemoryHistory = createMemoryHistory;
  exports.createRouter = createRouter;
  exports.createRouterMatcher = createRouterMatcher;
  exports.createWebHashHistory = createWebHashHistory;
  exports.createWebHistory = createWebHistory;
  exports.isNavigationFailure = isNavigationFailure;
  exports.matchedRouteKey = matchedRouteKey;
  exports.onBeforeRouteLeave = onBeforeRouteLeave;
  exports.onBeforeRouteUpdate = onBeforeRouteUpdate;
  exports.parseQuery = parseQuery;
  exports.routeLocationKey = routeLocationKey;
  exports.routerKey = routerKey;
  exports.routerViewLocationKey = routerViewLocationKey;
  exports.stringifyQuery = stringifyQuery;
  exports.useLink = useLink;
  exports.useRoute = useRoute2;
  exports.useRouter = useRouter2;
  exports.viewDepthKey = viewDepthKey;
})(vueRouter_cjs_prod);
const wrapInRef = (value) => vue_cjs_prod.isRef(value) ? value : vue_cjs_prod.ref(value);
const getDefault = () => null;
function useAsyncData(key, handler, options = {}) {
  var _a2, _b2, _c, _d, _e;
  if (typeof key !== "string") {
    throw new TypeError("asyncData key must be a string");
  }
  if (typeof handler !== "function") {
    throw new TypeError("asyncData handler must be a function");
  }
  options = __spreadValues({ server: true, default: getDefault }, options);
  if (options.defer) {
    console.warn("[useAsyncData] `defer` has been renamed to `lazy`. Support for `defer` will be removed in RC.");
  }
  options.lazy = (_b2 = (_a2 = options.lazy) != null ? _a2 : options.defer) != null ? _b2 : false;
  options.initialCache = (_c = options.initialCache) != null ? _c : true;
  const nuxt = useNuxtApp();
  const instance = vue_cjs_prod.getCurrentInstance();
  if (instance && !instance._nuxtOnBeforeMountCbs) {
    const cbs = instance._nuxtOnBeforeMountCbs = [];
    if (instance && false) {
      vue_cjs_prod.onBeforeMount(() => {
        cbs.forEach((cb) => {
          cb();
        });
        cbs.splice(0, cbs.length);
      });
      vue_cjs_prod.onUnmounted(() => cbs.splice(0, cbs.length));
    }
  }
  const useInitialCache = () => options.initialCache && nuxt.payload.data[key] !== void 0;
  const asyncData = {
    data: wrapInRef((_d = nuxt.payload.data[key]) != null ? _d : options.default()),
    pending: vue_cjs_prod.ref(!useInitialCache()),
    error: vue_cjs_prod.ref((_e = nuxt.payload._errors[key]) != null ? _e : null)
  };
  asyncData.refresh = (opts = {}) => {
    if (nuxt._asyncDataPromises[key]) {
      return nuxt._asyncDataPromises[key];
    }
    if (opts._initial && useInitialCache()) {
      return nuxt.payload.data[key];
    }
    asyncData.pending.value = true;
    nuxt._asyncDataPromises[key] = Promise.resolve(handler(nuxt)).then((result) => {
      if (options.transform) {
        result = options.transform(result);
      }
      if (options.pick) {
        result = pick(result, options.pick);
      }
      asyncData.data.value = result;
      asyncData.error.value = null;
    }).catch((error) => {
      asyncData.error.value = error;
      asyncData.data.value = vue_cjs_prod.unref(options.default());
    }).finally(() => {
      asyncData.pending.value = false;
      nuxt.payload.data[key] = asyncData.data.value;
      if (asyncData.error.value) {
        nuxt.payload._errors[key] = true;
      }
      delete nuxt._asyncDataPromises[key];
    });
    return nuxt._asyncDataPromises[key];
  };
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options.server !== false && nuxt.payload.serverRendered;
  if (fetchOnServer) {
    const promise = initialFetch();
    vue_cjs_prod.onServerPrefetch(() => promise);
  }
  const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
const useState = (key, init) => {
  const nuxt = useNuxtApp();
  const state = vue_cjs_prod.toRef(nuxt.payload.state, key);
  if (state.value === void 0 && init) {
    const initialValue = init();
    if (vue_cjs_prod.isRef(initialValue)) {
      nuxt.payload.state[key] = initialValue;
      return initialValue;
    }
    state.value = initialValue;
  }
  return state;
};
const useError = () => {
  const nuxtApp = useNuxtApp();
  return useState("error", () => nuxtApp.ssrContext.error);
};
const throwError = (_err) => {
  const nuxtApp = useNuxtApp();
  useError();
  const err = typeof _err === "string" ? new Error(_err) : _err;
  nuxtApp.callHook("app:error", err);
  {
    nuxtApp.ssrContext.error = nuxtApp.ssrContext.error || err;
  }
  return err;
};
function murmurHash(key, seed = 0) {
  if (typeof key === "string") {
    key = createBuffer(key);
  }
  let i = 0;
  let h1 = seed;
  let k1;
  let h1b;
  const remainder = key.length & 3;
  const bytes = key.length - remainder;
  const c1 = 3432918353;
  const c2 = 461845907;
  while (i < bytes) {
    k1 = key[i] & 255 | (key[++i] & 255) << 8 | (key[++i] & 255) << 16 | (key[++i] & 255) << 24;
    ++i;
    k1 = (k1 & 65535) * c1 + (((k1 >>> 16) * c1 & 65535) << 16) & 4294967295;
    k1 = k1 << 15 | k1 >>> 17;
    k1 = (k1 & 65535) * c2 + (((k1 >>> 16) * c2 & 65535) << 16) & 4294967295;
    h1 ^= k1;
    h1 = h1 << 13 | h1 >>> 19;
    h1b = (h1 & 65535) * 5 + (((h1 >>> 16) * 5 & 65535) << 16) & 4294967295;
    h1 = (h1b & 65535) + 27492 + (((h1b >>> 16) + 58964 & 65535) << 16);
  }
  k1 = 0;
  switch (remainder) {
    case 3:
      k1 ^= (key[i + 2] & 255) << 16;
      break;
    case 2:
      k1 ^= (key[i + 1] & 255) << 8;
      break;
    case 1:
      k1 ^= key[i] & 255;
      k1 = (k1 & 65535) * c1 + (((k1 >>> 16) * c1 & 65535) << 16) & 4294967295;
      k1 = k1 << 15 | k1 >>> 17;
      k1 = (k1 & 65535) * c2 + (((k1 >>> 16) * c2 & 65535) << 16) & 4294967295;
      h1 ^= k1;
  }
  h1 ^= key.length;
  h1 ^= h1 >>> 16;
  h1 = (h1 & 65535) * 2246822507 + (((h1 >>> 16) * 2246822507 & 65535) << 16) & 4294967295;
  h1 ^= h1 >>> 13;
  h1 = (h1 & 65535) * 3266489909 + (((h1 >>> 16) * 3266489909 & 65535) << 16) & 4294967295;
  h1 ^= h1 >>> 16;
  return h1 >>> 0;
}
function createBuffer(val) {
  return new TextEncoder().encode(val);
}
const defaults = {
  ignoreUnknown: false,
  respectType: false,
  respectFunctionNames: false,
  respectFunctionProperties: false,
  unorderedObjects: true,
  unorderedArrays: false,
  unorderedSets: false
};
function objectHash(object, options = {}) {
  options = __spreadValues(__spreadValues({}, defaults), options);
  const hasher = createHasher(options);
  hasher.dispatch(object);
  return hasher.toString();
}
function createHasher(options) {
  const buff = [];
  let context = [];
  const write = (str) => {
    buff.push(str);
  };
  return {
    toString() {
      return buff.join("");
    },
    getContext() {
      return context;
    },
    dispatch(value) {
      if (options.replacer) {
        value = options.replacer(value);
      }
      const type = value === null ? "null" : typeof value;
      return this["_" + type](value);
    },
    _object(object) {
      const pattern = /\[object (.*)\]/i;
      const objString = Object.prototype.toString.call(object);
      const _objType = pattern.exec(objString);
      const objType = _objType ? _objType[1].toLowerCase() : "unknown:[" + objString.toLowerCase() + "]";
      let objectNumber = null;
      if ((objectNumber = context.indexOf(object)) >= 0) {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      } else {
        context.push(object);
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        write("buffer:");
        return write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this["_" + objType]) {
          this["_" + objType](object);
        } else if (options.ignoreUnknown) {
          return write("[" + objType + "]");
        } else {
          throw new Error('Unknown object type "' + objType + '"');
        }
      } else {
        let keys = Object.keys(object);
        if (options.unorderedObjects) {
          keys = keys.sort();
        }
        if (options.respectType !== false && !isNativeFunction(object)) {
          keys.splice(0, 0, "prototype", "__proto__", "letructor");
        }
        if (options.excludeKeys) {
          keys = keys.filter(function(key) {
            return !options.excludeKeys(key);
          });
        }
        write("object:" + keys.length + ":");
        return keys.forEach((key) => {
          this.dispatch(key);
          write(":");
          if (!options.excludeValues) {
            this.dispatch(object[key]);
          }
          write(",");
        });
      }
    },
    _array(arr, unordered) {
      unordered = typeof unordered !== "undefined" ? unordered : options.unorderedArrays !== false;
      write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        return arr.forEach((entry2) => {
          return this.dispatch(entry2);
        });
      }
      const contextAdditions = [];
      const entries = arr.map((entry2) => {
        const hasher = createHasher(options);
        hasher.dispatch(entry2);
        contextAdditions.push(hasher.getContext());
        return hasher.toString();
      });
      context = context.concat(contextAdditions);
      entries.sort();
      return this._array(entries, false);
    },
    _date(date) {
      return write("date:" + date.toJSON());
    },
    _symbol(sym) {
      return write("symbol:" + sym.toString());
    },
    _error(err) {
      return write("error:" + err.toString());
    },
    _boolean(bool) {
      return write("bool:" + bool.toString());
    },
    _string(string) {
      write("string:" + string.length + ":");
      write(string.toString());
    },
    _function(fn) {
      write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
      if (options.respectFunctionNames !== false) {
        this.dispatch("function-name:" + String(fn.name));
      }
      if (options.respectFunctionProperties) {
        this._object(fn);
      }
    },
    _number(number) {
      return write("number:" + number.toString());
    },
    _xml(xml) {
      return write("xml:" + xml.toString());
    },
    _null() {
      return write("Null");
    },
    _undefined() {
      return write("Undefined");
    },
    _regexp(regex) {
      return write("regex:" + regex.toString());
    },
    _uint8array(arr) {
      write("uint8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _uint8clampedarray(arr) {
      write("uint8clampedarray:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _int8array(arr) {
      write("int8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _uint16array(arr) {
      write("uint16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _int16array(arr) {
      write("int16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _uint32array(arr) {
      write("uint32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _int32array(arr) {
      write("int32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _float32array(arr) {
      write("float32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _float64array(arr) {
      write("float64array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    _arraybuffer(arr) {
      write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    },
    _url(url) {
      return write("url:" + url.toString());
    },
    _map(map) {
      write("map:");
      const arr = Array.from(map);
      return this._array(arr, options.unorderedSets !== false);
    },
    _set(set) {
      write("set:");
      const arr = Array.from(set);
      return this._array(arr, options.unorderedSets !== false);
    },
    _file(file) {
      write("file:");
      return this.dispatch([file.name, file.size, file.type, file.lastModfied]);
    },
    _blob() {
      if (options.ignoreUnknown) {
        return write("[blob]");
      }
      throw new Error('Hashing Blob objects is currently not supported\nUse "options.replacer" or "options.ignoreUnknown"\n');
    },
    _domwindow() {
      return write("domwindow");
    },
    _bigint(number) {
      return write("bigint:" + number.toString());
    },
    _process() {
      return write("process");
    },
    _timer() {
      return write("timer");
    },
    _pipe() {
      return write("pipe");
    },
    _tcp() {
      return write("tcp");
    },
    _udp() {
      return write("udp");
    },
    _tty() {
      return write("tty");
    },
    _statwatcher() {
      return write("statwatcher");
    },
    _securecontext() {
      return write("securecontext");
    },
    _connection() {
      return write("connection");
    },
    _zlib() {
      return write("zlib");
    },
    _context() {
      return write("context");
    },
    _nodescript() {
      return write("nodescript");
    },
    _httpparser() {
      return write("httpparser");
    },
    _dataview() {
      return write("dataview");
    },
    _signal() {
      return write("signal");
    },
    _fsevent() {
      return write("fsevent");
    },
    _tlswrap() {
      return write("tlswrap");
    }
  };
}
function isNativeFunction(f) {
  if (typeof f !== "function") {
    return false;
  }
  const exp = /^function\s+\w*\s*\(\s*\)\s*{\s+\[native code\]\s+}$/i;
  return exp.exec(Function.prototype.toString.call(f)) != null;
}
function hash(object, options = {}) {
  const hashed = typeof object === "string" ? object : objectHash(object, options);
  return String(murmurHash(hashed));
}
function useFetch(request, opts = {}) {
  const key = "$f_" + (opts.key || hash([request, __spreadProps(__spreadValues({}, opts), { transform: null })]));
  const _request = vue_cjs_prod.computed(() => {
    let r = request;
    if (typeof r === "function") {
      r = r();
    }
    return vue_cjs_prod.isRef(r) ? r.value : r;
  });
  const _fetchOptions = __spreadProps(__spreadValues({}, opts), {
    cache: typeof opts.cache === "boolean" ? void 0 : opts.cache
  });
  const _asyncDataOptions = __spreadProps(__spreadValues({}, opts), {
    watch: [
      _request,
      ...opts.watch || []
    ]
  });
  const asyncData = useAsyncData(key, () => {
    return $fetch(_request.value, _fetchOptions);
  }, _asyncDataOptions);
  return asyncData;
}
const MIMES = {
  html: "text/html",
  json: "application/json"
};
const defer = typeof setImmediate !== "undefined" ? setImmediate : (fn) => fn();
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      event.res.end(data);
      resolve(void 0);
    });
  });
}
function defaultContentType(event, type) {
  if (type && !event.res.getHeader("Content-Type")) {
    event.res.setHeader("Content-Type", type);
  }
}
function sendRedirect(event, location2, code = 302) {
  event.res.statusCode = code;
  event.res.setHeader("Location", location2);
  return send(event, "Redirecting to " + location2, MIMES.html);
}
class H3Error extends Error {
  constructor() {
    super(...arguments);
    this.statusCode = 500;
    this.statusMessage = "H3Error";
  }
}
function createError(input) {
  var _a2;
  if (input instanceof H3Error) {
    return input;
  }
  const err = new H3Error((_a2 = input.message) != null ? _a2 : input.statusMessage);
  if (input.statusCode) {
    err.statusCode = input.statusCode;
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  }
  if (input.data) {
    err.data = input.data;
  }
  return err;
}
const useRouter = () => {
  var _a2;
  return (_a2 = useNuxtApp()) == null ? void 0 : _a2.$router;
};
const useRoute = () => {
  return useNuxtApp()._route;
};
const isProcessingMiddleware = () => {
  try {
    if (useNuxtApp()._processingMiddleware) {
      return true;
    }
  } catch {
    return true;
  }
  return false;
};
const navigateTo = (to, options = {}) => {
  if (!to) {
    to = "/";
  }
  if (isProcessingMiddleware()) {
    return to;
  }
  const router = useRouter();
  {
    const nuxtApp = useNuxtApp();
    if (nuxtApp.ssrContext && nuxtApp.ssrContext.event) {
      const redirectLocation = router.resolve(to).fullPath || "/";
      return nuxtApp.callHook("app:redirected").then(() => sendRedirect(nuxtApp.ssrContext.event, redirectLocation, options.redirectCode || 301));
    }
  }
  return options.replace ? router.replace(to) : router.push(to);
};
const firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
const DEFAULT_EXTERNAL_REL_ATTRIBUTE = "noopener noreferrer";
function defineNuxtLink(options) {
  const componentName = options.componentName || "NuxtLink";
  const checkPropConflicts = (props, main, sub) => {
  };
  return vue_cjs_prod.defineComponent({
    name: componentName,
    props: {
      to: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      href: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      target: {
        type: String,
        default: void 0,
        required: false
      },
      rel: {
        type: String,
        default: void 0,
        required: false
      },
      noRel: {
        type: Boolean,
        default: void 0,
        required: false
      },
      activeClass: {
        type: String,
        default: void 0,
        required: false
      },
      exactActiveClass: {
        type: String,
        default: void 0,
        required: false
      },
      replace: {
        type: Boolean,
        default: void 0,
        required: false
      },
      ariaCurrentValue: {
        type: String,
        default: void 0,
        required: false
      },
      external: {
        type: Boolean,
        default: void 0,
        required: false
      },
      custom: {
        type: Boolean,
        default: void 0,
        required: false
      }
    },
    setup(props, { slots }) {
      const router = useRouter();
      const to = vue_cjs_prod.computed(() => {
        checkPropConflicts(props, "to", "href");
        return props.to || props.href || "";
      });
      const isExternal = vue_cjs_prod.computed(() => {
        if (props.external) {
          return true;
        }
        if (props.target && props.target !== "_self") {
          return true;
        }
        if (typeof to.value === "object") {
          return false;
        }
        return to.value === "" || hasProtocol(to.value, true);
      });
      return () => {
        var _a2, _b2, _c;
        if (!isExternal.value) {
          return vue_cjs_prod.h(vue_cjs_prod.resolveComponent("RouterLink"), {
            to: to.value,
            activeClass: props.activeClass || options.activeClass,
            exactActiveClass: props.exactActiveClass || options.exactActiveClass,
            replace: props.replace,
            ariaCurrentValue: props.ariaCurrentValue
          }, slots.default);
        }
        const href = typeof to.value === "object" ? (_b2 = (_a2 = router.resolve(to.value)) == null ? void 0 : _a2.href) != null ? _b2 : null : to.value || null;
        const target = props.target || null;
        checkPropConflicts(props, "noRel", "rel");
        const rel = props.noRel ? null : firstNonUndefined(props.rel, options.externalRelAttribute, href ? DEFAULT_EXTERNAL_REL_ATTRIBUTE : "") || null;
        return vue_cjs_prod.h("a", { href, rel, target }, (_c = slots.default) == null ? void 0 : _c.call(slots));
      };
    }
  });
}
const __nuxt_component_0 = defineNuxtLink({ componentName: "NuxtLink" });
var shared_cjs_prod = {};
Object.defineProperty(shared_cjs_prod, "__esModule", { value: true });
function makeMap(str, expectsLowerCase) {
  const map = /* @__PURE__ */ Object.create(null);
  const list = str.split(",");
  for (let i = 0; i < list.length; i++) {
    map[list[i]] = true;
  }
  return expectsLowerCase ? (val) => !!map[val.toLowerCase()] : (val) => !!map[val];
}
const PatchFlagNames = {
  [1]: `TEXT`,
  [2]: `CLASS`,
  [4]: `STYLE`,
  [8]: `PROPS`,
  [16]: `FULL_PROPS`,
  [32]: `HYDRATE_EVENTS`,
  [64]: `STABLE_FRAGMENT`,
  [128]: `KEYED_FRAGMENT`,
  [256]: `UNKEYED_FRAGMENT`,
  [512]: `NEED_PATCH`,
  [1024]: `DYNAMIC_SLOTS`,
  [2048]: `DEV_ROOT_FRAGMENT`,
  [-1]: `HOISTED`,
  [-2]: `BAIL`
};
const slotFlagsText = {
  [1]: "STABLE",
  [2]: "DYNAMIC",
  [3]: "FORWARDED"
};
const GLOBALS_WHITE_LISTED = "Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt";
const isGloballyWhitelisted = /* @__PURE__ */ makeMap(GLOBALS_WHITE_LISTED);
const range = 2;
function generateCodeFrame(source, start = 0, end = source.length) {
  let lines = source.split(/(\r?\n)/);
  const newlineSequences = lines.filter((_, idx) => idx % 2 === 1);
  lines = lines.filter((_, idx) => idx % 2 === 0);
  let count = 0;
  const res = [];
  for (let i = 0; i < lines.length; i++) {
    count += lines[i].length + (newlineSequences[i] && newlineSequences[i].length || 0);
    if (count >= start) {
      for (let j = i - range; j <= i + range || end > count; j++) {
        if (j < 0 || j >= lines.length)
          continue;
        const line = j + 1;
        res.push(`${line}${" ".repeat(Math.max(3 - String(line).length, 0))}|  ${lines[j]}`);
        const lineLength = lines[j].length;
        const newLineSeqLength = newlineSequences[j] && newlineSequences[j].length || 0;
        if (j === i) {
          const pad = start - (count - (lineLength + newLineSeqLength));
          const length = Math.max(1, end > count ? lineLength - pad : end - start);
          res.push(`   |  ` + " ".repeat(pad) + "^".repeat(length));
        } else if (j > i) {
          if (end > count) {
            const length = Math.max(Math.min(end - count, lineLength), 1);
            res.push(`   |  ` + "^".repeat(length));
          }
          count += lineLength + newLineSeqLength;
        }
      }
      break;
    }
  }
  return res.join("\n");
}
const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
const isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
const isBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs + `,async,autofocus,autoplay,controls,default,defer,disabled,hidden,loop,open,required,reversed,scoped,seamless,checked,muted,multiple,selected`);
function includeBooleanAttr(value) {
  return !!value || value === "";
}
const unsafeAttrCharRE = /[>/="'\u0009\u000a\u000c\u0020]/;
const attrValidationCache = {};
function isSSRSafeAttrName(name) {
  if (attrValidationCache.hasOwnProperty(name)) {
    return attrValidationCache[name];
  }
  const isUnsafe = unsafeAttrCharRE.test(name);
  if (isUnsafe) {
    console.error(`unsafe attribute name: ${name}`);
  }
  return attrValidationCache[name] = !isUnsafe;
}
const propsToAttrMap = {
  acceptCharset: "accept-charset",
  className: "class",
  htmlFor: "for",
  httpEquiv: "http-equiv"
};
const isNoUnitNumericStyleProp = /* @__PURE__ */ makeMap(`animation-iteration-count,border-image-outset,border-image-slice,border-image-width,box-flex,box-flex-group,box-ordinal-group,column-count,columns,flex,flex-grow,flex-positive,flex-shrink,flex-negative,flex-order,grid-row,grid-row-end,grid-row-span,grid-row-start,grid-column,grid-column-end,grid-column-span,grid-column-start,font-weight,line-clamp,line-height,opacity,order,orphans,tab-size,widows,z-index,zoom,fill-opacity,flood-opacity,stop-opacity,stroke-dasharray,stroke-dashoffset,stroke-miterlimit,stroke-opacity,stroke-width`);
const isKnownHtmlAttr = /* @__PURE__ */ makeMap(`accept,accept-charset,accesskey,action,align,allow,alt,async,autocapitalize,autocomplete,autofocus,autoplay,background,bgcolor,border,buffered,capture,challenge,charset,checked,cite,class,code,codebase,color,cols,colspan,content,contenteditable,contextmenu,controls,coords,crossorigin,csp,data,datetime,decoding,default,defer,dir,dirname,disabled,download,draggable,dropzone,enctype,enterkeyhint,for,form,formaction,formenctype,formmethod,formnovalidate,formtarget,headers,height,hidden,high,href,hreflang,http-equiv,icon,id,importance,integrity,ismap,itemprop,keytype,kind,label,lang,language,loading,list,loop,low,manifest,max,maxlength,minlength,media,min,multiple,muted,name,novalidate,open,optimum,pattern,ping,placeholder,poster,preload,radiogroup,readonly,referrerpolicy,rel,required,reversed,rows,rowspan,sandbox,scope,scoped,selected,shape,size,sizes,slot,span,spellcheck,src,srcdoc,srclang,srcset,start,step,style,summary,tabindex,target,title,translate,type,usemap,value,width,wrap`);
const isKnownSvgAttr = /* @__PURE__ */ makeMap(`xmlns,accent-height,accumulate,additive,alignment-baseline,alphabetic,amplitude,arabic-form,ascent,attributeName,attributeType,azimuth,baseFrequency,baseline-shift,baseProfile,bbox,begin,bias,by,calcMode,cap-height,class,clip,clipPathUnits,clip-path,clip-rule,color,color-interpolation,color-interpolation-filters,color-profile,color-rendering,contentScriptType,contentStyleType,crossorigin,cursor,cx,cy,d,decelerate,descent,diffuseConstant,direction,display,divisor,dominant-baseline,dur,dx,dy,edgeMode,elevation,enable-background,end,exponent,fill,fill-opacity,fill-rule,filter,filterRes,filterUnits,flood-color,flood-opacity,font-family,font-size,font-size-adjust,font-stretch,font-style,font-variant,font-weight,format,from,fr,fx,fy,g1,g2,glyph-name,glyph-orientation-horizontal,glyph-orientation-vertical,glyphRef,gradientTransform,gradientUnits,hanging,height,href,hreflang,horiz-adv-x,horiz-origin-x,id,ideographic,image-rendering,in,in2,intercept,k,k1,k2,k3,k4,kernelMatrix,kernelUnitLength,kerning,keyPoints,keySplines,keyTimes,lang,lengthAdjust,letter-spacing,lighting-color,limitingConeAngle,local,marker-end,marker-mid,marker-start,markerHeight,markerUnits,markerWidth,mask,maskContentUnits,maskUnits,mathematical,max,media,method,min,mode,name,numOctaves,offset,opacity,operator,order,orient,orientation,origin,overflow,overline-position,overline-thickness,panose-1,paint-order,path,pathLength,patternContentUnits,patternTransform,patternUnits,ping,pointer-events,points,pointsAtX,pointsAtY,pointsAtZ,preserveAlpha,preserveAspectRatio,primitiveUnits,r,radius,referrerPolicy,refX,refY,rel,rendering-intent,repeatCount,repeatDur,requiredExtensions,requiredFeatures,restart,result,rotate,rx,ry,scale,seed,shape-rendering,slope,spacing,specularConstant,specularExponent,speed,spreadMethod,startOffset,stdDeviation,stemh,stemv,stitchTiles,stop-color,stop-opacity,strikethrough-position,strikethrough-thickness,string,stroke,stroke-dasharray,stroke-dashoffset,stroke-linecap,stroke-linejoin,stroke-miterlimit,stroke-opacity,stroke-width,style,surfaceScale,systemLanguage,tabindex,tableValues,target,targetX,targetY,text-anchor,text-decoration,text-rendering,textLength,to,transform,transform-origin,type,u1,u2,underline-position,underline-thickness,unicode,unicode-bidi,unicode-range,units-per-em,v-alphabetic,v-hanging,v-ideographic,v-mathematical,values,vector-effect,version,vert-adv-y,vert-origin-x,vert-origin-y,viewBox,viewTarget,visibility,width,widths,word-spacing,writing-mode,x,x-height,x1,x2,xChannelSelector,xlink:actuate,xlink:arcrole,xlink:href,xlink:role,xlink:show,xlink:title,xlink:type,xml:base,xml:lang,xml:space,y,y1,y2,yChannelSelector,z,zoomAndPan`);
function normalizeStyle(value) {
  if (isArray(value)) {
    const res = {};
    for (let i = 0; i < value.length; i++) {
      const item = value[i];
      const normalized = isString$1(item) ? parseStringStyle(item) : normalizeStyle(item);
      if (normalized) {
        for (const key in normalized) {
          res[key] = normalized[key];
        }
      }
    }
    return res;
  } else if (isString$1(value)) {
    return value;
  } else if (isObject$1(value)) {
    return value;
  }
}
const listDelimiterRE = /;(?![^(]*\))/g;
const propertyDelimiterRE = /:(.+)/;
function parseStringStyle(cssText) {
  const ret = {};
  cssText.split(listDelimiterRE).forEach((item) => {
    if (item) {
      const tmp = item.split(propertyDelimiterRE);
      tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
    }
  });
  return ret;
}
function stringifyStyle(styles) {
  let ret = "";
  if (!styles || isString$1(styles)) {
    return ret;
  }
  for (const key in styles) {
    const value = styles[key];
    const normalizedKey = key.startsWith(`--`) ? key : hyphenate(key);
    if (isString$1(value) || typeof value === "number" && isNoUnitNumericStyleProp(normalizedKey)) {
      ret += `${normalizedKey}:${value};`;
    }
  }
  return ret;
}
function normalizeClass(value) {
  let res = "";
  if (isString$1(value)) {
    res = value;
  } else if (isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      const normalized = normalizeClass(value[i]);
      if (normalized) {
        res += normalized + " ";
      }
    }
  } else if (isObject$1(value)) {
    for (const name in value) {
      if (value[name]) {
        res += name + " ";
      }
    }
  }
  return res.trim();
}
function normalizeProps(props) {
  if (!props)
    return null;
  let { class: klass, style: style2 } = props;
  if (klass && !isString$1(klass)) {
    props.class = normalizeClass(klass);
  }
  if (style2) {
    props.style = normalizeStyle(style2);
  }
  return props;
}
const HTML_TAGS = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot";
const SVG_TAGS = "svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistanceLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view";
const VOID_TAGS = "area,base,br,col,embed,hr,img,input,link,meta,param,source,track,wbr";
const isHTMLTag = /* @__PURE__ */ makeMap(HTML_TAGS);
const isSVGTag = /* @__PURE__ */ makeMap(SVG_TAGS);
const isVoidTag = /* @__PURE__ */ makeMap(VOID_TAGS);
const escapeRE = /["'&<>]/;
function escapeHtml(string) {
  const str = "" + string;
  const match = escapeRE.exec(str);
  if (!match) {
    return str;
  }
  let html = "";
  let escaped;
  let index2;
  let lastIndex = 0;
  for (index2 = match.index; index2 < str.length; index2++) {
    switch (str.charCodeAt(index2)) {
      case 34:
        escaped = "&quot;";
        break;
      case 38:
        escaped = "&amp;";
        break;
      case 39:
        escaped = "&#39;";
        break;
      case 60:
        escaped = "&lt;";
        break;
      case 62:
        escaped = "&gt;";
        break;
      default:
        continue;
    }
    if (lastIndex !== index2) {
      html += str.slice(lastIndex, index2);
    }
    lastIndex = index2 + 1;
    html += escaped;
  }
  return lastIndex !== index2 ? html + str.slice(lastIndex, index2) : html;
}
const commentStripRE = /^-?>|<!--|-->|--!>|<!-$/g;
function escapeHtmlComment(src) {
  return src.replace(commentStripRE, "");
}
function looseCompareArrays(a, b) {
  if (a.length !== b.length)
    return false;
  let equal = true;
  for (let i = 0; equal && i < a.length; i++) {
    equal = looseEqual(a[i], b[i]);
  }
  return equal;
}
function looseEqual(a, b) {
  if (a === b)
    return true;
  let aValidType = isDate(a);
  let bValidType = isDate(b);
  if (aValidType || bValidType) {
    return aValidType && bValidType ? a.getTime() === b.getTime() : false;
  }
  aValidType = isArray(a);
  bValidType = isArray(b);
  if (aValidType || bValidType) {
    return aValidType && bValidType ? looseCompareArrays(a, b) : false;
  }
  aValidType = isObject$1(a);
  bValidType = isObject$1(b);
  if (aValidType || bValidType) {
    if (!aValidType || !bValidType) {
      return false;
    }
    const aKeysCount = Object.keys(a).length;
    const bKeysCount = Object.keys(b).length;
    if (aKeysCount !== bKeysCount) {
      return false;
    }
    for (const key in a) {
      const aHasKey = a.hasOwnProperty(key);
      const bHasKey = b.hasOwnProperty(key);
      if (aHasKey && !bHasKey || !aHasKey && bHasKey || !looseEqual(a[key], b[key])) {
        return false;
      }
    }
  }
  return String(a) === String(b);
}
function looseIndexOf(arr, val) {
  return arr.findIndex((item) => looseEqual(item, val));
}
const toDisplayString = (val) => {
  return isString$1(val) ? val : val == null ? "" : isArray(val) || isObject$1(val) && (val.toString === objectToString || !isFunction(val.toString)) ? JSON.stringify(val, replacer, 2) : String(val);
};
const replacer = (_key, val) => {
  if (val && val.__v_isRef) {
    return replacer(_key, val.value);
  } else if (isMap(val)) {
    return {
      [`Map(${val.size})`]: [...val.entries()].reduce((entries, [key, val2]) => {
        entries[`${key} =>`] = val2;
        return entries;
      }, {})
    };
  } else if (isSet(val)) {
    return {
      [`Set(${val.size})`]: [...val.values()]
    };
  } else if (isObject$1(val) && !isArray(val) && !isPlainObject(val)) {
    return String(val);
  }
  return val;
};
const EMPTY_OBJ = {};
const EMPTY_ARR = [];
const NOOP = () => {
};
const NO = () => false;
const onRE = /^on[^a-z]/;
const isOn = (key) => onRE.test(key);
const isModelListener = (key) => key.startsWith("onUpdate:");
const extend = Object.assign;
const remove = (arr, el) => {
  const i = arr.indexOf(el);
  if (i > -1) {
    arr.splice(i, 1);
  }
};
const hasOwnProperty = Object.prototype.hasOwnProperty;
const hasOwn = (val, key) => hasOwnProperty.call(val, key);
const isArray = Array.isArray;
const isMap = (val) => toTypeString(val) === "[object Map]";
const isSet = (val) => toTypeString(val) === "[object Set]";
const isDate = (val) => val instanceof Date;
const isFunction = (val) => typeof val === "function";
const isString$1 = (val) => typeof val === "string";
const isSymbol = (val) => typeof val === "symbol";
const isObject$1 = (val) => val !== null && typeof val === "object";
const isPromise = (val) => {
  return isObject$1(val) && isFunction(val.then) && isFunction(val.catch);
};
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);
const toRawType = (value) => {
  return toTypeString(value).slice(8, -1);
};
const isPlainObject = (val) => toTypeString(val) === "[object Object]";
const isIntegerKey = (key) => isString$1(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
const isReservedProp = /* @__PURE__ */ makeMap(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted");
const isBuiltInDirective = /* @__PURE__ */ makeMap("bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo");
const cacheStringFunction = (fn) => {
  const cache = /* @__PURE__ */ Object.create(null);
  return (str) => {
    const hit = cache[str];
    return hit || (cache[str] = fn(str));
  };
};
const camelizeRE = /-(\w)/g;
const camelize = cacheStringFunction((str) => {
  return str.replace(camelizeRE, (_, c) => c ? c.toUpperCase() : "");
});
const hyphenateRE = /\B([A-Z])/g;
const hyphenate = cacheStringFunction((str) => str.replace(hyphenateRE, "-$1").toLowerCase());
const capitalize = cacheStringFunction((str) => str.charAt(0).toUpperCase() + str.slice(1));
const toHandlerKey = cacheStringFunction((str) => str ? `on${capitalize(str)}` : ``);
const hasChanged = (value, oldValue) => !Object.is(value, oldValue);
const invokeArrayFns = (fns, arg) => {
  for (let i = 0; i < fns.length; i++) {
    fns[i](arg);
  }
};
const def = (obj, key, value) => {
  Object.defineProperty(obj, key, {
    configurable: true,
    enumerable: false,
    value
  });
};
const toNumber = (val) => {
  const n = parseFloat(val);
  return isNaN(n) ? val : n;
};
let _globalThis;
const getGlobalThis = () => {
  return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof commonjsGlobal !== "undefined" ? commonjsGlobal : {});
};
shared_cjs_prod.EMPTY_ARR = EMPTY_ARR;
shared_cjs_prod.EMPTY_OBJ = EMPTY_OBJ;
shared_cjs_prod.NO = NO;
shared_cjs_prod.NOOP = NOOP;
shared_cjs_prod.PatchFlagNames = PatchFlagNames;
shared_cjs_prod.camelize = camelize;
shared_cjs_prod.capitalize = capitalize;
shared_cjs_prod.def = def;
shared_cjs_prod.escapeHtml = escapeHtml;
shared_cjs_prod.escapeHtmlComment = escapeHtmlComment;
shared_cjs_prod.extend = extend;
shared_cjs_prod.generateCodeFrame = generateCodeFrame;
shared_cjs_prod.getGlobalThis = getGlobalThis;
shared_cjs_prod.hasChanged = hasChanged;
shared_cjs_prod.hasOwn = hasOwn;
shared_cjs_prod.hyphenate = hyphenate;
shared_cjs_prod.includeBooleanAttr = includeBooleanAttr;
shared_cjs_prod.invokeArrayFns = invokeArrayFns;
shared_cjs_prod.isArray = isArray;
shared_cjs_prod.isBooleanAttr = isBooleanAttr;
shared_cjs_prod.isBuiltInDirective = isBuiltInDirective;
shared_cjs_prod.isDate = isDate;
var isFunction_1 = shared_cjs_prod.isFunction = isFunction;
shared_cjs_prod.isGloballyWhitelisted = isGloballyWhitelisted;
shared_cjs_prod.isHTMLTag = isHTMLTag;
shared_cjs_prod.isIntegerKey = isIntegerKey;
shared_cjs_prod.isKnownHtmlAttr = isKnownHtmlAttr;
shared_cjs_prod.isKnownSvgAttr = isKnownSvgAttr;
shared_cjs_prod.isMap = isMap;
shared_cjs_prod.isModelListener = isModelListener;
shared_cjs_prod.isNoUnitNumericStyleProp = isNoUnitNumericStyleProp;
shared_cjs_prod.isObject = isObject$1;
shared_cjs_prod.isOn = isOn;
shared_cjs_prod.isPlainObject = isPlainObject;
shared_cjs_prod.isPromise = isPromise;
shared_cjs_prod.isReservedProp = isReservedProp;
shared_cjs_prod.isSSRSafeAttrName = isSSRSafeAttrName;
shared_cjs_prod.isSVGTag = isSVGTag;
shared_cjs_prod.isSet = isSet;
shared_cjs_prod.isSpecialBooleanAttr = isSpecialBooleanAttr;
shared_cjs_prod.isString = isString$1;
shared_cjs_prod.isSymbol = isSymbol;
shared_cjs_prod.isVoidTag = isVoidTag;
shared_cjs_prod.looseEqual = looseEqual;
shared_cjs_prod.looseIndexOf = looseIndexOf;
shared_cjs_prod.makeMap = makeMap;
shared_cjs_prod.normalizeClass = normalizeClass;
shared_cjs_prod.normalizeProps = normalizeProps;
shared_cjs_prod.normalizeStyle = normalizeStyle;
shared_cjs_prod.objectToString = objectToString;
shared_cjs_prod.parseStringStyle = parseStringStyle;
shared_cjs_prod.propsToAttrMap = propsToAttrMap;
shared_cjs_prod.remove = remove;
shared_cjs_prod.slotFlagsText = slotFlagsText;
shared_cjs_prod.stringifyStyle = stringifyStyle;
shared_cjs_prod.toDisplayString = toDisplayString;
shared_cjs_prod.toHandlerKey = toHandlerKey;
shared_cjs_prod.toNumber = toNumber;
shared_cjs_prod.toRawType = toRawType;
shared_cjs_prod.toTypeString = toTypeString;
function useHead$1(meta2) {
  const resolvedMeta = isFunction_1(meta2) ? vue_cjs_prod.computed(meta2) : meta2;
  useNuxtApp()._useHead(resolvedMeta);
}
const preload = defineNuxtPlugin((nuxtApp) => {
  nuxtApp.vueApp.mixin({
    beforeCreate() {
      const { _registeredComponents } = this.$nuxt.ssrContext;
      const { __moduleIdentifier } = this.$options;
      _registeredComponents.add(__moduleIdentifier);
    }
  });
});
const components = {
  Footer: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return Footer;
  }).then((c) => c.default || c)),
  Header: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return Header;
  }).then((c) => c.default || c)),
  Introduce: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return Introduce;
  }).then((c) => c.default || c)),
  Post: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return Post;
  }).then((c) => c.default || c)),
  Posts: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return Posts;
  }).then((c) => c.default || c)),
  Search: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return Search;
  }).then((c) => c.default || c)),
  Seo: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return Seo;
  }).then((c) => c.default || c)),
  ToggleTheme: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return ToggleTheme;
  }).then((c) => c.default || c)),
  UnoIcon: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return UnoIcon$1;
  }).then((c) => c.default || c))
};
function componentsPlugin_ec27b3c8(nuxtApp) {
  for (const name in components) {
    nuxtApp.vueApp.component(name, components[name]);
    nuxtApp.vueApp.component("Lazy" + name, components[name]);
  }
}
var __defProp2 = Object.defineProperty;
var __defProps2 = Object.defineProperties;
var __getOwnPropDescs2 = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols2 = Object.getOwnPropertySymbols;
var __hasOwnProp2 = Object.prototype.hasOwnProperty;
var __propIsEnum2 = Object.prototype.propertyIsEnumerable;
var __defNormalProp2 = (obj, key, value) => key in obj ? __defProp2(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues2 = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp2.call(b, prop))
      __defNormalProp2(a, prop, b[prop]);
  if (__getOwnPropSymbols2)
    for (var prop of __getOwnPropSymbols2(b)) {
      if (__propIsEnum2.call(b, prop))
        __defNormalProp2(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps2 = (a, b) => __defProps2(a, __getOwnPropDescs2(b));
var PROVIDE_KEY = `usehead`;
var HEAD_COUNT_KEY = `head:count`;
var HEAD_ATTRS_KEY = `data-head-attrs`;
var SELF_CLOSING_TAGS = ["meta", "link", "base"];
var createElement = (tag, attrs, document2) => {
  const el = document2.createElement(tag);
  for (const key of Object.keys(attrs)) {
    let value = attrs[key];
    if (key === "key" || value === false) {
      continue;
    }
    if (key === "children") {
      el.textContent = value;
    } else {
      el.setAttribute(key, value);
    }
  }
  return el;
};
var htmlEscape = (str) => str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
var stringifyAttrs = (attributes) => {
  const handledAttributes = [];
  for (let [key, value] of Object.entries(attributes)) {
    if (key === "children" || key === "key") {
      continue;
    }
    if (value === false || value == null) {
      continue;
    }
    let attribute = htmlEscape(key);
    if (value !== true) {
      attribute += `="${htmlEscape(String(value))}"`;
    }
    handledAttributes.push(attribute);
  }
  return handledAttributes.length > 0 ? " " + handledAttributes.join(" ") : "";
};
function isEqualNode(oldTag, newTag) {
  if (oldTag instanceof HTMLElement && newTag instanceof HTMLElement) {
    const nonce = newTag.getAttribute("nonce");
    if (nonce && !oldTag.getAttribute("nonce")) {
      const cloneTag = newTag.cloneNode(true);
      cloneTag.setAttribute("nonce", "");
      cloneTag.nonce = nonce;
      return nonce === oldTag.nonce && oldTag.isEqualNode(cloneTag);
    }
  }
  return oldTag.isEqualNode(newTag);
}
var getTagKey = (props) => {
  const names = ["key", "id", "name", "property"];
  for (const n of names) {
    const value = typeof props.getAttribute === "function" ? props.hasAttribute(n) ? props.getAttribute(n) : void 0 : props[n];
    if (value !== void 0) {
      return { name: n, value };
    }
  }
};
var injectHead = () => {
  const head = vue_cjs_prod.inject(PROVIDE_KEY);
  if (!head) {
    throw new Error(`You may forget to apply app.use(head)`);
  }
  return head;
};
var acceptFields = [
  "title",
  "meta",
  "link",
  "base",
  "style",
  "script",
  "htmlAttrs",
  "bodyAttrs"
];
var headObjToTags = (obj) => {
  const tags = [];
  for (const key of Object.keys(obj)) {
    if (obj[key] == null)
      continue;
    if (key === "title") {
      tags.push({ tag: key, props: { children: obj[key] } });
    } else if (key === "base") {
      tags.push({ tag: key, props: __spreadValues2({ key: "default" }, obj[key]) });
    } else if (acceptFields.includes(key)) {
      const value = obj[key];
      if (Array.isArray(value)) {
        value.forEach((item) => {
          tags.push({ tag: key, props: item });
        });
      } else if (value) {
        tags.push({ tag: key, props: value });
      }
    }
  }
  return tags;
};
var setAttrs = (el, attrs) => {
  const existingAttrs = el.getAttribute(HEAD_ATTRS_KEY);
  if (existingAttrs) {
    for (const key of existingAttrs.split(",")) {
      if (!(key in attrs)) {
        el.removeAttribute(key);
      }
    }
  }
  const keys = [];
  for (const key in attrs) {
    const value = attrs[key];
    if (value == null)
      continue;
    if (value === false) {
      el.removeAttribute(key);
    } else {
      el.setAttribute(key, value);
    }
    keys.push(key);
  }
  if (keys.length) {
    el.setAttribute(HEAD_ATTRS_KEY, keys.join(","));
  } else {
    el.removeAttribute(HEAD_ATTRS_KEY);
  }
};
var updateElements = (document2 = window.document, type, tags) => {
  var _a2;
  const head = document2.head;
  let headCountEl = head.querySelector(`meta[name="${HEAD_COUNT_KEY}"]`);
  const headCount = headCountEl ? Number(headCountEl.getAttribute("content")) : 0;
  const oldElements = [];
  if (headCountEl) {
    for (let i = 0, j = headCountEl.previousElementSibling; i < headCount; i++, j = (j == null ? void 0 : j.previousElementSibling) || null) {
      if (((_a2 = j == null ? void 0 : j.tagName) == null ? void 0 : _a2.toLowerCase()) === type) {
        oldElements.push(j);
      }
    }
  } else {
    headCountEl = document2.createElement("meta");
    headCountEl.setAttribute("name", HEAD_COUNT_KEY);
    headCountEl.setAttribute("content", "0");
    head.append(headCountEl);
  }
  let newElements = tags.map((tag) => createElement(tag.tag, tag.props, document2));
  newElements = newElements.filter((newEl) => {
    for (let i = 0; i < oldElements.length; i++) {
      const oldEl = oldElements[i];
      if (isEqualNode(oldEl, newEl)) {
        oldElements.splice(i, 1);
        return false;
      }
    }
    return true;
  });
  oldElements.forEach((t) => {
    var _a22;
    return (_a22 = t.parentNode) == null ? void 0 : _a22.removeChild(t);
  });
  newElements.forEach((t) => {
    head.insertBefore(t, headCountEl);
  });
  headCountEl.setAttribute("content", "" + (headCount - oldElements.length + newElements.length));
};
var createHead = () => {
  let allHeadObjs = [];
  let previousTags = /* @__PURE__ */ new Set();
  const head = {
    install(app) {
      app.config.globalProperties.$head = head;
      app.provide(PROVIDE_KEY, head);
    },
    get headTags() {
      const deduped = [];
      allHeadObjs.forEach((objs) => {
        const tags = headObjToTags(objs.value);
        tags.forEach((tag) => {
          if (tag.tag === "meta" || tag.tag === "base" || tag.tag === "script") {
            const key = getTagKey(tag.props);
            if (key) {
              let index2 = -1;
              for (let i = 0; i < deduped.length; i++) {
                const prev = deduped[i];
                const prevValue = prev.props[key.name];
                const nextValue = tag.props[key.name];
                if (prev.tag === tag.tag && prevValue === nextValue) {
                  index2 = i;
                  break;
                }
              }
              if (index2 !== -1) {
                deduped.splice(index2, 1);
              }
            }
          }
          deduped.push(tag);
        });
      });
      return deduped;
    },
    addHeadObjs(objs) {
      allHeadObjs.push(objs);
    },
    removeHeadObjs(objs) {
      allHeadObjs = allHeadObjs.filter((_objs) => _objs !== objs);
    },
    updateDOM(document2 = window.document) {
      let title;
      let htmlAttrs = {};
      let bodyAttrs = {};
      const actualTags = {};
      for (const tag of head.headTags) {
        if (tag.tag === "title") {
          title = tag.props.children;
          continue;
        }
        if (tag.tag === "htmlAttrs") {
          Object.assign(htmlAttrs, tag.props);
          continue;
        }
        if (tag.tag === "bodyAttrs") {
          Object.assign(bodyAttrs, tag.props);
          continue;
        }
        actualTags[tag.tag] = actualTags[tag.tag] || [];
        actualTags[tag.tag].push(tag);
      }
      if (title !== void 0) {
        document2.title = title;
      }
      setAttrs(document2.documentElement, htmlAttrs);
      setAttrs(document2.body, bodyAttrs);
      const tags = /* @__PURE__ */ new Set([...Object.keys(actualTags), ...previousTags]);
      for (const tag of tags) {
        updateElements(document2, tag, actualTags[tag] || []);
      }
      previousTags.clear();
      Object.keys(actualTags).forEach((i) => previousTags.add(i));
    }
  };
  return head;
};
var useHead = (obj) => {
  const headObj = vue_cjs_prod.ref(obj);
  const head = injectHead();
  head.addHeadObjs(headObj);
};
var tagToString = (tag) => {
  let attrs = stringifyAttrs(tag.props);
  if (SELF_CLOSING_TAGS.includes(tag.tag)) {
    return `<${tag.tag}${attrs}>`;
  }
  return `<${tag.tag}${attrs}>${tag.props.children || ""}</${tag.tag}>`;
};
var renderHeadToString = (head) => {
  const tags = [];
  let titleTag = "";
  let htmlAttrs = {};
  let bodyAttrs = {};
  for (const tag of head.headTags) {
    if (tag.tag === "title") {
      titleTag = tagToString(tag);
    } else if (tag.tag === "htmlAttrs") {
      Object.assign(htmlAttrs, tag.props);
    } else if (tag.tag === "bodyAttrs") {
      Object.assign(bodyAttrs, tag.props);
    } else {
      tags.push(tagToString(tag));
    }
  }
  tags.push(`<meta name="${HEAD_COUNT_KEY}" content="${tags.length}">`);
  return {
    get headTags() {
      return titleTag + tags.join("");
    },
    get htmlAttrs() {
      return stringifyAttrs(__spreadProps2(__spreadValues2({}, htmlAttrs), {
        [HEAD_ATTRS_KEY]: Object.keys(htmlAttrs).join(",")
      }));
    },
    get bodyAttrs() {
      return stringifyAttrs(__spreadProps2(__spreadValues2({}, bodyAttrs), {
        [HEAD_ATTRS_KEY]: Object.keys(bodyAttrs).join(",")
      }));
    }
  };
};
function isObject(val) {
  return val !== null && typeof val === "object";
}
function _defu(baseObj, defaults2, namespace = ".", merger) {
  if (!isObject(defaults2)) {
    return _defu(baseObj, {}, namespace, merger);
  }
  const obj = Object.assign({}, defaults2);
  for (const key in baseObj) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const val = baseObj[key];
    if (val === null || val === void 0) {
      continue;
    }
    if (merger && merger(obj, key, val, namespace)) {
      continue;
    }
    if (Array.isArray(val) && Array.isArray(obj[key])) {
      obj[key] = val.concat(obj[key]);
    } else if (isObject(val) && isObject(obj[key])) {
      obj[key] = _defu(val, obj[key], (namespace ? `${namespace}.` : "") + key.toString(), merger);
    } else {
      obj[key] = val;
    }
  }
  return obj;
}
function createDefu(merger) {
  return (...args) => args.reduce((p, c) => _defu(p, c, "", merger), {});
}
const defu = createDefu();
const vueuseHead_8f7ea34a = defineNuxtPlugin((nuxtApp) => {
  const head = createHead();
  nuxtApp.vueApp.use(head);
  nuxtApp.hooks.hookOnce("app:mounted", () => {
    vue_cjs_prod.watchEffect(() => {
      head.updateDOM();
    });
  });
  const titleTemplate = vue_cjs_prod.ref();
  nuxtApp._useHead = (_meta) => {
    const meta2 = vue_cjs_prod.ref(_meta);
    if ("titleTemplate" in meta2.value) {
      titleTemplate.value = meta2.value.titleTemplate;
    }
    const headObj = vue_cjs_prod.computed(() => {
      const overrides = { meta: [] };
      if (titleTemplate.value && "title" in meta2.value) {
        overrides.title = typeof titleTemplate.value === "function" ? titleTemplate.value(meta2.value.title) : titleTemplate.value.replace(/%s/g, meta2.value.title);
      }
      if (meta2.value.charset) {
        overrides.meta.push({ key: "charset", charset: meta2.value.charset });
      }
      if (meta2.value.viewport) {
        overrides.meta.push({ name: "viewport", content: meta2.value.viewport });
      }
      return defu(overrides, meta2.value);
    });
    head.addHeadObjs(headObj);
    {
      return;
    }
  };
  {
    nuxtApp.ssrContext.renderMeta = () => renderHeadToString(head);
  }
});
const removeUndefinedProps = (props) => Object.fromEntries(Object.entries(props).filter(([, value]) => value !== void 0));
const setupForUseMeta = (metaFactory, renderChild) => (props, ctx) => {
  useHead$1(() => metaFactory(__spreadValues(__spreadValues({}, removeUndefinedProps(props)), ctx.attrs), ctx));
  return () => {
    var _a2, _b2;
    return renderChild ? (_b2 = (_a2 = ctx.slots).default) == null ? void 0 : _b2.call(_a2) : null;
  };
};
const globalProps = {
  accesskey: String,
  autocapitalize: String,
  autofocus: {
    type: Boolean,
    default: void 0
  },
  class: String,
  contenteditable: {
    type: Boolean,
    default: void 0
  },
  contextmenu: String,
  dir: String,
  draggable: {
    type: Boolean,
    default: void 0
  },
  enterkeyhint: String,
  exportparts: String,
  hidden: {
    type: Boolean,
    default: void 0
  },
  id: String,
  inputmode: String,
  is: String,
  itemid: String,
  itemprop: String,
  itemref: String,
  itemscope: String,
  itemtype: String,
  lang: String,
  nonce: String,
  part: String,
  slot: String,
  spellcheck: {
    type: Boolean,
    default: void 0
  },
  style: String,
  tabindex: String,
  title: String,
  translate: String
};
const Script = vue_cjs_prod.defineComponent({
  name: "Script",
  props: __spreadProps(__spreadValues({}, globalProps), {
    async: Boolean,
    crossorigin: {
      type: [Boolean, String],
      default: void 0
    },
    defer: Boolean,
    integrity: String,
    nomodule: Boolean,
    nonce: String,
    referrerpolicy: String,
    src: String,
    type: String,
    charset: String,
    language: String
  }),
  setup: setupForUseMeta((script2) => ({
    script: [script2]
  }))
});
const Link = vue_cjs_prod.defineComponent({
  name: "Link",
  props: __spreadProps(__spreadValues({}, globalProps), {
    as: String,
    crossorigin: String,
    disabled: Boolean,
    href: String,
    hreflang: String,
    imagesizes: String,
    imagesrcset: String,
    integrity: String,
    media: String,
    prefetch: {
      type: Boolean,
      default: void 0
    },
    referrerpolicy: String,
    rel: String,
    sizes: String,
    title: String,
    type: String,
    methods: String,
    target: String
  }),
  setup: setupForUseMeta((link) => ({
    link: [link]
  }))
});
const Base = vue_cjs_prod.defineComponent({
  name: "Base",
  props: __spreadProps(__spreadValues({}, globalProps), {
    href: String,
    target: String
  }),
  setup: setupForUseMeta((base) => ({
    base
  }))
});
const Title = vue_cjs_prod.defineComponent({
  name: "Title",
  setup: setupForUseMeta((_, { slots }) => {
    var _a2, _b2, _c;
    const title = ((_c = (_b2 = (_a2 = slots.default) == null ? void 0 : _a2.call(slots)) == null ? void 0 : _b2[0]) == null ? void 0 : _c.children) || null;
    return {
      title
    };
  })
});
const Meta = vue_cjs_prod.defineComponent({
  name: "Meta",
  props: __spreadProps(__spreadValues({}, globalProps), {
    charset: String,
    content: String,
    httpEquiv: String,
    name: String
  }),
  setup: setupForUseMeta((meta2) => ({
    meta: [meta2]
  }))
});
const Style = vue_cjs_prod.defineComponent({
  name: "Style",
  props: __spreadProps(__spreadValues({}, globalProps), {
    type: String,
    media: String,
    nonce: String,
    title: String,
    scoped: {
      type: Boolean,
      default: void 0
    }
  }),
  setup: setupForUseMeta((props, { slots }) => {
    var _a2, _b2, _c;
    const style2 = __spreadValues({}, props);
    const textContent = (_c = (_b2 = (_a2 = slots.default) == null ? void 0 : _a2.call(slots)) == null ? void 0 : _b2[0]) == null ? void 0 : _c.children;
    if (textContent) {
      style2.children = textContent;
    }
    return {
      style: [style2]
    };
  })
});
const Head = vue_cjs_prod.defineComponent({
  name: "Head",
  setup: (_props, ctx) => () => {
    var _a2, _b2;
    return (_b2 = (_a2 = ctx.slots).default) == null ? void 0 : _b2.call(_a2);
  }
});
const Html = vue_cjs_prod.defineComponent({
  name: "Html",
  props: __spreadProps(__spreadValues({}, globalProps), {
    manifest: String,
    version: String,
    xmlns: String
  }),
  setup: setupForUseMeta((htmlAttrs) => ({ htmlAttrs }), true)
});
const Body = vue_cjs_prod.defineComponent({
  name: "Body",
  props: globalProps,
  setup: setupForUseMeta((bodyAttrs) => ({ bodyAttrs }), true)
});
const Components = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Script,
  Link,
  Base,
  Title,
  Meta,
  Style,
  Head,
  Html,
  Body
}, Symbol.toStringTag, { value: "Module" }));
const metaConfig = { "globalMeta": { "charset": "utf-8", "viewport": "width=device-width, initial-scale=1", "meta": [], "link": [], "style": [], "script": [] } };
const metaMixin = {
  created() {
    const instance = vue_cjs_prod.getCurrentInstance();
    if (!instance) {
      return;
    }
    const options = instance.type;
    if (!options || !("head" in options)) {
      return;
    }
    const nuxtApp = useNuxtApp();
    const source = typeof options.head === "function" ? vue_cjs_prod.computed(() => options.head(nuxtApp)) : options.head;
    useHead$1(source);
  }
};
const _bcc70762 = defineNuxtPlugin((nuxtApp) => {
  useHead$1(vue_cjs_prod.markRaw(metaConfig.globalMeta));
  nuxtApp.vueApp.mixin(metaMixin);
  for (const name in Components) {
    nuxtApp.vueApp.component(name, Components[name]);
  }
});
const interpolatePath = (route, match) => {
  return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a2;
    return ((_a2 = route.params[r.slice(1)]) == null ? void 0 : _a2.toString()) || "";
  });
};
const generateRouteKey = (override, routeProps) => {
  var _a2;
  const matchedRoute = routeProps.route.matched.find((m) => m.components.default === routeProps.Component.type);
  const source = (_a2 = override != null ? override : matchedRoute == null ? void 0 : matchedRoute.meta.key) != null ? _a2 : interpolatePath(routeProps.route, matchedRoute);
  return typeof source === "function" ? source(routeProps.route) : source;
};
const wrapInKeepAlive = (props, children) => {
  return { default: () => children };
};
const Fragment = {
  setup(_props, { slots }) {
    return () => {
      var _a2;
      return (_a2 = slots.default) == null ? void 0 : _a2.call(slots);
    };
  }
};
const _wrapIf = (component, props, slots) => {
  return { default: () => props ? vue_cjs_prod.h(component, props === true ? {} : props, slots) : vue_cjs_prod.h(Fragment, {}, slots) };
};
const isNestedKey = Symbol("isNested");
const NuxtPage = vue_cjs_prod.defineComponent({
  name: "NuxtPage",
  props: {
    pageKey: {
      type: [Function, String],
      default: null
    }
  },
  setup(props) {
    const nuxtApp = useNuxtApp();
    const isNested = vue_cjs_prod.inject(isNestedKey, false);
    vue_cjs_prod.provide(isNestedKey, true);
    return () => {
      return vue_cjs_prod.h(vueRouter_cjs_prod.RouterView, {}, {
        default: (routeProps) => {
          var _a2;
          return routeProps.Component && _wrapIf(vue_cjs_prod.Transition, (_a2 = routeProps.route.meta.pageTransition) != null ? _a2 : defaultPageTransition, wrapInKeepAlive(routeProps.route.meta.keepalive, isNested && nuxtApp.isHydrating ? vue_cjs_prod.h(routeProps.Component, { key: generateRouteKey(props.pageKey, routeProps) }) : vue_cjs_prod.h(vue_cjs_prod.Suspense, {
            onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
            onResolve: () => nuxtApp.callHook("page:finish", routeProps.Component)
          }, { default: () => vue_cjs_prod.h(routeProps.Component, { key: generateRouteKey(props.pageKey, routeProps) }) }))).default();
        }
      });
    };
  }
});
const defaultPageTransition = { name: "page", mode: "out-in" };
const _imports_0$4 = publicAssetsURL(`images/nav-floppy.png`);
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const meta$a = void 0;
const meta$9 = void 0;
const _imports_0$3 = publicAssetsURL(`images/nav-search.png`);
const menuList = [
  {
    year: 2022,
    list: [
      {
        type: "post",
        thumbnail: " /images/github.png",
        highlight: true,
        name: "New-Blog",
        title: "New-Blog",
        date: "2022-05-15T11:37:35.417Z",
        birthtime: "2022-05-15T11:33:45.202Z"
      },
      {
        type: "post",
        thumbnail: void 0,
        highlight: false,
        name: "px\u81EA\u52A8\u8F6C\u6362\u6210rem",
        title: "px\u81EA\u52A8\u8F6C\u6362\u6210rem",
        date: "2022-05-15T11:33:14.565Z",
        birthtime: "2022-05-15T11:32:10.858Z"
      },
      {
        type: "post",
        thumbnail: void 0,
        highlight: false,
        name: "JavaScript-\u76D1\u542C\u622A\u56FE",
        title: "JavaScript-\u76D1\u542C\u622A\u56FE",
        date: "2022-05-15T11:32:23.698Z",
        birthtime: "2022-05-15T11:17:01.450Z"
      },
      {
        type: "post",
        thumbnail: void 0,
        highlight: false,
        name: "Vue-Class\u7684\u663E\u793A",
        title: "Vue-Class\u7684\u663E\u793A",
        date: "2022-05-15T11:32:16.915Z",
        birthtime: "2022-05-15T11:20:41.056Z"
      },
      {
        type: "post",
        thumbnail: void 0,
        highlight: false,
        name: "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",
        title: "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",
        date: "2022-05-15T11:27:17.971Z",
        birthtime: "2022-05-15T11:23:43.019Z"
      },
      {
        type: "post",
        thumbnail: " /images/vue.png",
        highlight: true,
        name: "test",
        title: "test",
        date: "2022-05-15T10:57:34.423Z",
        birthtime: "2022-05-13T03:48:42.732Z"
      }
    ]
  }
];
const query = vue_cjs_prod.ref("");
const isSearching = vue_cjs_prod.ref(false);
const searchResult = vue_cjs_prod.shallowRef([]);
const searcher = createSearch(menuList);
function createSearch(data) {
  const options = {
    includeScore: false,
    includeMatches: true,
    threshold: 0.3,
    keys: ["list.name"]
  };
  const fuse = new Fuse(data, options);
  async function search(query2) {
    return await Array.from(/* @__PURE__ */ new Set([...fuse.search(query2)])).map((i) => ({ item: i.item, matches: i.matches }));
  }
  return {
    search
  };
}
const _sfc_main$t = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    vue_cjs_prod.onMounted(async () => {
      query.value = String(route.query.search || "");
    });
    vue_cjs_prod.watch(() => query.value, excuteSearch);
    async function excuteSearch() {
      isSearching.value = true;
      try {
        searchResult.value = await searcher.search(query.value);
        vue_cjs_prod.nextTick(() => isSearching.value = false);
      } catch (e) {
        console.error(e);
      }
      await router.replace({
        query: query.value ? {
          search: query.value
        } : void 0
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><div class="search-bar"><input id="search"${serverRenderer.exports.ssrRenderAttr("value", vue_cjs_prod.unref(query))} type="search" class="search-input" placeholder="Begin typing to search..."><img class="search-icon"${serverRenderer.exports.ssrRenderAttr("src", _imports_0$3)} alt="Search"></div></div>`);
    };
  }
});
const _sfc_setup$t = _sfc_main$t.setup;
_sfc_main$t.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Search.vue");
  return _sfc_setup$t ? _sfc_setup$t(props, ctx) : void 0;
};
const Search = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$t
}, Symbol.toStringTag, { value: "Module" }));
function tryOnScopeDispose(fn) {
  if (vue_cjs_prod.getCurrentScope()) {
    vue_cjs_prod.onScopeDispose(fn);
    return true;
  }
  return false;
}
const isClient = false;
const isString = (val) => typeof val === "string";
const noop = () => {
};
const REGEX_PARSE = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/;
const REGEX_FORMAT = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g;
const formatDate$1 = (date, formatStr) => {
  const years = date.getFullYear();
  const month = date.getMonth();
  const days = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();
  const milliseconds = date.getMilliseconds();
  const day = date.getDay();
  const matches = {
    YY: String(years).slice(-2),
    YYYY: years,
    M: month + 1,
    MM: `${month + 1}`.padStart(2, "0"),
    D: String(days),
    DD: `${days}`.padStart(2, "0"),
    H: String(hours),
    HH: `${hours}`.padStart(2, "0"),
    h: `${hours % 12 || 12}`.padStart(1, "0"),
    hh: `${hours % 12 || 12}`.padStart(2, "0"),
    m: String(minutes),
    mm: `${minutes}`.padStart(2, "0"),
    s: String(seconds),
    ss: `${seconds}`.padStart(2, "0"),
    SSS: `${milliseconds}`.padStart(3, "0"),
    d: day
  };
  return formatStr.replace(REGEX_FORMAT, (match, $1) => $1 || matches[match]);
};
const normalizeDate = (date) => {
  if (date === null)
    return new Date(NaN);
  if (date === void 0)
    return new Date();
  if (date instanceof Date)
    return new Date(date);
  if (typeof date === "string" && !/Z$/i.test(date)) {
    const d = date.match(REGEX_PARSE);
    if (d) {
      const m = d[2] - 1 || 0;
      const ms = (d[7] || "0").substring(0, 3);
      return new Date(d[1], m, d[3] || 1, d[4] || 0, d[5] || 0, d[6] || 0, ms);
    }
  }
  return new Date(date);
};
function useDateFormat(date, formatStr = "HH:mm:ss") {
  return vue_cjs_prod.computed(() => formatDate$1(normalizeDate(vue_cjs_prod.unref(date)), vue_cjs_prod.unref(formatStr)));
}
function useIntervalFn(cb, interval = 1e3, options = {}) {
  const {
    immediate = true,
    immediateCallback = false
  } = options;
  let timer = null;
  const isActive = vue_cjs_prod.ref(false);
  function clean() {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }
  function pause() {
    isActive.value = false;
    clean();
  }
  function resume() {
    if (interval <= 0)
      return;
    isActive.value = true;
    if (immediateCallback)
      cb();
    clean();
    timer = setInterval(cb, vue_cjs_prod.unref(interval));
  }
  if (immediate && isClient)
    resume();
  if (vue_cjs_prod.isRef(interval)) {
    const stopWatch = vue_cjs_prod.watch(interval, () => {
      if (immediate && isClient)
        resume();
    });
    tryOnScopeDispose(stopWatch);
  }
  tryOnScopeDispose(pause);
  return {
    isActive,
    pause,
    resume
  };
}
function unrefElement(elRef) {
  var _a2;
  const plain = vue_cjs_prod.unref(elRef);
  return (_a2 = plain == null ? void 0 : plain.$el) != null ? _a2 : plain;
}
const defaultWindow = void 0;
function useEventListener(...args) {
  let target;
  let event;
  let listener;
  let options;
  if (isString(args[0])) {
    [event, listener, options] = args;
    target = defaultWindow;
  } else {
    [target, event, listener, options] = args;
  }
  if (!target)
    return noop;
  let cleanup = noop;
  const stopWatch = vue_cjs_prod.watch(() => unrefElement(target), (el) => {
    cleanup();
    if (!el)
      return;
    el.addEventListener(event, listener, options);
    cleanup = () => {
      el.removeEventListener(event, listener, options);
      cleanup = noop;
    };
  }, { immediate: true, flush: "post" });
  const stop = () => {
    stopWatch();
    cleanup();
  };
  tryOnScopeDispose(stop);
  return stop;
}
const _global = typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
const globalKey = "__vueuse_ssr_handlers__";
_global[globalKey] = _global[globalKey] || {};
_global[globalKey];
function useRafFn(fn, options = {}) {
  const {
    immediate = true,
    window: window2 = defaultWindow
  } = options;
  const isActive = vue_cjs_prod.ref(false);
  let rafId = null;
  function loop() {
    if (!isActive.value || !window2)
      return;
    fn();
    rafId = window2.requestAnimationFrame(loop);
  }
  function resume() {
    if (!isActive.value && window2) {
      isActive.value = true;
      loop();
    }
  }
  function pause() {
    isActive.value = false;
    if (rafId != null && window2) {
      window2.cancelAnimationFrame(rafId);
      rafId = null;
    }
  }
  if (immediate)
    resume();
  tryOnScopeDispose(pause);
  return {
    isActive,
    pause,
    resume
  };
}
var __defProp$5 = Object.defineProperty;
var __getOwnPropSymbols$5 = Object.getOwnPropertySymbols;
var __hasOwnProp$5 = Object.prototype.hasOwnProperty;
var __propIsEnum$5 = Object.prototype.propertyIsEnumerable;
var __defNormalProp$5 = (obj, key, value) => key in obj ? __defProp$5(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues$5 = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp$5.call(b, prop))
      __defNormalProp$5(a, prop, b[prop]);
  if (__getOwnPropSymbols$5)
    for (var prop of __getOwnPropSymbols$5(b)) {
      if (__propIsEnum$5.call(b, prop))
        __defNormalProp$5(a, prop, b[prop]);
    }
  return a;
};
function useNow(options = {}) {
  const {
    controls: exposeControls = false,
    interval = "requestAnimationFrame"
  } = options;
  const now = vue_cjs_prod.ref(new Date());
  const update = () => now.value = new Date();
  const controls = interval === "requestAnimationFrame" ? useRafFn(update, { immediate: true }) : useIntervalFn(update, interval, { immediate: true });
  if (exposeControls) {
    return __spreadValues$5({
      now
    }, controls);
  } else {
    return now;
  }
}
const formatDate = (time = useNow(), format = "MM-DD") => {
  return useDateFormat(time, format).value;
};
const postDate = (time = new Date(), showYear = true) => {
  return showYear ? `${new Date(time).toDateString().split(" ")[1]}  ${new Date(time).getDate()},  ${new Date(time).getFullYear()}` : `${new Date(time).toDateString().split(" ")[1]}  ${new Date(time).getDate()}`;
};
const _sfc_main$s = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  props: {
    yearOnly: { type: Boolean, default: false },
    isNew: { type: Boolean, default: false },
    showThumbnail: { type: Boolean, default: false },
    matches: { default: () => [] },
    node: { default: () => {
    } },
    timeType: { default: "" }
  },
  setup(__props) {
    let title = vue_cjs_prod.ref("");
    if (__props.matches.length > 0) {
      if (__props.matches.length === 1) {
        __props.matches.forEach((v) => {
          const s = __props.node.title.slice(0, v[0]);
          const m = __props.node.title.slice(v[0], v[1] + 1);
          const e = __props.node.title.slice(v[1] + 1);
          title.value += `${s}<strong class="highlighted">${m}</strong>${e}`;
        });
      } else {
        let index2 = 0;
        __props.matches.forEach((v, k) => {
          const s = __props.node.title.slice(index2, v[0]);
          const m = __props.node.title.slice(v[0], v[1] + 1);
          index2 = v[0] + 1;
          if (k === __props.matches.length) {
            const e = __props.node.title.slice(v[1] + 1);
            title.value += `${s}<strong class="highlighted">${m}</strong>${e}`;
          }
          title.value += `${s}<strong class="highlighted">${m}</strong>`;
        });
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><section><div class="posts">`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
        key: __props.node.title,
        to: `/posts/${__props.node.title}`,
        class: __props.isNew ? "post new" : "post"
      }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="flex" style="${serverRenderer.exports.ssrRenderStyle({ alignItems: "center" })}"${_scopeId}>`);
            if (__props.node.thumbnail && __props.showThumbnail) {
              _push2(`<img${serverRenderer.exports.ssrRenderAttr("src", __props.node.thumbnail)} w6 mr4 loading="lazy"${_scopeId}>`);
            } else {
              _push2(`<!---->`);
            }
            if (title.value) {
              _push2(`<h3${_scopeId}>${title.value}</h3>`);
            } else {
              _push2(`<h3${_scopeId}>${serverRenderer.exports.ssrInterpolate(__props.node.title)}</h3>`);
            }
            if (__props.isNew) {
              _push2(`<span class="new-badge"${_scopeId}> New!</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</span><div${_scopeId}><time${_scopeId}>${serverRenderer.exports.ssrInterpolate(__props.timeType === "post" ? vue_cjs_prod.unref(postDate)(__props.node.date, false) : vue_cjs_prod.unref(formatDate)(__props.node.date, __props.yearOnly ? "YYYY" : void 0))}</time></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("span", {
                class: "flex",
                style: { alignItems: "center" }
              }, [
                __props.node.thumbnail && __props.showThumbnail ? (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("img", {
                  key: 0,
                  src: __props.node.thumbnail,
                  w6: "",
                  mr4: "",
                  loading: "lazy"
                }, null, 8, ["src"])) : vue_cjs_prod.createCommentVNode("", true),
                title.value ? (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("h3", {
                  key: 1,
                  innerHTML: title.value
                }, null, 8, ["innerHTML"])) : (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("h3", { key: 2 }, vue_cjs_prod.toDisplayString(__props.node.title), 1)),
                __props.isNew ? (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("span", {
                  key: 3,
                  class: "new-badge"
                }, " New!")) : vue_cjs_prod.createCommentVNode("", true)
              ]),
              vue_cjs_prod.createVNode("div", null, [
                vue_cjs_prod.createVNode("time", null, vue_cjs_prod.toDisplayString(__props.timeType === "post" ? vue_cjs_prod.unref(postDate)(__props.node.date, false) : vue_cjs_prod.unref(formatDate)(__props.node.date, __props.yearOnly ? "YYYY" : void 0)), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section></div>`);
    };
  }
});
const _sfc_setup$s = _sfc_main$s.setup;
_sfc_main$s.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Posts.vue");
  return _sfc_setup$s ? _sfc_setup$s(props, ctx) : void 0;
};
const Posts = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$s
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$r = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Search = _sfc_main$t;
      const _component_Posts = _sfc_main$s;
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><article class="blog-page"><header><div class="container"><h1>Articles</h1><p class="description"> Tutorials, technical articles, snippets, reference materials, and all development-related resources I&#39;ve written. See `);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, { to: "/notes" }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Notes `);
          } else {
            return [
              vue_cjs_prod.createTextVNode(" Notes ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` for everything else. </p></div></header><section><div class="container">`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_Search, null, null, _parent));
      if (vue_cjs_prod.unref(isSearching)) {
        _push(`<div i-carbon-circle-dash w-7 h-7 animate-spin mt5 mxa></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<section>`);
      if (vue_cjs_prod.unref(query)) {
        _push(`<!--[-->`);
        if (!vue_cjs_prod.unref(isSearching) && vue_cjs_prod.unref(searchResult).length > 0) {
          _push(`<!--[-->`);
          serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(searchResult), (v) => {
            _push(`<!--[--><h2 class="main-header"><span>${serverRenderer.exports.ssrInterpolate(v.item.year)}</span></h2><!--[-->`);
            serverRenderer.exports.ssrRenderList(v.matches, (item) => {
              _push(serverRenderer.exports.ssrRenderComponent(_component_Posts, {
                key: item.value,
                node: { title: item.value, date: v.item.list[item.refIndex].birthtime },
                matches: item.indices,
                "time-type": "post"
              }, null, _parent));
            });
            _push(`<!--]--><!--]-->`);
          });
          _push(`<!--]-->`);
        } else if (!vue_cjs_prod.unref(isSearching)) {
          _push(`<p mt8> Sorry, nothing matched that search. </p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<!--]-->`);
      } else {
        _push(`<!--[-->`);
        serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(menuList), (v) => {
          _push(`<!--[--><h2 class="main-header"><span>${serverRenderer.exports.ssrInterpolate(v.year)}</span></h2><!--[-->`);
          serverRenderer.exports.ssrRenderList(v.list, (item) => {
            _push(serverRenderer.exports.ssrRenderComponent(_component_Posts, {
              key: item.name,
              node: item,
              "time-type": "post"
            }, null, _parent));
          });
          _push(`<!--]--><!--]-->`);
        });
        _push(`<!--]-->`);
      }
      _push(`</section></div></section></article></div>`);
    };
  }
});
const _sfc_setup$r = _sfc_main$r.setup;
_sfc_main$r.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/articles.vue");
  return _sfc_setup$r ? _sfc_setup$r(props, ctx) : void 0;
};
const meta$8 = void 0;
function useConfig() {
  const config = useState("config", () => ({
    siteUrl: "https://localhost",
    siteLogo: "/images/logo.jpeg",
    github: "https://github.com/Soya-xy",
    description: "1",
    image: "1",
    article: "1",
    summary: "1",
    schemaOrgJSONLD: {},
    author: "Soya",
    title: "Soya",
    menu: [{
      label: "Articles",
      icon: "/images/nav-blog.png",
      url: "/articles"
    }, {
      label: "Projects",
      icon: "/images/nav-dos.png",
      url: "/projects"
    }, {
      label: "About me",
      icon: "/images/nav-floppy.png",
      url: "/about"
    }],
    socialMenu: [
      {
        label: "Twitter",
        icon: "/images/nav-twitter.png",
        url: "https://twitter.com/SoyaXyo"
      },
      {
        label: "Github",
        icon: "/images/nav-github.png",
        url: "https://github.com/Soya-xy"
      }
    ],
    enableThemeSwitch: true,
    latestNum: 10,
    highlightNum: 10
  }));
  return {
    config
  };
}
const _imports_0$2 = publicAssetsURL(`images/nav-github.png`);
const _sfc_main$q = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { config } = useConfig();
    const { data } = ([__temp, __restore] = vue_cjs_prod.withAsyncContext(() => useFetch("https://api.github.com/users/Soya-xy")), __temp = await __temp, __restore(), __temp);
    const edges = menuList[0].list.filter((item, index2) => index2 <= config.value.latestNum);
    const highlighted = vue_cjs_prod.ref([]);
    menuList[0].list.forEach((item) => {
      if (item.highlight && highlighted.value.length <= config.value.highlightNum)
        highlighted.value.push(item);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Posts = _sfc_main$s;
      _push(`<article${serverRenderer.exports.ssrRenderAttrs(vue_cjs_prod.mergeProps({ class: "hero" }, _attrs))}><header><div class="container"><div class="flex-content"><div><h1>Hey, I&#39;m Soya.</h1><p class="subtitle small"> I&#39;m a Front End Developer in China. I love building open-source `);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, { to: "/projects" }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Projects `);
          } else {
            return [
              vue_cjs_prod.createTextVNode(" Projects ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` and `);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, { to: "/blog" }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Writing `);
          } else {
            return [
              vue_cjs_prod.createTextVNode(" Writing ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` about what I learn. This website is my digital garden\u2014a compendium of the things I&#39;ve learned and created over the years. </p></div><img${serverRenderer.exports.ssrRenderAttr("src", vue_cjs_prod.unref(config).siteLogo)} alt="Web Logo" class="main-image"></div><p class="hero-buttons">`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
        to: "/about",
        class: "hero-button"
      }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${serverRenderer.exports.ssrRenderAttr("src", _imports_0$4)} alt="Me"${_scopeId}> More about me `);
          } else {
            return [
              vue_cjs_prod.createVNode("img", {
                src: _imports_0$4,
                alt: "Me"
              }),
              vue_cjs_prod.createTextVNode(" More about me ")
            ];
          }
        }),
        _: 1
      }, _parent));
      if (vue_cjs_prod.unref(data)) {
        _push(`<a${serverRenderer.exports.ssrRenderAttr("href", vue_cjs_prod.unref(config).github)} target="_blank" class="hero-button" rel="noreferrer"><img${serverRenderer.exports.ssrRenderAttr("src", _imports_0$2)} alt="GitHub"><span class="bright">${serverRenderer.exports.ssrInterpolate(Number(vue_cjs_prod.unref(data).followers).toLocaleString())}</span> followers on GitHub </a>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</p></div></header><div class="container"><h2 class="main-header"><span>Latest Articles</span>`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, { to: "/blog" }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` View All `);
          } else {
            return [
              vue_cjs_prod.createTextVNode(" View All ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</h2><!--[-->`);
      serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(edges), (item, index2) => {
        _push(serverRenderer.exports.ssrRenderComponent(_component_Posts, {
          key: index2,
          node: item,
          "is-new": index2 === 0
        }, null, _parent));
      });
      _push(`<!--]--><h2 class="main-header"><span>Highlights</span>`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, { to: "/blog" }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` View All `);
          } else {
            return [
              vue_cjs_prod.createTextVNode(" View All ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</h2><!--[-->`);
      serverRenderer.exports.ssrRenderList(highlighted.value, (item, index2) => {
        _push(serverRenderer.exports.ssrRenderComponent(_component_Posts, {
          key: index2,
          node: item,
          "year-only": "",
          "show-thumbnail": ""
        }, null, _parent));
      });
      _push(`<!--]--><h2 class="main-header"> Contact </h2><div><p><b>Wechat:</b> <span class="tag">SoyaXy</span></p><p><b>Email:</b> <span class="tag">soyayiyi@gmail.com</span></p></div></div></article>`);
    };
  }
});
const _sfc_setup$q = _sfc_main$q.setup;
_sfc_main$q.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Introduce.vue");
  return _sfc_setup$q ? _sfc_setup$q(props, ctx) : void 0;
};
const Introduce = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$q
}, Symbol.toStringTag, { value: "Module" }));
const meta$7 = void 0;
const meta$6 = void 0;
const meta$5 = void 0;
const meta$4 = void 0;
const meta$3 = void 0;
const meta$2 = void 0;
const meta$1 = void 0;
const projectsList = [
  {
    name: "Soya",
    repoName: "Soya.xy",
    tagline: "The source of this website.",
    image: "/images/nuxt.png",
    url: "https://xiaoyio.com",
    writeup: "",
    description: "A static site generator for Nuxt.js."
  }
];
const _sfc_main$p = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { config } = useConfig();
    const { data } = ([__temp, __restore] = vue_cjs_prod.withAsyncContext(() => useFetch(`https://api.github.com/users/${config.value.github.split("/")[3]}/repos`)), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<article${serverRenderer.exports.ssrRenderAttrs(_attrs)}><header><div class="container"><h1>Projects</h1><p class="description"> A few highlights of my open-source projects. View them all <a${serverRenderer.exports.ssrRenderAttr("href", vue_cjs_prod.unref(config).github)}>on GitHub</a>. </p></div></header><section class="projects large container"><!--[-->`);
      serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(projectsList), (project) => {
        var _a2;
        _push(`<div class="project"><h2>${serverRenderer.exports.ssrInterpolate(project.name)}</h2>`);
        if (project.image) {
          _push(`<img${serverRenderer.exports.ssrRenderAttr("src", project.image)}${serverRenderer.exports.ssrRenderAttr("alt", project.name)}>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="links tags">`);
        if (project.writeup) {
          _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
            to: project.writeup
          }, {
            default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Write-up `);
              } else {
                return [
                  vue_cjs_prod.createTextVNode(" Write-up ")
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<a${serverRenderer.exports.ssrRenderAttr("href", `https://github.com/taniarascia/${project.repoName}`)} target="_blank" rel="noreferrer"> Source </a>`);
        if (project.url) {
          _push(`<a href="{project.url}" target="_blank" rel="noreferrer"> Demo </a>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><p class="description">${serverRenderer.exports.ssrInterpolate(project.tagline)}</p><div class="stars"><img${serverRenderer.exports.ssrRenderAttr("src", _imports_0$2)} alt="Stargazers"><span>`);
        if (vue_cjs_prod.unref(data).length > 0) {
          _push(`<a${serverRenderer.exports.ssrRenderAttr("href", `https://github.com/taniarascia/${project.repoName}/stargazers`)}>${serverRenderer.exports.ssrInterpolate(Number(((_a2 = vue_cjs_prod.unref(data).find((repo) => repo.name === project.name)) == null ? void 0 : _a2.stargazers_count) || 0).toLocaleString())}</a>`);
        } else {
          _push(`<!---->`);
        }
        _push(` stars on GitHub </span><span></span></div></div>`);
      });
      _push(`<!--]--></section></article>`);
    };
  }
});
const _sfc_setup$p = _sfc_main$p.setup;
_sfc_main$p.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/projects.vue");
  return _sfc_setup$p ? _sfc_setup$p(props, ctx) : void 0;
};
const meta = void 0;
const routes = [
  {
    name: "404",
    path: "/:catchAll(.*)*",
    file: "/Users/sys/Desktop/soya.xy/pages/404.vue",
    children: [],
    meta: meta$a,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return _404$1;
    })
  },
  {
    name: "about",
    path: "/about",
    file: "/Users/sys/Desktop/soya.xy/pages/about.md",
    children: [],
    meta: meta$9,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return about;
    })
  },
  {
    name: "articles",
    path: "/articles",
    file: "/Users/sys/Desktop/soya.xy/pages/articles.vue",
    children: [],
    meta: meta$8,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return articles;
    })
  },
  {
    name: "index",
    path: "/",
    file: "/Users/sys/Desktop/soya.xy/pages/index.vue",
    children: [],
    meta: meta$7,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return index$1;
    })
  },
  {
    name: "posts-JavaScript-\u76D1\u542C\u622A\u56FE",
    path: "/posts/JavaScript-%E7%9B%91%E5%90%AC%E6%88%AA%E5%9B%BE",
    file: "/Users/sys/Desktop/soya.xy/pages/posts/JavaScript-\u76D1\u542C\u622A\u56FE.md",
    children: [],
    meta: meta$6,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return JavaScript_____;
    })
  },
  {
    name: "posts-New-Blog",
    path: "/posts/New-Blog",
    file: "/Users/sys/Desktop/soya.xy/pages/posts/New-Blog.md",
    children: [],
    meta: meta$5,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return NewBlog;
    })
  },
  {
    name: "posts-Vue-Class\u7684\u663E\u793A",
    path: "/posts/Vue-Class%E7%9A%84%E6%98%BE%E7%A4%BA",
    file: "/Users/sys/Desktop/soya.xy/pages/posts/Vue-Class\u7684\u663E\u793A.md",
    children: [],
    meta: meta$4,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return VueClass___;
    })
  },
  {
    name: "posts-px\u81EA\u52A8\u8F6C\u6362\u6210rem",
    path: "/posts/px%E8%87%AA%E5%8A%A8%E8%BD%AC%E6%8D%A2%E6%88%90rem",
    file: "/Users/sys/Desktop/soya.xy/pages/posts/px\u81EA\u52A8\u8F6C\u6362\u6210rem.md",
    children: [],
    meta: meta$3,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return px_____rem;
    })
  },
  {
    name: "posts-test",
    path: "/posts/test",
    file: "/Users/sys/Desktop/soya.xy/pages/posts/test.md",
    children: [],
    meta: meta$2,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return test;
    })
  },
  {
    name: "posts-\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",
    path: "/posts/%E5%B0%8F%E7%A8%8B%E5%BA%8F%E7%99%BB%E5%BD%95%E6%B5%81%E7%A8%8B%E4%B8%8E%E5%88%A4%E6%96%AD%E7%99%BB%E5%BD%95%E4%BF%A1%E6%81%AF%E5%A4%B1%E6%95%88",
    file: "/Users/sys/Desktop/soya.xy/pages/posts/\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548.md",
    children: [],
    meta: meta$1,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return ________________;
    })
  },
  {
    name: "projects",
    path: "/projects",
    file: "/Users/sys/Desktop/soya.xy/pages/projects.vue",
    children: [],
    meta,
    alias: [],
    component: () => Promise.resolve().then(function() {
      return projects;
    })
  }
];
const configRouterOptions = {};
const routerOptions = __spreadValues({}, configRouterOptions);
const globalMiddleware = [];
const namedMiddleware = {};
const _585c4ed5 = defineNuxtPlugin(async (nuxtApp) => {
  nuxtApp.vueApp.component("NuxtPage", NuxtPage);
  nuxtApp.vueApp.component("NuxtNestedPage", NuxtPage);
  nuxtApp.vueApp.component("NuxtChild", NuxtPage);
  const baseURL2 = useRuntimeConfig().app.baseURL;
  const routerHistory = vueRouter_cjs_prod.createMemoryHistory(baseURL2);
  const initialURL = nuxtApp.ssrContext.url;
  const router = vueRouter_cjs_prod.createRouter(__spreadProps(__spreadValues({}, routerOptions), {
    history: routerHistory,
    routes
  }));
  nuxtApp.vueApp.use(router);
  const previousRoute = vue_cjs_prod.shallowRef(router.currentRoute.value);
  router.afterEach((_to, from) => {
    previousRoute.value = from;
  });
  Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
    get: () => previousRoute.value
  });
  const route = {};
  for (const key in router.currentRoute.value) {
    route[key] = vue_cjs_prod.computed(() => router.currentRoute.value[key]);
  }
  const _activeRoute = vue_cjs_prod.shallowRef(router.resolve(initialURL));
  const syncCurrentRoute = () => {
    _activeRoute.value = router.currentRoute.value;
  };
  nuxtApp.hook("page:finish", syncCurrentRoute);
  router.afterEach((to, from) => {
    var _a2, _b2, _c, _d;
    if (((_b2 = (_a2 = to.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d = (_c = from.matched[0]) == null ? void 0 : _c.components) == null ? void 0 : _d.default)) {
      syncCurrentRoute();
    }
  });
  const activeRoute = {};
  for (const key in _activeRoute.value) {
    activeRoute[key] = vue_cjs_prod.computed(() => _activeRoute.value[key]);
  }
  nuxtApp._route = vue_cjs_prod.reactive(route);
  nuxtApp._activeRoute = vue_cjs_prod.reactive(activeRoute);
  nuxtApp._middleware = nuxtApp._middleware || {
    global: [],
    named: {}
  };
  useError();
  router.afterEach(async (to) => {
    if (to.matched.length === 0) {
      callWithNuxt(nuxtApp, throwError, [createError({
        statusCode: 404,
        statusMessage: `Page not found: ${to.fullPath}`
      })]);
    } else if (to.matched[0].name === "404" && nuxtApp.ssrContext) {
      nuxtApp.ssrContext.res.statusCode = 404;
    }
  });
  try {
    if (true) {
      await router.push(initialURL);
    }
    await router.isReady();
  } catch (error2) {
    callWithNuxt(nuxtApp, throwError, [error2]);
  }
  router.beforeEach(async (to, from) => {
    var _a2;
    to.meta = vue_cjs_prod.reactive(to.meta);
    nuxtApp._processingMiddleware = true;
    const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
    for (const component of to.matched) {
      const componentMiddleware = component.meta.middleware;
      if (!componentMiddleware) {
        continue;
      }
      if (Array.isArray(componentMiddleware)) {
        for (const entry2 of componentMiddleware) {
          middlewareEntries.add(entry2);
        }
      } else {
        middlewareEntries.add(componentMiddleware);
      }
    }
    for (const entry2 of middlewareEntries) {
      const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_a2 = namedMiddleware[entry2]) == null ? void 0 : _a2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
      const result = await callWithNuxt(nuxtApp, middleware, [to, from]);
      {
        if (result === false || result instanceof Error) {
          const error2 = result || createError({
            statusMessage: `Route navigation aborted: ${initialURL}`
          });
          return callWithNuxt(nuxtApp, throwError, [error2]);
        }
      }
      if (result || result === false) {
        return result;
      }
    }
  });
  router.afterEach(async (to) => {
    delete nuxtApp._processingMiddleware;
    {
      const currentURL = to.fullPath || "/";
      if (!isEqual(currentURL, initialURL)) {
        await callWithNuxt(nuxtApp, navigateTo, [currentURL]);
      }
    }
  });
  nuxtApp.hooks.hookOnce("app:created", async () => {
    try {
      await router.replace(__spreadProps(__spreadValues({}, router.resolve(initialURL)), {
        force: true
      }));
    } catch (error2) {
      callWithNuxt(nuxtApp, throwError, [error2]);
    }
  });
  return { provide: { router } };
});
function useTheme() {
  let index2 = 0;
  const theme = useState("theme", () => "default");
  const themeList = ["default", "light", "sepia"];
  function switchTheme() {
    index2++;
    theme.value = themeList[index2];
    if (index2 >= themeList.length)
      index2 = 0;
  }
  return {
    theme,
    switchTheme
  };
}
const preference = "system";
const script = 'const w=window,de=document.documentElement,knownColorSchemes=["dark","light"],preference=window.localStorage.getItem("nuxt-color-mode")||"system";let value=preference==="system"?getColorScheme():preference;const forcedColorMode=de.getAttribute("data-color-mode-forced");forcedColorMode&&(value=forcedColorMode),addClass(value),w["__NUXT_COLOR_MODE__"]={preference,value,getColorScheme,addClass,removeClass};function addClass(e){const o=""+e+"";de.classList?de.classList.add(o):de.className+=" "+o}function removeClass(e){const o=""+e+"";de.classList?de.classList.remove(o):de.className=de.className.replace(new RegExp(o,"g"),"")}function prefersColorScheme(e){return w.matchMedia("(prefers-color-scheme"+e+")")}function getColorScheme(){if(w.matchMedia&&prefersColorScheme("").media!=="not all"){for(const e of knownColorSchemes)if(prefersColorScheme(":"+e).matches)return e}return"light"}\n';
const plugin_3762bbcf = defineNuxtPlugin((nuxtApp) => {
  const colorMode = useState("color-mode", () => vue_cjs_prod.reactive({
    preference,
    value: preference,
    unknown: true,
    forced: false
  })).value;
  const htmlAttrs = {};
  {
    useHead$1({
      htmlAttrs,
      script: [{ children: script }]
    });
  }
  useRouter().afterEach((to) => {
    const forcedColorMode = to.meta.colorMode;
    if (forcedColorMode && forcedColorMode !== "system") {
      colorMode.value = htmlAttrs["data-color-mode-forced"] = forcedColorMode;
      colorMode.forced = true;
    } else if (forcedColorMode === "system") {
      console.warn("You cannot force the colorMode to system at the page level.");
    }
  });
  nuxtApp.provide("colorMode", colorMode);
});
const unocss_3f399228 = () => {
};
const _plugins = [
  preload,
  componentsPlugin_ec27b3c8,
  vueuseHead_8f7ea34a,
  _bcc70762,
  _585c4ed5,
  plugin_3762bbcf,
  unocss_3f399228
];
const _sfc_main$o = {
  __ssrInlineRender: true,
  props: {
    appName: {
      type: String,
      default: "Nuxt"
    },
    version: {
      type: String,
      default: ""
    },
    statusCode: {
      type: String,
      default: "404"
    },
    statusMessage: {
      type: String,
      default: "Not Found"
    },
    description: {
      type: String,
      default: "Sorry, the page you are looking for could not be found."
    },
    backHome: {
      type: String,
      default: "Go back home"
    }
  },
  setup(__props) {
    const props = __props;
    useHead$1({
      title: `${props.statusCode} - ${props.statusMessage} | ${props.appName}`,
      script: [],
      style: [
        {
          children: `*,:before,:after{-webkit-box-sizing:border-box;box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}*{--tw-ring-inset:var(--tw-empty, );--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(14, 165, 233, .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000}:root{-moz-tab-size:4;-o-tab-size:4;tab-size:4}a{color:inherit;text-decoration:inherit}body{margin:0;font-family:inherit;line-height:inherit}html{-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5}h1,p{margin:0}h1{font-size:inherit;font-weight:inherit}`
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(vue_cjs_prod.mergeProps({ class: "font-sans antialiased bg-white dark:bg-black text-black dark:text-white grid min-h-screen place-content-center overflow-hidden" }, _attrs))} data-v-49db1bb2><div class="fixed left-0 right-0 spotlight z-10" data-v-49db1bb2></div><div class="max-w-520px text-center z-20" data-v-49db1bb2><h1 class="text-8xl sm:text-10xl font-medium mb-8" data-v-49db1bb2>${serverRenderer.exports.ssrInterpolate(__props.statusCode)}</h1><p class="text-xl px-8 sm:px-0 sm:text-4xl font-light mb-16 leading-tight" data-v-49db1bb2>${serverRenderer.exports.ssrInterpolate(__props.description)}</p><div class="w-full flex items-center justify-center" data-v-49db1bb2>`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "gradient-border text-md sm:text-xl py-2 px-4 sm:py-3 sm:px-6 cursor-pointer"
      }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${serverRenderer.exports.ssrInterpolate(__props.backHome)}`);
          } else {
            return [
              vue_cjs_prod.createTextVNode(vue_cjs_prod.toDisplayString(__props.backHome), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$o = _sfc_main$o.setup;
_sfc_main$o.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/.pnpm/@nuxt+ui-templates@0.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue");
  return _sfc_setup$o ? _sfc_setup$o(props, ctx) : void 0;
};
const Error404 = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__scopeId", "data-v-49db1bb2"]]);
const _sfc_main$n = {
  __ssrInlineRender: true,
  props: {
    appName: {
      type: String,
      default: "Nuxt"
    },
    version: {
      type: String,
      default: ""
    },
    statusCode: {
      type: String,
      default: "500"
    },
    statusMessage: {
      type: String,
      default: "Server error"
    },
    description: {
      type: String,
      default: "This page is temporarily unavailable."
    }
  },
  setup(__props) {
    const props = __props;
    useHead$1({
      title: `${props.statusCode} - ${props.statusMessage} | ${props.appName}`,
      script: [],
      style: [
        {
          children: `*,:before,:after{-webkit-box-sizing:border-box;box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}*{--tw-ring-inset:var(--tw-empty, );--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:rgba(14, 165, 233, .5);--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000}:root{-moz-tab-size:4;-o-tab-size:4;tab-size:4}body{margin:0;font-family:inherit;line-height:inherit}html{-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol,"Noto Color Emoji";line-height:1.5}h1,p{margin:0}h1{font-size:inherit;font-weight:inherit}`
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(vue_cjs_prod.mergeProps({ class: "font-sans antialiased bg-white dark:bg-black text-black dark:text-white grid min-h-screen place-content-center overflow-hidden" }, _attrs))} data-v-48d28fca><div class="fixed -bottom-1/2 left-0 right-0 h-1/2 spotlight" data-v-48d28fca></div><div class="max-w-520px text-center" data-v-48d28fca><h1 class="text-8xl sm:text-10xl font-medium mb-8" data-v-48d28fca>${serverRenderer.exports.ssrInterpolate(__props.statusCode)}</h1><p class="text-xl px-8 sm:px-0 sm:text-4xl font-light mb-16 leading-tight" data-v-48d28fca>${serverRenderer.exports.ssrInterpolate(__props.description)}</p></div></div>`);
    };
  }
};
const _sfc_setup$n = _sfc_main$n.setup;
_sfc_main$n.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/.pnpm/@nuxt+ui-templates@0.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue");
  return _sfc_setup$n ? _sfc_setup$n(props, ctx) : void 0;
};
const Error500 = /* @__PURE__ */ _export_sfc(_sfc_main$n, [["__scopeId", "data-v-48d28fca"]]);
const _sfc_main$l = {
  __ssrInlineRender: true,
  props: {
    error: Object
  },
  setup(__props) {
    var _a2;
    const props = __props;
    const error = props.error;
    (error.stack || "").split("\n").splice(1).map((line) => {
      const text = line.replace("webpack:/", "").replace(".vue", ".js").trim();
      return {
        text,
        internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
      };
    }).map((i) => `<span class="stack${i.internal ? " internal" : ""}">${i.text}</span>`).join("\n");
    const statusCode = String(error.statusCode || 500);
    const is404 = statusCode === "404";
    const statusMessage = (_a2 = error.statusMessage) != null ? _a2 : is404 ? "Page Not Found" : "Internal Server Error";
    const description = error.message || error.toString();
    const stack = void 0;
    const ErrorTemplate = is404 ? Error404 : Error500;
    return (_ctx, _push, _parent, _attrs) => {
      _push(serverRenderer.exports.ssrRenderComponent(vue_cjs_prod.unref(ErrorTemplate), vue_cjs_prod.mergeProps({ statusCode: vue_cjs_prod.unref(statusCode), statusMessage: vue_cjs_prod.unref(statusMessage), description: vue_cjs_prod.unref(description), stack: vue_cjs_prod.unref(stack) }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$l = _sfc_main$l.setup;
_sfc_main$l.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/components/nuxt-error-page.vue");
  return _sfc_setup$l ? _sfc_setup$l(props, ctx) : void 0;
};
const _sfc_main$k = {
  __ssrInlineRender: true,
  setup(__props) {
    const nuxtApp = useNuxtApp();
    nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
    const error = useError();
    vue_cjs_prod.onErrorCaptured((err, target, info) => {
      nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
      {
        callWithNuxt(nuxtApp, throwError, [err]);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_App = vue_cjs_prod.resolveComponent("App");
      serverRenderer.exports.ssrRenderSuspense(_push, {
        default: () => {
          if (vue_cjs_prod.unref(error)) {
            _push(serverRenderer.exports.ssrRenderComponent(vue_cjs_prod.unref(_sfc_main$l), { error: vue_cjs_prod.unref(error) }, null, _parent));
          } else {
            _push(serverRenderer.exports.ssrRenderComponent(_component_App, null, null, _parent));
          }
        },
        _: 1
      });
    };
  }
};
const _sfc_setup$k = _sfc_main$k.setup;
_sfc_main$k.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/.pnpm/nuxt@3.0.0-rc.3/node_modules/nuxt/dist/app/components/nuxt-root.vue");
  return _sfc_setup$k ? _sfc_setup$k(props, ctx) : void 0;
};
const _sfc_main$j = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  props: {
    postSEO: { type: Boolean, default: false },
    postPath: { default: "" }
  },
  setup(__props) {
    const __$temp_1 = useConfig(), config = vue_cjs_prod.toRef(__$temp_1, "config");
    const postURL = `${config.value.siteUrl}${__props.postPath}`;
    config.value.schemaOrgJSONLD && useHead$1({
      script: [{
        type: "application/ld+json",
        children: JSON.stringify(config.value.schemaOrgJSONLD)
      }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Html = vue_cjs_prod.resolveComponent("Html");
      const _component_Head = vue_cjs_prod.resolveComponent("Head");
      const _component_Title = vue_cjs_prod.resolveComponent("Title");
      const _component_Meta = vue_cjs_prod.resolveComponent("Meta");
      _push(serverRenderer.exports.ssrRenderComponent(_component_Html, vue_cjs_prod.mergeProps({ lang: "zh" }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(serverRenderer.exports.ssrRenderComponent(_component_Head, null, {
              default: vue_cjs_prod.withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Title, null, {
                    default: vue_cjs_prod.withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`${serverRenderer.exports.ssrInterpolate(config.value.title)}`);
                      } else {
                        return [
                          vue_cjs_prod.createTextVNode(vue_cjs_prod.toDisplayString(config.value.title), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    name: "description",
                    content: config.value.description
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    name: "image",
                    content: config.value.image
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    property: "og:url",
                    content: __props.postSEO ? postURL : config.value.siteUrl
                  }, null, _parent3, _scopeId2));
                  if (__props.postSEO) {
                    _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                      property: "og:type",
                      content: config.value.article
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    property: "og:title",
                    content: config.value.title
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    property: "og:description",
                    content: config.value.description
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    property: "og:image",
                    content: config.value.image
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    name: "twitter:card",
                    content: config.value.summary
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    name: "twitter:title",
                    content: config.value.title
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    name: "twitter:description",
                    content: config.value.description
                  }, null, _parent3, _scopeId2));
                  _push3(serverRenderer.exports.ssrRenderComponent(_component_Meta, {
                    name: "twitter:image",
                    content: config.value.image
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    vue_cjs_prod.createVNode(_component_Title, null, {
                      default: vue_cjs_prod.withCtx(() => [
                        vue_cjs_prod.createTextVNode(vue_cjs_prod.toDisplayString(config.value.title), 1)
                      ]),
                      _: 1
                    }),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      name: "description",
                      content: config.value.description
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      name: "image",
                      content: config.value.image
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      property: "og:url",
                      content: __props.postSEO ? postURL : config.value.siteUrl
                    }, null, 8, ["content"]),
                    __props.postSEO ? (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock(_component_Meta, {
                      key: 0,
                      property: "og:type",
                      content: config.value.article
                    }, null, 8, ["content"])) : vue_cjs_prod.createCommentVNode("", true),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      property: "og:title",
                      content: config.value.title
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      property: "og:description",
                      content: config.value.description
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      property: "og:image",
                      content: config.value.image
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      name: "twitter:card",
                      content: config.value.summary
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      name: "twitter:title",
                      content: config.value.title
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      name: "twitter:description",
                      content: config.value.description
                    }, null, 8, ["content"]),
                    vue_cjs_prod.createVNode(_component_Meta, {
                      name: "twitter:image",
                      content: config.value.image
                    }, null, 8, ["content"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              vue_cjs_prod.createVNode(_component_Head, null, {
                default: vue_cjs_prod.withCtx(() => [
                  vue_cjs_prod.createVNode(_component_Title, null, {
                    default: vue_cjs_prod.withCtx(() => [
                      vue_cjs_prod.createTextVNode(vue_cjs_prod.toDisplayString(config.value.title), 1)
                    ]),
                    _: 1
                  }),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    name: "description",
                    content: config.value.description
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    name: "image",
                    content: config.value.image
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    property: "og:url",
                    content: __props.postSEO ? postURL : config.value.siteUrl
                  }, null, 8, ["content"]),
                  __props.postSEO ? (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock(_component_Meta, {
                    key: 0,
                    property: "og:type",
                    content: config.value.article
                  }, null, 8, ["content"])) : vue_cjs_prod.createCommentVNode("", true),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    property: "og:title",
                    content: config.value.title
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    property: "og:description",
                    content: config.value.description
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    property: "og:image",
                    content: config.value.image
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    name: "twitter:card",
                    content: config.value.summary
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    name: "twitter:title",
                    content: config.value.title
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    name: "twitter:description",
                    content: config.value.description
                  }, null, 8, ["content"]),
                  vue_cjs_prod.createVNode(_component_Meta, {
                    name: "twitter:image",
                    content: config.value.image
                  }, null, 8, ["content"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Seo.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const Seo = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$j
}, Symbol.toStringTag, { value: "Module" }));
const layouts = {
  readme: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return README;
  })),
  default: vue_cjs_prod.defineAsyncComponent(() => Promise.resolve().then(function() {
    return _default;
  }))
};
const defaultLayoutTransition = { name: "layout", mode: "out-in" };
const __nuxt_component_1 = vue_cjs_prod.defineComponent({
  props: {
    name: {
      type: [String, Boolean, Object],
      default: null
    }
  },
  setup(props, context) {
    const route = useRoute();
    return () => {
      var _a2, _b2, _c;
      const layout = (_b2 = (_a2 = vue_cjs_prod.isRef(props.name) ? props.name.value : props.name) != null ? _a2 : route.meta.layout) != null ? _b2 : "default";
      const hasLayout = layout && layout in layouts;
      return _wrapIf(vue_cjs_prod.Transition, hasLayout && ((_c = route.meta.layoutTransition) != null ? _c : defaultLayoutTransition), _wrapIf(layouts[layout], hasLayout, context.slots)).default();
    };
  }
});
const _sfc_main$i = {
  __ssrInlineRender: true,
  setup(__props) {
    useHead$1({
      title: "Soya",
      link: [
        {
          rel: "icon",
          type: "image/png",
          href: "/images/nuxt.png"
        }
      ]
    });
    const { theme } = useTheme();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Seo = _sfc_main$j;
      const _component_NuxtLayout = __nuxt_component_1;
      const _component_NuxtPage = vue_cjs_prod.resolveComponent("NuxtPage");
      _push(`<!--[-->`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_Seo, null, null, _parent));
      _push(`<div class="${serverRenderer.exports.ssrRenderClass(vue_cjs_prod.unref(theme))}">`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLayout, null, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(serverRenderer.exports.ssrRenderComponent(_component_NuxtPage, null, null, _parent2, _scopeId));
          } else {
            return [
              vue_cjs_prod.createVNode(_component_NuxtPage)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
if (!globalThis.$fetch) {
  globalThis.$fetch = $fetch$1.create({
    baseURL: baseURL()
  });
}
let entry;
const plugins = normalizePlugins(_plugins);
{
  entry = async function createNuxtAppServer(ssrContext = {}) {
    const vueApp = vue_cjs_prod.createApp(_sfc_main$k);
    vueApp.component("App", _sfc_main$i);
    const nuxt = createNuxtApp({ vueApp, ssrContext });
    try {
      await applyPlugins(nuxt, plugins);
      await nuxt.hooks.callHook("app:created", vueApp);
    } catch (err) {
      await nuxt.callHook("app:error", err);
      ssrContext.error = ssrContext.error || err;
    }
    return vueApp;
  };
}
const entry$1 = (ctx) => entry(ctx);
const _sfc_main$h = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    const links = [
      { url: "https://taniarascia.substack.com/subscribe", label: "Newsletter" }
    ];
    const madeWithLinks = [
      { url: "https://v3.nuxtjs.org/", label: "Next3", icon: "/images/nuxt.png" },
      { url: "https://vitejs.dev/", label: "Vite", icon: "/images/vite.png" },
      { url: "https://github.com/Soya-xy", label: "Github", icon: "/images/nav-github.png" }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><footer class="footer"><section><nav><span class="desktop-only">Made by Soya</span><a class="desktop-only !text-#eee" href="https://www.taniarascia.com/" target="_blank">Theme By Tania Rascia</a></nav><nav><span class="desktop-only">Links:</span><!--[-->`);
      serverRenderer.exports.ssrRenderList(links, (link) => {
        _push(`<a${serverRenderer.exports.ssrRenderAttr("href", link.url)} target="_blank" rel="noopener noreferrer">${serverRenderer.exports.ssrInterpolate(link.label)}</a>`);
      });
      _push(`<!--]--></nav><nav><!--[-->`);
      serverRenderer.exports.ssrRenderList(madeWithLinks, (link) => {
        _push(`<a${serverRenderer.exports.ssrRenderAttr("href", link.url)}${serverRenderer.exports.ssrRenderAttr("title", link.label)} target="_blank" rel="noopener noreferrer"><span>${serverRenderer.exports.ssrInterpolate(link.label)}</span><img${serverRenderer.exports.ssrRenderAttr("src", link.icon)}${serverRenderer.exports.ssrRenderAttr("alt", link.label)}></a>`);
      });
      _push(`<!--]--></nav></section></footer></div>`);
    };
  }
});
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const Footer = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$h
}, Symbol.toStringTag, { value: "Module" }));
const _imports_0$1 = publicAssetsURL(`images/moon.png`);
const _sfc_main$g = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    useTheme();
    const { config } = useConfig();
    return (_ctx, _push, _parent, _attrs) => {
      if (vue_cjs_prod.unref(config).enableThemeSwitch) {
        _push(`<button${serverRenderer.exports.ssrRenderAttrs(vue_cjs_prod.mergeProps({ class: "theme-switcher" }, _attrs))}><img${serverRenderer.exports.ssrRenderAttr("src", _imports_0$1)} alt="Theme"></button>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ToggleTheme.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const ToggleTheme = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$g
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$f = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    const { config } = useConfig();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_ToggleTheme = _sfc_main$g;
      _push(`<header${serverRenderer.exports.ssrRenderAttrs(vue_cjs_prod.mergeProps({ class: "navigation" }, _attrs))}><div class="navigation-inner"><nav class="brand-section"><button class="desktop-only collapse-button"><i icon-btn i-material-symbols:menu-rounded></i></button>`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "brand"
      }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span${_scopeId}>Soya</span>`);
          } else {
            return [
              vue_cjs_prod.createVNode("span", null, "Soya")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</nav><div><nav><!--[-->`);
      serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(config).menu, (item) => {
        _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
          key: item.label,
          to: item.url,
          "active-class": "active"
        }, {
          default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${serverRenderer.exports.ssrRenderAttr("src", item.icon)}${serverRenderer.exports.ssrRenderAttr("alt", item.label)}${_scopeId}><div class="tooltip"${_scopeId}>${serverRenderer.exports.ssrInterpolate(item.label)}</div>`);
            } else {
              return [
                vue_cjs_prod.createVNode("img", {
                  src: item.icon,
                  alt: item.label
                }, null, 8, ["src", "alt"]),
                vue_cjs_prod.createVNode("div", { class: "tooltip" }, vue_cjs_prod.toDisplayString(item.label), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></nav></div><div class="toolbar-section"><nav class="social-nav"><!--[-->`);
      serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(config).socialMenu, (item) => {
        _push(`<a${serverRenderer.exports.ssrRenderAttr("href", item.url)} target="_blank" rel="noreferrer"><img${serverRenderer.exports.ssrRenderAttr("src", item.icon)}${serverRenderer.exports.ssrRenderAttr("alt", item.label)}></a>`);
      });
      _push(`<!--]--></nav>`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_ToggleTheme, null, null, _parent));
      _push(`</div></div></header>`);
    };
  }
});
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const Header = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$f
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$e = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    const {
      frontmatter: post = {
        title: "",
        content: "",
        noHeader: true
      }
    } = vue_cjs_prod.useAttrs();
    const { config } = useConfig();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><article><header><div class="container">`);
      if (!vue_cjs_prod.unref(post).noHeader) {
        _push(`<div class="post-details">`);
        if (vue_cjs_prod.unref(post).thumbnail) {
          _push(`<div><div class="post-image"><img${serverRenderer.exports.ssrRenderAttr("src", vue_cjs_prod.unref(post).thumbnail)}></div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (vue_cjs_prod.unref(post).author) {
          _push(`<!--[--> Written by `);
          _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, { to: "/me" }, {
            default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${serverRenderer.exports.ssrInterpolate(vue_cjs_prod.unref(post).author || vue_cjs_prod.unref(config).author)}`);
              } else {
                return [
                  vue_cjs_prod.createTextVNode(vue_cjs_prod.toDisplayString(vue_cjs_prod.unref(post).author || vue_cjs_prod.unref(config).author), 1)
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`<!--]-->`);
        } else {
          _push(`<!---->`);
        }
        if (vue_cjs_prod.unref(post).date) {
          _push(`<!--[--> on <time>${serverRenderer.exports.ssrInterpolate(vue_cjs_prod.unref(postDate)(vue_cjs_prod.unref(post).date))}</time><!--]-->`);
        } else {
          _push(`<!---->`);
        }
        if (vue_cjs_prod.unref(post).duration) {
          _push(`<!--[--> Duration: <time>${serverRenderer.exports.ssrInterpolate(vue_cjs_prod.unref(post).duration)}</time><!--]-->`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<h1>${serverRenderer.exports.ssrInterpolate(vue_cjs_prod.unref(post).title)}</h1>`);
      if (vue_cjs_prod.unref(post).description) {
        _push(`<p class="description">${serverRenderer.exports.ssrInterpolate(vue_cjs_prod.unref(post).description)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="post-meta">`);
      if (vue_cjs_prod.unref(post).tags) {
        _push(`<div class="tags"><!--[-->`);
        serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(post).tags, (tag) => {
          _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
            key: tag,
            to: `/tags/${tag}`,
            class: "{`tag-${tag}`}"
          }, {
            default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${serverRenderer.exports.ssrInterpolate(tag)}`);
              } else {
                return [
                  vue_cjs_prod.createTextVNode(vue_cjs_prod.toDisplayString(tag), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></header>`);
      serverRenderer.exports.ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</article><section id="comments" class="comments container"><h3>Comments</h3></section></div>`);
    };
  }
});
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Post.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const Post = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$e
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$d = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}></div>`);
}
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/.pnpm/@unocss+nuxt@0.33.4/node_modules/@unocss/nuxt/runtime/UnoIcon.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const UnoIcon = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["ssrRender", _sfc_ssrRender$2]]);
const UnoIcon$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": UnoIcon
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$c = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<article${serverRenderer.exports.ssrRenderAttrs(_attrs)}><header><div class="container"><h1>404</h1><p class="description"> This was probably a mistake. </p></div></header><section><div class="container"><img${serverRenderer.exports.ssrRenderAttr("src", _imports_0$4)} alt="404" class="not-found-image"></div></section></article>`);
}
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/404.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const _404 = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["ssrRender", _sfc_ssrRender$1]]);
const _404$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _404
}, Symbol.toStringTag, { value: "Module" }));
const frontmatter$7 = { "title": "About Me", "noHeader": true, "description": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world.", "meta": [{ "property": "og:title", "content": "About Me" }, { "property": "og:description", "content": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world." }, { "name": "description", "content": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world." }] };
const _sfc_main$b = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "title": "About Me", "meta": [{ "property": "og:title", "content": "About Me" }, { "property": "og:description", "content": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world." }, { "name": "description", "content": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world." }] };
    useHead(head);
    expose({ frontmatter: { "title": "About Me", "noHeader": true, "description": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world.", "meta": [{ "property": "og:title", "content": "About Me" }, { "property": "og:description", "content": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world." }, { "name": "description", "content": "Hey, I'm Tania! I'm a software engineer working in Chicago. Welcome to my spot on the web for projects I've created, tutorials I've written, musings, and anything else I want to show the world." }] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter: frontmatter$7 }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><p${_scopeId}>Hey, I\u2019m Tania! I\u2019m a software engineer working in Chicago. Welcome to my spot on the web for projects I\u2019ve created, tutorials I\u2019ve written, musings, and anything else I want to show the world.</p><p${_scopeId}>My site has no ads, no affiliate links, no tracking or analytics, no sponsored posts, and no paywall. My only motivation for this site is to share what I\u2019ve learned with the world and document notes for myself, and hopefully connect with a few people.</p><p${_scopeId}>Check out the projects page to see a highlight of the open-source projects I\u2019ve made, and articles to see everything I\u2019ve written. I\u2019ve also written external publications for DigitalOcean, Envato Tuts+, etc. and done a few speaking engagements and podcasts, which you can find below.</p><p${_scopeId}>What I\u2019m doing now Updated April 25, 2022</p><p${_scopeId}>Working on KeyboardAccordion.com Working full time Writing about GraphQL Looking for new video games to play Connect You can contact me by email at hello at taniarascia.com to say hi! I always appreciate meeting new people.</p><p${_scopeId}>GitHub Twitter Random facts I built my first website in 1998 on GeoCities Two of my favorite book series are The Expanse and A Song of Ice and Fire I own at least one accordion I once hopped on a one-way flight to Scotland and traveled Europe for several months I worked as a chef for nearly a decade before becoming a developer My favorite childhood game was Final Fantasy VI My current favorite type of game is strategy-based My best trivia category is 80\u2019s music I have an adorable little gray cat named Dimo I\u2019m a fan of Carl Sagan, Nobuo Uematsu, Bob Ross, Bo Burnham, Kyle Mooney, and Edward Snowden I\u2019ve been writing for this blog since 2015 Quotes Tania writes extremely clear, concise tutorials. It\u2019s no exaggeration to say that I wouldn\u2019t currently have a job in development without this site. So thanks for ruining my life, Tania.</p><p${_scopeId}>\u2013 Craig Lam Software Developer @ KPV LAB</p><p${_scopeId}>Tools Software This website is hosted on Netlify and uses the Gatsby framework Coding: Visual Studio Code with New Moon Theme Terminal: iTerm2 Notes: Bear App Music: Spotify Hardware Coding PC: M1 MacBook Pro 16&quot; 2021 Gaming PC CPU: AMD Ryzen 5 3600 Motherboard: ASRock B550 Phantom Gaming 4 Memory: Crucial Ballistix 32GB Storage: SSD 970 EVO NVMe M.2 1TB GPU: GTX 1660Ti PSU: EVGA SuperNOVA 650 G+ Case: MasterBox NR600 Monitor: TUF Gaming VG27AQ (x2) Keyboard: Keychron K1 Wireless Mechanical Microphone: Blue Yeti Headphones: Sony WH-1000XM3 Publications GraphQL Series DigitalOcean, 2021 How to Code in JavaScript (Tutorial Series, 32 articles) DigitalOcean, 2017 - 2020 Understanding the DOM \u2014 Document Object Model (Tutorial Series, 8 articles) DigitalOcean, 2017 - 2018 Setting up a RESTful API with Node.js and PostgreSQL LogRocket, 2018 An Introduction to CSS Shapes Tympanus Codrops, 2018 ES6 Syntax, Features and Additions: A Reference Guide Progress Telerik, 2018 REST API Tutorial (1): Understanding REST APIs Envato Tuts+, 2018 REST API Tutorial (2): Set Up a Node/Express Server Envato Tuts+, 2018 REST API Tutorial (3): Connect to a Postgres Database Envato Tuts+, 2018 A Beginner\u2019s Guide to JavaScript Variables and Datatypes SitePoint, 2017 JavaScript Operators, Conditionals &amp; Functions SitePoint, 2017 Books Understanding the DOM DigitalOcean, 2020 Interviews &amp; Podcasts How to Organize your React App React Round Up, Jack Herrington, Paige Niedringhaus, TJ VanToll Switching Careers and Learning in Public Egghead.io Podcast, Joel Hooks Web Developer: Tania Rascia You are techY Podcast, Ellen Twomey Interview Hashnode Townhall, Bolaji Ayodeji Speaking Getting Started with Vue Chicago JavaScript, 2019 Getting Started with React Chicago JavaScript, 2018 Developing a WordPress Theme from Scratch WordCamp Chicago, 2017 Songs I\u2019d Like to Walk Around In Your Mind El Pasadiscos Such Great Hights (Duet) Night Nurse (Duet) Misc Resume</p></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("p", null, "Hey, I\u2019m Tania! I\u2019m a software engineer working in Chicago. Welcome to my spot on the web for projects I\u2019ve created, tutorials I\u2019ve written, musings, and anything else I want to show the world."),
                vue_cjs_prod.createVNode("p", null, "My site has no ads, no affiliate links, no tracking or analytics, no sponsored posts, and no paywall. My only motivation for this site is to share what I\u2019ve learned with the world and document notes for myself, and hopefully connect with a few people."),
                vue_cjs_prod.createVNode("p", null, "Check out the projects page to see a highlight of the open-source projects I\u2019ve made, and articles to see everything I\u2019ve written. I\u2019ve also written external publications for DigitalOcean, Envato Tuts+, etc. and done a few speaking engagements and podcasts, which you can find below."),
                vue_cjs_prod.createVNode("p", null, "What I\u2019m doing now Updated April 25, 2022"),
                vue_cjs_prod.createVNode("p", null, "Working on KeyboardAccordion.com Working full time Writing about GraphQL Looking for new video games to play Connect You can contact me by email at hello at taniarascia.com to say hi! I always appreciate meeting new people."),
                vue_cjs_prod.createVNode("p", null, "GitHub Twitter Random facts I built my first website in 1998 on GeoCities Two of my favorite book series are The Expanse and A Song of Ice and Fire I own at least one accordion I once hopped on a one-way flight to Scotland and traveled Europe for several months I worked as a chef for nearly a decade before becoming a developer My favorite childhood game was Final Fantasy VI My current favorite type of game is strategy-based My best trivia category is 80\u2019s music I have an adorable little gray cat named Dimo I\u2019m a fan of Carl Sagan, Nobuo Uematsu, Bob Ross, Bo Burnham, Kyle Mooney, and Edward Snowden I\u2019ve been writing for this blog since 2015 Quotes Tania writes extremely clear, concise tutorials. It\u2019s no exaggeration to say that I wouldn\u2019t currently have a job in development without this site. So thanks for ruining my life, Tania."),
                vue_cjs_prod.createVNode("p", null, "\u2013 Craig Lam Software Developer @ KPV LAB"),
                vue_cjs_prod.createVNode("p", null, 'Tools Software This website is hosted on Netlify and uses the Gatsby framework Coding: Visual Studio Code with New Moon Theme Terminal: iTerm2 Notes: Bear App Music: Spotify Hardware Coding PC: M1 MacBook Pro 16" 2021 Gaming PC CPU: AMD Ryzen 5 3600 Motherboard: ASRock B550 Phantom Gaming 4 Memory: Crucial Ballistix 32GB Storage: SSD 970 EVO NVMe M.2 1TB GPU: GTX 1660Ti PSU: EVGA SuperNOVA 650 G+ Case: MasterBox NR600 Monitor: TUF Gaming VG27AQ (x2) Keyboard: Keychron K1 Wireless Mechanical Microphone: Blue Yeti Headphones: Sony WH-1000XM3 Publications GraphQL Series DigitalOcean, 2021 How to Code in JavaScript (Tutorial Series, 32 articles) DigitalOcean, 2017 - 2020 Understanding the DOM \u2014 Document Object Model (Tutorial Series, 8 articles) DigitalOcean, 2017 - 2018 Setting up a RESTful API with Node.js and PostgreSQL LogRocket, 2018 An Introduction to CSS Shapes Tympanus Codrops, 2018 ES6 Syntax, Features and Additions: A Reference Guide Progress Telerik, 2018 REST API Tutorial (1): Understanding REST APIs Envato Tuts+, 2018 REST API Tutorial (2): Set Up a Node/Express Server Envato Tuts+, 2018 REST API Tutorial (3): Connect to a Postgres Database Envato Tuts+, 2018 A Beginner\u2019s Guide to JavaScript Variables and Datatypes SitePoint, 2017 JavaScript Operators, Conditionals & Functions SitePoint, 2017 Books Understanding the DOM DigitalOcean, 2020 Interviews & Podcasts How to Organize your React App React Round Up, Jack Herrington, Paige Niedringhaus, TJ VanToll Switching Careers and Learning in Public Egghead.io Podcast, Joel Hooks Web Developer: Tania Rascia You are techY Podcast, Ellen Twomey Interview Hashnode Townhall, Bolaji Ayodeji Speaking Getting Started with Vue Chicago JavaScript, 2019 Getting Started with React Chicago JavaScript, 2018 Developing a WordPress Theme from Scratch WordCamp Chicago, 2017 Songs I\u2019d Like to Walk Around In Your Mind El Pasadiscos Such Great Hights (Duet) Night Nurse (Duet) Misc Resume')
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/about.md");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const about = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter: frontmatter$7,
  "default": _sfc_main$b
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$a = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Search = _sfc_main$t;
      const _component_Posts = _sfc_main$s;
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}><article class="blog-page"><header><div class="container"><h1>Articles</h1><p class="description"> Tutorials, technical articles, snippets, reference materials, and all development-related resources I&#39;ve written. See `);
      _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, { to: "/notes" }, {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Notes `);
          } else {
            return [
              vue_cjs_prod.createTextVNode(" Notes ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` for everything else. </p></div></header><section><div class="container">`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_Search, null, null, _parent));
      if (vue_cjs_prod.unref(isSearching)) {
        _push(`<div i-carbon-circle-dash w-7 h-7 animate-spin mt5 mxa></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<section>`);
      if (vue_cjs_prod.unref(query)) {
        _push(`<!--[-->`);
        if (!vue_cjs_prod.unref(isSearching) && vue_cjs_prod.unref(searchResult).length > 0) {
          _push(`<!--[-->`);
          serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(searchResult), (v) => {
            _push(`<!--[--><h2 class="main-header"><span>${serverRenderer.exports.ssrInterpolate(v.item.year)}</span></h2><!--[-->`);
            serverRenderer.exports.ssrRenderList(v.matches, (item) => {
              _push(serverRenderer.exports.ssrRenderComponent(_component_Posts, {
                key: item.value,
                node: { title: item.value, date: v.item.list[item.refIndex].birthtime },
                matches: item.indices,
                "time-type": "post"
              }, null, _parent));
            });
            _push(`<!--]--><!--]-->`);
          });
          _push(`<!--]-->`);
        } else if (!vue_cjs_prod.unref(isSearching)) {
          _push(`<p mt8> Sorry, nothing matched that search. </p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<!--]-->`);
      } else {
        _push(`<!--[-->`);
        serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(menuList), (v) => {
          _push(`<!--[--><h2 class="main-header"><span>${serverRenderer.exports.ssrInterpolate(v.year)}</span></h2><!--[-->`);
          serverRenderer.exports.ssrRenderList(v.list, (item) => {
            _push(serverRenderer.exports.ssrRenderComponent(_component_Posts, {
              key: item.name,
              node: item,
              "time-type": "post"
            }, null, _parent));
          });
          _push(`<!--]--><!--]-->`);
        });
        _push(`<!--]-->`);
      }
      _push(`</section></div></section></article></div>`);
    };
  }
});
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/articles.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const articles = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$a
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$9 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Introduce = _sfc_main$q;
  _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}>`);
  _push(serverRenderer.exports.ssrRenderComponent(_component_Introduce, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["ssrRender", _sfc_ssrRender]]);
const index$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": index
}, Symbol.toStringTag, { value: "Module" }));
const frontmatter$6 = { "title": "JavaScript \u76D1\u542C\u622A\u56FE", "date": "2021-08-05 23:39", "tags": ["javascript"], "meta": [{ "property": "og:title", "content": "JavaScript \u76D1\u542C\u622A\u56FE" }] };
const _sfc_main$8 = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "title": "JavaScript \u76D1\u542C\u622A\u56FE", "meta": [{ "property": "og:title", "content": "JavaScript \u76D1\u542C\u622A\u56FE" }] };
    useHead(head);
    expose({ frontmatter: { "title": "JavaScript \u76D1\u542C\u622A\u56FE", "date": "2021-08-05 23:39", "tags": ["javascript"], "meta": [{ "property": "og:title", "content": "JavaScript \u76D1\u542C\u622A\u56FE" }] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter: frontmatter$6 }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><h1 id="\u4ECB\u7ECD\u4E00\u4E0Bdocument-visibilitystate" tabindex="-1"${_scopeId}>\u4ECB\u7ECD\u4E00\u4E0B<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/Document/visibilityState" target="_blank" rel="noopener"${_scopeId}>Document.visibilityState</a> <a class="anchor before" href="#\u4ECB\u7ECD\u4E00\u4E0Bdocument-visibilitystate" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h1><h2 id="\u5F53\u9879\u76EE\u9047\u5230\u4E00\u4E2A-\u626B\u7801\u767B\u5F55-\u5E76\u7981\u6B62\u622A\u56FE-\u622A\u56FE\u540E\u4E8C\u7EF4\u7801\u66F4\u65B0-\u7B49\u7B49\u7C7B\u4F3C\u60C5\u51B5" tabindex="-1"${_scopeId}>\u5F53\u9879\u76EE\u9047\u5230\u4E00\u4E2A,\u626B\u7801\u767B\u5F55,\u5E76\u7981\u6B62\u622A\u56FE,\u622A\u56FE\u540E\u4E8C\u7EF4\u7801\u66F4\u65B0,\u7B49\u7B49\u7C7B\u4F3C\u60C5\u51B5 <a class="anchor before" href="#\u5F53\u9879\u76EE\u9047\u5230\u4E00\u4E2A-\u626B\u7801\u767B\u5F55-\u5E76\u7981\u6B62\u622A\u56FE-\u622A\u56FE\u540E\u4E8C\u7EF4\u7801\u66F4\u65B0-\u7B49\u7B49\u7C7B\u4F3C\u60C5\u51B5" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><h2 id="\u6B64\u65F6\u53EF\u4EE5\u4F7F\u7528\u5230document-visibilitystate-\uFF0C\u76D1\u542Cdocument-visibilitystate" tabindex="-1"${_scopeId}>\u6B64\u65F6\u53EF\u4EE5\u4F7F\u7528\u5230<code class="language-text"${_scopeId}>Document.visibilityState</code> \uFF0C\u76D1\u542Cdocument visibilityState <a class="anchor before" href="#\u6B64\u65F6\u53EF\u4EE5\u4F7F\u7528\u5230document-visibilitystate-\uFF0C\u76D1\u542Cdocument-visibilitystate" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><pre class="language-js"${_scopeId}><code class="language-js"${_scopeId}>document<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>addEventListener</span><span class="token punctuation"${_scopeId}>(</span><span class="token string"${_scopeId}>&#39;visibilitychange&#39;</span><span class="token punctuation"${_scopeId}>,</span> <span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
  console<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>log</span><span class="token punctuation"${_scopeId}>(</span>document<span class="token punctuation"${_scopeId}>.</span>visibilityState<span class="token punctuation"${_scopeId}>)</span>
<span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
</code></pre><ul${_scopeId}><li${_scopeId}><code class="language-text"${_scopeId}>visible</code> : \u6B64\u65F6\u9875\u9762\u5185\u5BB9\u81F3\u5C11\u662F\u90E8\u5206\u53EF\u89C1. \u5373\u6B64\u9875\u9762\u5728\u524D\u666F\u6807\u7B7E\u9875\u4E2D\uFF0C\u5E76\u4E14\u7A97\u53E3\u6CA1\u6709\u6700\u5C0F\u5316.</li><li${_scopeId}><code class="language-text"${_scopeId}>hidden</code> : \u6B64\u65F6\u9875\u9762\u5BF9\u7528\u6237\u4E0D\u53EF\u89C1. \u5373\u6587\u6863\u5904\u4E8E\u80CC\u666F\u6807\u7B7E\u9875\u6216\u8005\u7A97\u53E3\u5904\u4E8E\u6700\u5C0F\u5316\u72B6\u6001\uFF0C\u6216\u8005\u64CD\u4F5C\u7CFB\u7EDF\u6B63\u5904\u4E8E &#39;\u9501\u5C4F\u72B6\u6001&#39; .</li><li${_scopeId}><code class="language-text"${_scopeId}>prerender</code> : \u9875\u9762\u6B64\u65F6\u6B63\u5728\u6E32\u67D3\u4E2D, \u56E0\u6B64\u662F\u4E0D\u53EF\u89C1\u7684 (considered hidden for purposes of document.hidden). \u6587\u6863\u53EA\u80FD\u4ECE\u6B64\u72B6\u6001\u5F00\u59CB\uFF0C\u6C38\u8FDC\u4E0D\u80FD\u4ECE\u5176\u4ED6\u503C\u53D8\u4E3A\u6B64\u72B6\u6001.\u6CE8\u610F: \u6D4F\u89C8\u5668\u652F\u6301\u662F\u53EF\u9009\u7684.</li></ul><h3 id="\u6839\u636E\u72B6\u6001\u6765\u89E6\u53D1\u5BF9\u5E94\u6D41\u7A0B" tabindex="-1"${_scopeId}>\u6839\u636E\u72B6\u6001\u6765\u89E6\u53D1\u5BF9\u5E94\u6D41\u7A0B <a class="anchor before" href="#\u6839\u636E\u72B6\u6001\u6765\u89E6\u53D1\u5BF9\u5E94\u6D41\u7A0B" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h3></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("h1", {
                  id: "\u4ECB\u7ECD\u4E00\u4E0Bdocument-visibilitystate",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u4ECB\u7ECD\u4E00\u4E0B"),
                  vue_cjs_prod.createVNode("a", {
                    href: "https://developer.mozilla.org/zh-CN/docs/Web/API/Document/visibilityState",
                    target: "_blank",
                    rel: "noopener"
                  }, "Document.visibilityState"),
                  vue_cjs_prod.createTextVNode(),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u4ECB\u7ECD\u4E00\u4E0Bdocument-visibilitystate",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "\u5F53\u9879\u76EE\u9047\u5230\u4E00\u4E2A-\u626B\u7801\u767B\u5F55-\u5E76\u7981\u6B62\u622A\u56FE-\u622A\u56FE\u540E\u4E8C\u7EF4\u7801\u66F4\u65B0-\u7B49\u7B49\u7C7B\u4F3C\u60C5\u51B5",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u5F53\u9879\u76EE\u9047\u5230\u4E00\u4E2A,\u626B\u7801\u767B\u5F55,\u5E76\u7981\u6B62\u622A\u56FE,\u622A\u56FE\u540E\u4E8C\u7EF4\u7801\u66F4\u65B0,\u7B49\u7B49\u7C7B\u4F3C\u60C5\u51B5 "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u5F53\u9879\u76EE\u9047\u5230\u4E00\u4E2A-\u626B\u7801\u767B\u5F55-\u5E76\u7981\u6B62\u622A\u56FE-\u622A\u56FE\u540E\u4E8C\u7EF4\u7801\u66F4\u65B0-\u7B49\u7B49\u7C7B\u4F3C\u60C5\u51B5",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "\u6B64\u65F6\u53EF\u4EE5\u4F7F\u7528\u5230document-visibilitystate-\uFF0C\u76D1\u542Cdocument-visibilitystate",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u6B64\u65F6\u53EF\u4EE5\u4F7F\u7528\u5230"),
                  vue_cjs_prod.createVNode("code", { class: "language-text" }, "Document.visibilityState"),
                  vue_cjs_prod.createTextVNode(" \uFF0C\u76D1\u542Cdocument visibilityState "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u6B64\u65F6\u53EF\u4EE5\u4F7F\u7528\u5230document-visibilitystate-\uFF0C\u76D1\u542Cdocument-visibilitystate",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("pre", { class: "language-js" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-js" }, [
                    vue_cjs_prod.createTextVNode("document"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "addEventListener"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'visibilitychange'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  console"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "log"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("document"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("visibilityState"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ]),
                vue_cjs_prod.createVNode("ul", null, [
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("code", { class: "language-text" }, "visible"),
                    vue_cjs_prod.createTextVNode(" : \u6B64\u65F6\u9875\u9762\u5185\u5BB9\u81F3\u5C11\u662F\u90E8\u5206\u53EF\u89C1. \u5373\u6B64\u9875\u9762\u5728\u524D\u666F\u6807\u7B7E\u9875\u4E2D\uFF0C\u5E76\u4E14\u7A97\u53E3\u6CA1\u6709\u6700\u5C0F\u5316.")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("code", { class: "language-text" }, "hidden"),
                    vue_cjs_prod.createTextVNode(" : \u6B64\u65F6\u9875\u9762\u5BF9\u7528\u6237\u4E0D\u53EF\u89C1. \u5373\u6587\u6863\u5904\u4E8E\u80CC\u666F\u6807\u7B7E\u9875\u6216\u8005\u7A97\u53E3\u5904\u4E8E\u6700\u5C0F\u5316\u72B6\u6001\uFF0C\u6216\u8005\u64CD\u4F5C\u7CFB\u7EDF\u6B63\u5904\u4E8E '\u9501\u5C4F\u72B6\u6001' .")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("code", { class: "language-text" }, "prerender"),
                    vue_cjs_prod.createTextVNode(" : \u9875\u9762\u6B64\u65F6\u6B63\u5728\u6E32\u67D3\u4E2D, \u56E0\u6B64\u662F\u4E0D\u53EF\u89C1\u7684 (considered hidden for purposes of document.hidden). \u6587\u6863\u53EA\u80FD\u4ECE\u6B64\u72B6\u6001\u5F00\u59CB\uFF0C\u6C38\u8FDC\u4E0D\u80FD\u4ECE\u5176\u4ED6\u503C\u53D8\u4E3A\u6B64\u72B6\u6001.\u6CE8\u610F: \u6D4F\u89C8\u5668\u652F\u6301\u662F\u53EF\u9009\u7684.")
                  ])
                ]),
                vue_cjs_prod.createVNode("h3", {
                  id: "\u6839\u636E\u72B6\u6001\u6765\u89E6\u53D1\u5BF9\u5E94\u6D41\u7A0B",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u6839\u636E\u72B6\u6001\u6765\u89E6\u53D1\u5BF9\u5E94\u6D41\u7A0B "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u6839\u636E\u72B6\u6001\u6765\u89E6\u53D1\u5BF9\u5E94\u6D41\u7A0B",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/JavaScript-\u76D1\u542C\u622A\u56FE.md");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const JavaScript_____ = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter: frontmatter$6,
  "default": _sfc_main$8
}, Symbol.toStringTag, { value: "Module" }));
const frontmatter$5 = { "title": "New Blog", "date": "2022-05-15 19:34", "tags": ["post", "note-taking"], "thumbnail": "/images/github.png", "highlighted": true, "meta": [{ "property": "og:title", "content": "New Blog" }] };
const _sfc_main$7 = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "title": "New Blog", "meta": [{ "property": "og:title", "content": "New Blog" }] };
    useHead(head);
    expose({ frontmatter: { "title": "New Blog", "date": "2022-05-15 19:34", "tags": ["post", "note-taking"], "thumbnail": "/images/github.png", "highlighted": true, "meta": [{ "property": "og:title", "content": "New Blog" }] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter: frontmatter$5 }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><p${_scopeId}>I came across Taniarascia\u2019s blog and liked his theme, and nuxT3 came into RC, so it took 2 days to migrate the theme to NuxT3</p><h2 id="introduce" tabindex="-1"${_scopeId}>Introduce <a class="anchor before" href="#introduce" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><p${_scopeId}>Nuxt3 Blog based on <a href="https://github.com/antfu/vitesse-nuxt3" target="_blank" rel="noopener"${_scopeId}>Vitesse-Nuxt3</a> template, using <a href="https://www.taniarascia.com/" target="_blank" rel="noopener"${_scopeId}>Taniarascia</a>\`s Blog style theme</p><h2 id="todo" tabindex="-1"${_scopeId}>TODO <a class="anchor before" href="#todo" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><ul${_scopeId}><li${_scopeId}>[ ] Add Menu</li><li${_scopeId}>[ ] Add ToolTip</li><li${_scopeId}>[ ] Add go back to the top</li><li${_scopeId}>[ ] Add Comment (&#39;Consider adding GraphQL&#39;)</li></ul><h2 id="feature" tabindex="-1"${_scopeId}>Feature <a class="anchor before" href="#feature" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><ul${_scopeId}><li${_scopeId}><a href="https://v3.nuxtjs.org" target="_blank" rel="noopener"${_scopeId}>Nuxt 3</a> - SSR, ESR, File-based routing, components auto importing, modules, etc.</li><li${_scopeId}><a href="https://github.com/antfu/unocss" target="_blank" rel="noopener"${_scopeId}>UnoCSS</a> - The instant on-demand atomic CSS engine.</li><li${_scopeId}><a href="https://github.com/antfu/vite-plugin-md" target="_blank" rel="noopener"${_scopeId}>Vite-plugin-md</a> - Markdown for Vite</li><li${_scopeId}><a href="https://fusejs.io/" target="_blank" rel="noopener"${_scopeId}>Fuse.js</a> - Fuse.js is a powerful, lightweight fuzzy-search library, with zero dependencies.</li><li${_scopeId}><a href="https://vueuse.org/" target="_blank" rel="noopener"${_scopeId}>Vueuse</a> - Collection of essential Vue Composition Utilities</li></ul><h1 id="try-it" tabindex="-1"${_scopeId}>Try it <a class="anchor before" href="#try-it" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h1><h2 id="usage" tabindex="-1"${_scopeId}>Usage <a class="anchor before" href="#usage" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><p${_scopeId}>You can do this by creating an &#39;.md &#39;file in the&#39; page/posts&#39; directory called the article title, and then writing the article content to the file to display it on the page.</p><p${_scopeId}>Write headers at the top of the file to define the article parameters, following the &#39;YAML&#39; format as follows:</p><pre class="language-md"${_scopeId}><code class="language-md"${_scopeId}><span class="token front-matter-block"${_scopeId}><span class="token punctuation"${_scopeId}>---</span>
<span class="token front-matter yaml language-yaml"${_scopeId}>title: Articles \`s Title
date: Articles \`s Date
duration: How long did it take to write this article
author: Your/Other name
thumbnail: Articles \`s Thumbnail and Logo
highlighted: Whether it is specially displayed on the home page
tags: string[]  Articles \`s tag / keywords / categories</span>
<span class="token punctuation"${_scopeId}>---</span></span>
</code></pre><h2 id="config" tabindex="-1"${_scopeId}>Config <a class="anchor before" href="#config" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><p${_scopeId}>In the &#39;composables/config.ts&#39; file you can configure some default parameters, such as:</p><pre class="language-ts"${_scopeId}><code class="language-ts"${_scopeId}><span class="token keyword"${_scopeId}>interface</span> <span class="token class-name"${_scopeId}>Item</span> <span class="token punctuation"${_scopeId}>{</span>
  label<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  icon<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  url<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
<span class="token punctuation"${_scopeId}>}</span>

<span class="token keyword"${_scopeId}>interface</span> <span class="token class-name"${_scopeId}>WebConfig</span> <span class="token punctuation"${_scopeId}>{</span>
  siteUrl<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  siteLogo<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>

  <span class="token comment"${_scopeId}>// SEO These parameters will be generated in the of each page</span>
  <span class="token comment"${_scopeId}>// Specific please see: components/Seo.vue</span>
  github<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  description<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  image<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  article<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  summary<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span>
  schemaOrgJSONLD<span class="token operator"${_scopeId}>:</span> SchemaObject

  <span class="token comment"${_scopeId}>// Article</span>
  author<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span> <span class="token comment"${_scopeId}>// The author of the article</span>
  title<span class="token operator"${_scopeId}>:</span> <span class="token builtin"${_scopeId}>string</span> <span class="token comment"${_scopeId}>// This is the default title if the article does not declare a title</span>

  <span class="token comment"${_scopeId}>// headerMenu</span>
  menu<span class="token operator"${_scopeId}>:</span> Item
  <span class="token comment"${_scopeId}>// rightMenu eg: Github, Twitter, Facebook...</span>
  socialMenu<span class="token operator"${_scopeId}>:</span> Item<span class="token punctuation"${_scopeId}>[</span><span class="token punctuation"${_scopeId}>]</span>
  <span class="token comment"${_scopeId}>// Whether to enable theme color switch</span>
  enableThemeSwitch<span class="token operator"${_scopeId}>:</span> <span class="token boolean"${_scopeId}>true</span>
  <span class="token comment"${_scopeId}>// Number of latest articles on home page</span>
  latestNum<span class="token operator"${_scopeId}>:</span> <span class="token number"${_scopeId}>10</span>
  <span class="token comment"${_scopeId}>// Number of highlight articles on article page</span>
  highlightNum<span class="token operator"${_scopeId}>:</span> <span class="token number"${_scopeId}>10</span>
<span class="token punctuation"${_scopeId}>}</span>
</code></pre></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("p", null, "I came across Taniarascia\u2019s blog and liked his theme, and nuxT3 came into RC, so it took 2 days to migrate the theme to NuxT3"),
                vue_cjs_prod.createVNode("h2", {
                  id: "introduce",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("Introduce "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#introduce",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createTextVNode("Nuxt3 Blog based on "),
                  vue_cjs_prod.createVNode("a", {
                    href: "https://github.com/antfu/vitesse-nuxt3",
                    target: "_blank",
                    rel: "noopener"
                  }, "Vitesse-Nuxt3"),
                  vue_cjs_prod.createTextVNode(" template, using "),
                  vue_cjs_prod.createVNode("a", {
                    href: "https://www.taniarascia.com/",
                    target: "_blank",
                    rel: "noopener"
                  }, "Taniarascia"),
                  vue_cjs_prod.createTextVNode("`s Blog style theme")
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "todo",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("TODO "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#todo",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("ul", null, [
                  vue_cjs_prod.createVNode("li", null, "[ ] Add Menu"),
                  vue_cjs_prod.createVNode("li", null, "[ ] Add ToolTip"),
                  vue_cjs_prod.createVNode("li", null, "[ ] Add go back to the top"),
                  vue_cjs_prod.createVNode("li", null, "[ ] Add Comment ('Consider adding GraphQL')")
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "feature",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("Feature "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#feature",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("ul", null, [
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://v3.nuxtjs.org",
                      target: "_blank",
                      rel: "noopener"
                    }, "Nuxt 3"),
                    vue_cjs_prod.createTextVNode(" - SSR, ESR, File-based routing, components auto importing, modules, etc.")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/antfu/unocss",
                      target: "_blank",
                      rel: "noopener"
                    }, "UnoCSS"),
                    vue_cjs_prod.createTextVNode(" - The instant on-demand atomic CSS engine.")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/antfu/vite-plugin-md",
                      target: "_blank",
                      rel: "noopener"
                    }, "Vite-plugin-md"),
                    vue_cjs_prod.createTextVNode(" - Markdown for Vite")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://fusejs.io/",
                      target: "_blank",
                      rel: "noopener"
                    }, "Fuse.js"),
                    vue_cjs_prod.createTextVNode(" - Fuse.js is a powerful, lightweight fuzzy-search library, with zero dependencies.")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://vueuse.org/",
                      target: "_blank",
                      rel: "noopener"
                    }, "Vueuse"),
                    vue_cjs_prod.createTextVNode(" - Collection of essential Vue Composition Utilities")
                  ])
                ]),
                vue_cjs_prod.createVNode("h1", {
                  id: "try-it",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("Try it "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#try-it",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "usage",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("Usage "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#usage",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, "You can do this by creating an '.md 'file in the' page/posts' directory called the article title, and then writing the article content to the file to display it on the page."),
                vue_cjs_prod.createVNode("p", null, "Write headers at the top of the file to define the article parameters, following the 'YAML' format as follows:"),
                vue_cjs_prod.createVNode("pre", { class: "language-md" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-md" }, [
                    vue_cjs_prod.createVNode("span", { class: "token front-matter-block" }, [
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "---"),
                      vue_cjs_prod.createTextVNode("\n"),
                      vue_cjs_prod.createVNode("span", { class: "token front-matter yaml language-yaml" }, "title: Articles `s Title\ndate: Articles `s Date\nduration: How long did it take to write this article\nauthor: Your/Other name\nthumbnail: Articles `s Thumbnail and Logo\nhighlighted: Whether it is specially displayed on the home page\ntags: string[]  Articles `s tag / keywords / categories"),
                      vue_cjs_prod.createTextVNode("\n"),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "---")
                    ]),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "config",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("Config "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#config",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, "In the 'composables/config.ts' file you can configure some default parameters, such as:"),
                vue_cjs_prod.createVNode("pre", { class: "language-ts" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-ts" }, [
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "interface"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token class-name" }, "Item"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  label"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  icon"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  url"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n\n"),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "interface"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token class-name" }, "WebConfig"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  siteUrl"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  siteLogo"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// SEO These parameters will be generated in the of each page"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// Specific please see: components/Seo.vue"),
                    vue_cjs_prod.createTextVNode("\n  github"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  description"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  image"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  article"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  summary"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode("\n  schemaOrgJSONLD"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(" SchemaObject\n\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// Article"),
                    vue_cjs_prod.createTextVNode("\n  author"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// The author of the article"),
                    vue_cjs_prod.createTextVNode("\n  title"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token builtin" }, "string"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// This is the default title if the article does not declare a title"),
                    vue_cjs_prod.createTextVNode("\n\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// headerMenu"),
                    vue_cjs_prod.createTextVNode("\n  menu"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(" Item\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// rightMenu eg: Github, Twitter, Facebook..."),
                    vue_cjs_prod.createTextVNode("\n  socialMenu"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(" Item"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "["),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "]"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// Whether to enable theme color switch"),
                    vue_cjs_prod.createTextVNode("\n  enableThemeSwitch"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token boolean" }, "true"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// Number of latest articles on home page"),
                    vue_cjs_prod.createTextVNode("\n  latestNum"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token number" }, "10"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// Number of highlight articles on article page"),
                    vue_cjs_prod.createTextVNode("\n  highlightNum"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token number" }, "10"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/New-Blog.md");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const NewBlog = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter: frontmatter$5,
  "default": _sfc_main$7
}, Symbol.toStringTag, { value: "Module" }));
const frontmatter$4 = { "title": "Vue Class\u7684\u663E\u793A", "date": "2020-11-19 11:37", "tags": ["vue", "css"], "meta": [{ "property": "og:title", "content": "Vue Class\u7684\u663E\u793A" }] };
const _sfc_main$6 = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "title": "Vue Class\u7684\u663E\u793A", "meta": [{ "property": "og:title", "content": "Vue Class\u7684\u663E\u793A" }] };
    useHead(head);
    expose({ frontmatter: { "title": "Vue Class\u7684\u663E\u793A", "date": "2020-11-19 11:37", "tags": ["vue", "css"], "meta": [{ "property": "og:title", "content": "Vue Class\u7684\u663E\u793A" }] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter: frontmatter$4 }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><p${_scopeId}>Vue Class \u4E2D \u53EF\u4EE5\u4F20\u5165 \u5B57\u7B26\u4E32\uFF0C\u5BF9\u8C61\uFF0C\u6570\u7EC4</p><p${_scopeId}>\u5728\u4F20\u5165\u5BF9\u8C61\u7684\u65F6\u5019 \u53EF\u4EE5\u901A\u8FC7 \u5BF9\u8C61\u7684 key \u503C <code class="language-text"${_scopeId}>true/false</code> \u6765\u63A7\u5236\u8FD9\u4E2A<code class="language-text"${_scopeId}>class</code>\u662F\u5426\u663E\u793A</p><p${_scopeId}><code class="language-text"${_scopeId}>:class=&quot;{&#39;collapse&#39;: isCollapse}&quot;</code></p><pre class="language-js"${_scopeId}><code class="language-js"${_scopeId}><span class="token keyword"${_scopeId}>function</span> <span class="token function"${_scopeId}>isCollapse</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
  <span class="token keyword"${_scopeId}>return</span> <span class="token boolean"${_scopeId}>true</span>
<span class="token punctuation"${_scopeId}>}</span>
</code></pre></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("p", null, "Vue Class \u4E2D \u53EF\u4EE5\u4F20\u5165 \u5B57\u7B26\u4E32\uFF0C\u5BF9\u8C61\uFF0C\u6570\u7EC4"),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createTextVNode("\u5728\u4F20\u5165\u5BF9\u8C61\u7684\u65F6\u5019 \u53EF\u4EE5\u901A\u8FC7 \u5BF9\u8C61\u7684 key \u503C "),
                  vue_cjs_prod.createVNode("code", { class: "language-text" }, "true/false"),
                  vue_cjs_prod.createTextVNode(" \u6765\u63A7\u5236\u8FD9\u4E2A"),
                  vue_cjs_prod.createVNode("code", { class: "language-text" }, "class"),
                  vue_cjs_prod.createTextVNode("\u662F\u5426\u663E\u793A")
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("code", { class: "language-text" }, `:class="{'collapse': isCollapse}"`)
                ]),
                vue_cjs_prod.createVNode("pre", { class: "language-js" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-js" }, [
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "function"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "isCollapse"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "return"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token boolean" }, "true"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/Vue-Class\u7684\u663E\u793A.md");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const VueClass___ = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter: frontmatter$4,
  "default": _sfc_main$6
}, Symbol.toStringTag, { value: "Module" }));
const frontmatter$3 = { "title": "px\u81EA\u52A8\u8F6C\u6362\u6210rem", "date": "2020-04-25 18:17", "tags": ["vue", "css"], "meta": [{ "property": "og:title", "content": "px\u81EA\u52A8\u8F6C\u6362\u6210rem" }] };
const _sfc_main$5 = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "title": "px\u81EA\u52A8\u8F6C\u6362\u6210rem", "meta": [{ "property": "og:title", "content": "px\u81EA\u52A8\u8F6C\u6362\u6210rem" }] };
    useHead(head);
    expose({ frontmatter: { "title": "px\u81EA\u52A8\u8F6C\u6362\u6210rem", "date": "2020-04-25 18:17", "tags": ["vue", "css"], "meta": [{ "property": "og:title", "content": "px\u81EA\u52A8\u8F6C\u6362\u6210rem" }] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter: frontmatter$3 }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><pre class="language-javascript"${_scopeId}><code class="language-javascript"${_scopeId}><span class="token keyword"${_scopeId}>const</span> px2rem <span class="token operator"${_scopeId}>=</span> <span class="token function"${_scopeId}>require</span><span class="token punctuation"${_scopeId}>(</span><span class="token string"${_scopeId}>&#39;postcss-px2rem&#39;</span><span class="token punctuation"${_scopeId}>)</span><span class="token punctuation"${_scopeId}>;</span>

module<span class="token punctuation"${_scopeId}>.</span>exports <span class="token operator"${_scopeId}>=</span> <span class="token punctuation"${_scopeId}>{</span>
  <span class="token literal-property property"${_scopeId}>css</span><span class="token operator"${_scopeId}>:</span> <span class="token punctuation"${_scopeId}>{</span>
    <span class="token literal-property property"${_scopeId}>loaderOptions</span><span class="token operator"${_scopeId}>:</span> <span class="token punctuation"${_scopeId}>{</span>
      <span class="token literal-property property"${_scopeId}>postcss</span><span class="token operator"${_scopeId}>:</span> <span class="token punctuation"${_scopeId}>{</span>
        <span class="token literal-property property"${_scopeId}>plugins</span><span class="token operator"${_scopeId}>:</span> <span class="token punctuation"${_scopeId}>[</span>
          <span class="token function"${_scopeId}>px2rem</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
            <span class="token literal-property property"${_scopeId}>remUnit</span><span class="token operator"${_scopeId}>:</span> <span class="token number"${_scopeId}>75</span>
          <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
        <span class="token punctuation"${_scopeId}>]</span>
      <span class="token punctuation"${_scopeId}>}</span>
    <span class="token punctuation"${_scopeId}>}</span>
  <span class="token punctuation"${_scopeId}>}</span>
<span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>;</span>
</code></pre><p${_scopeId}><strong${_scopeId}>\u672C\u9879\u76EE\u4F1A\u81EA\u52A8\u628Apx\u81EA\u52A8\u8F6C\u6362\u6210rem\uFF0C\u4E0D\u9700\u8981\u8003\u8651\u79FB\u52A8\u7AEF\u5355\u4F4D\u517C\u5BB9\u6027\u95EE\u9898\uFF0C\u5355\u4F4D\u76F4\u63A5\u7528px\u5373\u53EF\uFF0C\u6D4F\u89C8\u5668\u4E0A\u4F1A\u81EA\u52A8\u53D8\u6210\u662Frem;\u82E5\u4E0D\u60F3\u628Apx\u8F6C\u6362\u6210rem\uFF0C\u90A3\u4E48\u76F4\u63A5\u5728\u5BF9\u5E94\u7684css\u5C5E\u6027\u540E\u9762\u589E\u52A0\u4E00\u4E2A/<em${_scopeId}>no</em>/</strong></p><p${_scopeId}><strong${_scopeId}>\u5199\u5728 vue.config.js \u4E2D\u5373\u53EF</strong></p></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("pre", { class: "language-javascript" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-javascript" }, [
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "const"),
                    vue_cjs_prod.createTextVNode(" px2rem "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "require"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'postcss-px2rem'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ";"),
                    vue_cjs_prod.createTextVNode("\n\nmodule"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("exports "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "css"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "loaderOptions"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "postcss"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "plugins"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "["),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "px2rem"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n            "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "remUnit"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token number" }, "75"),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "]"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ";"),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("strong", null, [
                    vue_cjs_prod.createTextVNode("\u672C\u9879\u76EE\u4F1A\u81EA\u52A8\u628Apx\u81EA\u52A8\u8F6C\u6362\u6210rem\uFF0C\u4E0D\u9700\u8981\u8003\u8651\u79FB\u52A8\u7AEF\u5355\u4F4D\u517C\u5BB9\u6027\u95EE\u9898\uFF0C\u5355\u4F4D\u76F4\u63A5\u7528px\u5373\u53EF\uFF0C\u6D4F\u89C8\u5668\u4E0A\u4F1A\u81EA\u52A8\u53D8\u6210\u662Frem;\u82E5\u4E0D\u60F3\u628Apx\u8F6C\u6362\u6210rem\uFF0C\u90A3\u4E48\u76F4\u63A5\u5728\u5BF9\u5E94\u7684css\u5C5E\u6027\u540E\u9762\u589E\u52A0\u4E00\u4E2A/"),
                    vue_cjs_prod.createVNode("em", null, "no"),
                    vue_cjs_prod.createTextVNode("/")
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("strong", null, "\u5199\u5728 vue.config.js \u4E2D\u5373\u53EF")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/px\u81EA\u52A8\u8F6C\u6362\u6210rem.md");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const px_____rem = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter: frontmatter$3,
  "default": _sfc_main$5
}, Symbol.toStringTag, { value: "Module" }));
const _imports_0 = publicAssetsURL(`images/nuxt.png`);
const frontmatter$2 = { "title": "About Yak Shaving", "date": "2021-05-19T16:00:00.000Z", "lang": "en", "duration": "15min", "author": "soya", "thumbnail": "/images/vue.png", "highlighted": true, "tags": ["vue", "vite", "vuepress", "vuepress-plugin-blog"], "meta": [{ "property": "og:title", "content": "About Yak Shaving" }] };
const _sfc_main$4 = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "title": "About Yak Shaving", "meta": [{ "property": "og:title", "content": "About Yak Shaving" }] };
    useHead(head);
    expose({ frontmatter: { "title": "About Yak Shaving", "date": "2021-05-19T16:00:00.000Z", "lang": "en", "duration": "15min", "author": "soya", "thumbnail": "/images/vue.png", "highlighted": true, "tags": ["vue", "vite", "vuepress", "vuepress-plugin-blog"], "meta": [{ "property": "og:title", "content": "About Yak Shaving" }] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      const _component_ToggleTheme = vue_cjs_prod.resolveComponent("ToggleTheme");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter: frontmatter$2 }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><p${_scopeId}><div class="table-of-contents"${_scopeId}><ul${_scopeId}><li${_scopeId}><a href="#title"${_scopeId}>title </a><ul${_scopeId}><li${_scopeId}><a href="#test"${_scopeId}>Test </a><ul${_scopeId}><li${_scopeId}><a href="#\u5F69\u8272\u56FE\u6807"${_scopeId}>\u5F69\u8272\u56FE\u6807 </a></li></ul></li></ul></li></ul></div></p><h1 id="title" tabindex="-1"${_scopeId}>title <a class="anchor before" href="#title" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h1><h2 id="test" tabindex="-1"${_scopeId}>Test <a class="anchor before" href="#test" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><p class="filename"${_scopeId}>TestMarkDown.js</p><pre class="language-js"${_scopeId}><code class="language-js"${_scopeId}><span class="token keyword"${_scopeId}>const</span> audio <span class="token operator"${_scopeId}>=</span> <span class="token keyword"${_scopeId}>new</span> <span class="token punctuation"${_scopeId}>(</span>window<span class="token punctuation"${_scopeId}>.</span>AudioContext <span class="token operator"${_scopeId}>||</span> window<span class="token punctuation"${_scopeId}>.</span>webkitAudioContext<span class="token punctuation"${_scopeId}>)</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span>
<span class="token keyword"${_scopeId}>const</span> gainNode <span class="token operator"${_scopeId}>=</span> audio<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>createGain</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span>
gainNode<span class="token punctuation"${_scopeId}>.</span>gain<span class="token punctuation"${_scopeId}>.</span>value <span class="token operator"${_scopeId}>=</span> <span class="token number"${_scopeId}>0.1</span>
gainNode<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>connect</span><span class="token punctuation"${_scopeId}>(</span>audio<span class="token punctuation"${_scopeId}>.</span>destination<span class="token punctuation"${_scopeId}>)</span>
</code></pre><p${_scopeId}>test \`\`</p><p${_scopeId}><code class="language-text"${_scopeId}>AudioContextAudioContext</code></p><p${_scopeId}>test Link</p><p${_scopeId}><a href="https://baidu.com" target="_blank" rel="noopener"${_scopeId}>Web Audio APi</a></p><p${_scopeId}>test List</p><ul${_scopeId}><li${_scopeId}><a href="https://github.com/antfu/vite-plugin-components" target="_blank" rel="noopener"${_scopeId}>vite-plugin-components</a> - On-demand components auto importing for Vite.</li><li${_scopeId}><a href="https://github.com/antfu/vite-plugin-pwa" target="_blank" rel="noopener"${_scopeId}>vite-plugin-pwa</a> - Zero-config PWA for Vite.</li><li${_scopeId}><a href="https://github.com/antfu/purge-icons" target="_blank" rel="noopener"${_scopeId}>vite-plugin-purge-icons</a> - Bundles icons on demand, with a Vite plugin.</li><li${_scopeId}><a href="https://github.com/iconify/iconify" target="_blank" rel="noopener"${_scopeId}>Iconify</a> - Universal icon framework, by <a href="https://github.com/cyberalien" target="_blank" rel="noopener"${_scopeId}>@cyberalien</a>.</li><li${_scopeId}><a href="https://github.com/brattonross/vite-plugin-voie" target="_blank" rel="noopener"${_scopeId}>vite-plugin-voie</a> - File system based routing for Vite, by <a href="https://github.com/brattonross" target="_blank" rel="noopener"${_scopeId}>@brattonross</a>.</li><li${_scopeId}><a href="https://github.com/hannoeru/vite-plugin-pages" target="_blank" rel="noopener"${_scopeId}>vite-plugin-pages</a> - Another file system based route generator, by <a href="https://github.com/hannoeru" target="_blank" rel="noopener"${_scopeId}>@hannoeru</a>.</li></ul><blockquote${_scopeId}><p${_scopeId}>test test2 test3</p><blockquote${_scopeId}><p${_scopeId}>test4 test5</p><blockquote${_scopeId}><p${_scopeId}>test6</p><blockquote${_scopeId}><p${_scopeId}>test7</p></blockquote></blockquote></blockquote></blockquote><p${_scopeId}>test Components</p>`);
            _push2(serverRenderer.exports.ssrRenderComponent(_component_ToggleTheme, null, null, _parent2, _scopeId));
            _push2(`<p${_scopeId}>test style</p><p${_scopeId}><strong${_scopeId}>\u7C97\u4F53</strong></p><p${_scopeId}><em${_scopeId}>\u659C\u4F53</em></p><p${_scopeId}><s${_scopeId}>\u5220\u9664\u7EBF</s></p><hr${_scopeId}><ol${_scopeId}><li${_scopeId}>A</li><li${_scopeId}>B</li><li${_scopeId}>C</li></ol><ul${_scopeId}><li${_scopeId}>A</li><li${_scopeId}>B</li><li${_scopeId}>C</li></ul><p${_scopeId}>This is <a href="http://example.com/" title="Title" target="_blank" rel="noopener"${_scopeId}>an example</a> inline link.</p><p${_scopeId}><img${serverRenderer.exports.ssrRenderAttr("src", _imports_0)} alt="nuxt"${_scopeId}></p><table${_scopeId}><thead${_scopeId}><tr${_scopeId}><th style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "left" })}"${_scopeId}>\u5DE6\u5BF9\u9F50</th><th style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "right" })}"${_scopeId}>\u53F3\u5BF9\u9F50</th><th style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "center" })}"${_scopeId}>\u5C45\u4E2D\u5BF9\u9F50</th></tr></thead><tbody${_scopeId}><tr${_scopeId}><td style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "left" })}"${_scopeId}>\u5355\u5143\u683C</td><td style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "right" })}"${_scopeId}>\u5355\u5143\u683C</td><td style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "center" })}"${_scopeId}>\u5355\u5143\u683C</td></tr><tr${_scopeId}><td style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "left" })}"${_scopeId}>\u5355\u5143\u683C</td><td style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "right" })}"${_scopeId}>\u5355\u5143\u683C</td><td style="${serverRenderer.exports.ssrRenderStyle({ "text-align": "center" })}"${_scopeId}>\u5355\u5143\u683C</td></tr></tbody></table><h3 id="\u5F69\u8272\u56FE\u6807" tabindex="-1"${_scopeId}>\u5F69\u8272\u56FE\u6807 <a class="anchor before" href="#\u5F69\u8272\u56FE\u6807" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h3><p${_scopeId}>We are the best. <code class="language-text"${_scopeId}>VB</code></p></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("div", { class: "table-of-contents" }, [
                    vue_cjs_prod.createVNode("ul", null, [
                      vue_cjs_prod.createVNode("li", null, [
                        vue_cjs_prod.createVNode("a", { href: "#title" }, "title "),
                        vue_cjs_prod.createVNode("ul", null, [
                          vue_cjs_prod.createVNode("li", null, [
                            vue_cjs_prod.createVNode("a", { href: "#test" }, "Test "),
                            vue_cjs_prod.createVNode("ul", null, [
                              vue_cjs_prod.createVNode("li", null, [
                                vue_cjs_prod.createVNode("a", { href: "#\u5F69\u8272\u56FE\u6807" }, "\u5F69\u8272\u56FE\u6807 ")
                              ])
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ]),
                vue_cjs_prod.createVNode("h1", {
                  id: "title",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("title "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#title",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "test",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("Test "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#test",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("p", { class: "filename" }, "TestMarkDown.js"),
                vue_cjs_prod.createVNode("pre", { class: "language-js" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-js" }, [
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "const"),
                    vue_cjs_prod.createTextVNode(" audio "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "new"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("window"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("AudioContext "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "||"),
                    vue_cjs_prod.createTextVNode(" window"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("webkitAudioContext"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "const"),
                    vue_cjs_prod.createTextVNode(" gainNode "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(" audio"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "createGain"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\ngainNode"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("gain"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("value "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token number" }, "0.1"),
                    vue_cjs_prod.createTextVNode("\ngainNode"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "connect"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("audio"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("destination"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, "test ``"),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("code", { class: "language-text" }, "AudioContextAudioContext")
                ]),
                vue_cjs_prod.createVNode("p", null, "test Link"),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("a", {
                    href: "https://baidu.com",
                    target: "_blank",
                    rel: "noopener"
                  }, "Web Audio APi")
                ]),
                vue_cjs_prod.createVNode("p", null, "test List"),
                vue_cjs_prod.createVNode("ul", null, [
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/antfu/vite-plugin-components",
                      target: "_blank",
                      rel: "noopener"
                    }, "vite-plugin-components"),
                    vue_cjs_prod.createTextVNode(" - On-demand components auto importing for Vite.")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/antfu/vite-plugin-pwa",
                      target: "_blank",
                      rel: "noopener"
                    }, "vite-plugin-pwa"),
                    vue_cjs_prod.createTextVNode(" - Zero-config PWA for Vite.")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/antfu/purge-icons",
                      target: "_blank",
                      rel: "noopener"
                    }, "vite-plugin-purge-icons"),
                    vue_cjs_prod.createTextVNode(" - Bundles icons on demand, with a Vite plugin.")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/iconify/iconify",
                      target: "_blank",
                      rel: "noopener"
                    }, "Iconify"),
                    vue_cjs_prod.createTextVNode(" - Universal icon framework, by "),
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/cyberalien",
                      target: "_blank",
                      rel: "noopener"
                    }, "@cyberalien"),
                    vue_cjs_prod.createTextVNode(".")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/brattonross/vite-plugin-voie",
                      target: "_blank",
                      rel: "noopener"
                    }, "vite-plugin-voie"),
                    vue_cjs_prod.createTextVNode(" - File system based routing for Vite, by "),
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/brattonross",
                      target: "_blank",
                      rel: "noopener"
                    }, "@brattonross"),
                    vue_cjs_prod.createTextVNode(".")
                  ]),
                  vue_cjs_prod.createVNode("li", null, [
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/hannoeru/vite-plugin-pages",
                      target: "_blank",
                      rel: "noopener"
                    }, "vite-plugin-pages"),
                    vue_cjs_prod.createTextVNode(" - Another file system based route generator, by "),
                    vue_cjs_prod.createVNode("a", {
                      href: "https://github.com/hannoeru",
                      target: "_blank",
                      rel: "noopener"
                    }, "@hannoeru"),
                    vue_cjs_prod.createTextVNode(".")
                  ])
                ]),
                vue_cjs_prod.createVNode("blockquote", null, [
                  vue_cjs_prod.createVNode("p", null, "test test2 test3"),
                  vue_cjs_prod.createVNode("blockquote", null, [
                    vue_cjs_prod.createVNode("p", null, "test4 test5"),
                    vue_cjs_prod.createVNode("blockquote", null, [
                      vue_cjs_prod.createVNode("p", null, "test6"),
                      vue_cjs_prod.createVNode("blockquote", null, [
                        vue_cjs_prod.createVNode("p", null, "test7")
                      ])
                    ])
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, "test Components"),
                vue_cjs_prod.createVNode(_component_ToggleTheme),
                vue_cjs_prod.createVNode("p", null, "test style"),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("strong", null, "\u7C97\u4F53")
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("em", null, "\u659C\u4F53")
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("s", null, "\u5220\u9664\u7EBF")
                ]),
                vue_cjs_prod.createVNode("hr"),
                vue_cjs_prod.createVNode("ol", null, [
                  vue_cjs_prod.createVNode("li", null, "A"),
                  vue_cjs_prod.createVNode("li", null, "B"),
                  vue_cjs_prod.createVNode("li", null, "C")
                ]),
                vue_cjs_prod.createVNode("ul", null, [
                  vue_cjs_prod.createVNode("li", null, "A"),
                  vue_cjs_prod.createVNode("li", null, "B"),
                  vue_cjs_prod.createVNode("li", null, "C")
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createTextVNode("This is "),
                  vue_cjs_prod.createVNode("a", {
                    href: "http://example.com/",
                    title: "Title",
                    target: "_blank",
                    rel: "noopener"
                  }, "an example"),
                  vue_cjs_prod.createTextVNode(" inline link.")
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createVNode("img", {
                    src: _imports_0,
                    alt: "nuxt"
                  })
                ]),
                vue_cjs_prod.createVNode("table", null, [
                  vue_cjs_prod.createVNode("thead", null, [
                    vue_cjs_prod.createVNode("tr", null, [
                      vue_cjs_prod.createVNode("th", { style: { "text-align": "left" } }, "\u5DE6\u5BF9\u9F50"),
                      vue_cjs_prod.createVNode("th", { style: { "text-align": "right" } }, "\u53F3\u5BF9\u9F50"),
                      vue_cjs_prod.createVNode("th", { style: { "text-align": "center" } }, "\u5C45\u4E2D\u5BF9\u9F50")
                    ])
                  ]),
                  vue_cjs_prod.createVNode("tbody", null, [
                    vue_cjs_prod.createVNode("tr", null, [
                      vue_cjs_prod.createVNode("td", { style: { "text-align": "left" } }, "\u5355\u5143\u683C"),
                      vue_cjs_prod.createVNode("td", { style: { "text-align": "right" } }, "\u5355\u5143\u683C"),
                      vue_cjs_prod.createVNode("td", { style: { "text-align": "center" } }, "\u5355\u5143\u683C")
                    ]),
                    vue_cjs_prod.createVNode("tr", null, [
                      vue_cjs_prod.createVNode("td", { style: { "text-align": "left" } }, "\u5355\u5143\u683C"),
                      vue_cjs_prod.createVNode("td", { style: { "text-align": "right" } }, "\u5355\u5143\u683C"),
                      vue_cjs_prod.createVNode("td", { style: { "text-align": "center" } }, "\u5355\u5143\u683C")
                    ])
                  ])
                ]),
                vue_cjs_prod.createVNode("h3", {
                  id: "\u5F69\u8272\u56FE\u6807",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u5F69\u8272\u56FE\u6807 "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u5F69\u8272\u56FE\u6807",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createTextVNode("We are the best. "),
                  vue_cjs_prod.createVNode("code", { class: "language-text" }, "VB")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/test.md");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const test = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter: frontmatter$2,
  "default": _sfc_main$4
}, Symbol.toStringTag, { value: "Module" }));
const frontmatter$1 = { "title": "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548", "date": "2020-10-06 10:56", "tags": ["\u5C0F\u7A0B\u5E8F"], "meta": [{ "property": "og:title", "content": "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548" }] };
const _sfc_main$3 = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "title": "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548", "meta": [{ "property": "og:title", "content": "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548" }] };
    useHead(head);
    expose({ frontmatter: { "title": "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548", "date": "2020-10-06 10:56", "tags": ["\u5C0F\u7A0B\u5E8F"], "meta": [{ "property": "og:title", "content": "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548" }] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter: frontmatter$1 }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><h1 id="\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406" tabindex="-1"${_scopeId}>\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406 <a class="anchor before" href="#\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h1><h2 id="\u6D41\u7A0B\u56FE" tabindex="-1"${_scopeId}>\u6D41\u7A0B\u56FE <a class="anchor before" href="#\u6D41\u7A0B\u56FE" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><p${_scopeId}>![\u6D41\u7A0B\u56FE.jpg][/post/images/xcx-login.png]</p><h2 id="\u4EE3\u7801\u793A\u4F8B" tabindex="-1"${_scopeId}>\u4EE3\u7801\u793A\u4F8B <a class="anchor before" href="#\u4EE3\u7801\u793A\u4F8B" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><pre class="language-js"${_scopeId}><code class="language-js"${_scopeId}><span class="token keyword"${_scopeId}>function</span> <span class="token function"${_scopeId}>wxLogin</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
  <span class="token comment"${_scopeId}>// \u8C03\u7528wx.login</span>
  wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>login</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
    <span class="token function-variable function"${_scopeId}>success</span><span class="token operator"${_scopeId}>:</span> <span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
      <span class="token comment"${_scopeId}>// \u83B7\u53D6\u5230code</span>
      <span class="token keyword"${_scopeId}>const</span> <span class="token constant"${_scopeId}>CODE</span> <span class="token operator"${_scopeId}>=</span> res<span class="token punctuation"${_scopeId}>.</span>code
      wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>showToast</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
        <span class="token literal-property property"${_scopeId}>title</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;\u6570\u636E\u52A0\u8F7D\u4E2D&#39;</span><span class="token punctuation"${_scopeId}>,</span>
        <span class="token literal-property property"${_scopeId}>icon</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;loading&#39;</span><span class="token punctuation"${_scopeId}>,</span>
      <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
      <span class="token comment"${_scopeId}>// \u4F7F\u7528code\u548C\u540E\u7AEF\u6362\u53D6openid\uFF0CsessionKey</span>
      <span class="token function"${_scopeId}>request</span><span class="token punctuation"${_scopeId}>(</span>
        <span class="token string"${_scopeId}>&#39;\u540E\u7AEF\u63D0\u4F9B\u7684\u63A5\u53E3&#39;</span><span class="token punctuation"${_scopeId}>,</span>
        <span class="token string"${_scopeId}>&#39;POST&#39;</span><span class="token punctuation"${_scopeId}>,</span>
        <span class="token punctuation"${_scopeId}>{</span>
          <span class="token literal-property property"${_scopeId}>code</span><span class="token operator"${_scopeId}>:</span> <span class="token constant"${_scopeId}>CODE</span><span class="token punctuation"${_scopeId}>,</span>
        <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
        <span class="token punctuation"${_scopeId}>{</span>
          <span class="token string-property property"${_scopeId}>&#39;content-type&#39;</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;application/json&#39;</span><span class="token punctuation"${_scopeId}>,</span>
        <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
      <span class="token punctuation"${_scopeId}>)</span>
        <span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>then</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
          wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>hideToast</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span>
          <span class="token keyword"${_scopeId}>if</span> <span class="token punctuation"${_scopeId}>(</span>res<span class="token punctuation"${_scopeId}>.</span>data<span class="token punctuation"${_scopeId}>.</span>InfoState <span class="token operator"${_scopeId}>===</span> <span class="token number"${_scopeId}>0</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
            <span class="token function"${_scopeId}>getUserInfo</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span>
              <span class="token punctuation"${_scopeId}>.</span>then
              <span class="token comment"${_scopeId}>// \u6210\u529F\u540E\u7684\u5904\u7406</span>
              <span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span>
              <span class="token punctuation"${_scopeId}>.</span>catch
              <span class="token comment"${_scopeId}>// \u5931\u8D25\u540E\u7684\u5904\u7406</span>
              <span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span>
          <span class="token punctuation"${_scopeId}>}</span>
        <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
        <span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>catch</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>result</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
          <span class="token comment"${_scopeId}>// \u8BF7\u6C42\u5931\u8D25\u91CD\u65B0\u5904\u7406</span>
          wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>showModal</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
            <span class="token literal-property property"${_scopeId}>title</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;\u63D0\u793A&#39;</span><span class="token punctuation"${_scopeId}>,</span>
            <span class="token literal-property property"${_scopeId}>content</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;\u8BF7\u6C42\u5931\u8D25&#39;</span><span class="token punctuation"${_scopeId}>,</span>
            <span class="token literal-property property"${_scopeId}>confirmText</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;\u91CD\u65B0\u8BF7\u6C42&#39;</span><span class="token punctuation"${_scopeId}>,</span>
            <span class="token function"${_scopeId}>success</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
              <span class="token keyword"${_scopeId}>if</span> <span class="token punctuation"${_scopeId}>(</span>res<span class="token punctuation"${_scopeId}>.</span>confirm<span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
                <span class="token function"${_scopeId}>request</span><span class="token punctuation"${_scopeId}>(</span>
                  <span class="token string"${_scopeId}>&#39;\u540E\u7AEF\u63D0\u4F9B\u7684\u63A5\u53E3&#39;</span><span class="token punctuation"${_scopeId}>,</span>
                  <span class="token string"${_scopeId}>&#39;POST&#39;</span><span class="token punctuation"${_scopeId}>,</span>
                  <span class="token punctuation"${_scopeId}>{</span>
                    <span class="token literal-property property"${_scopeId}>code</span><span class="token operator"${_scopeId}>:</span> <span class="token constant"${_scopeId}>CODE</span><span class="token punctuation"${_scopeId}>,</span>
                  <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
                  <span class="token punctuation"${_scopeId}>{</span>
                    <span class="token string-property property"${_scopeId}>&#39;content-type&#39;</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;application/json&#39;</span><span class="token punctuation"${_scopeId}>,</span>
                  <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
                <span class="token punctuation"${_scopeId}>)</span>
              <span class="token punctuation"${_scopeId}>}</span>
              <span class="token keyword"${_scopeId}>else</span> <span class="token keyword"${_scopeId}>if</span> <span class="token punctuation"${_scopeId}>(</span>res<span class="token punctuation"${_scopeId}>.</span>cancel<span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
                console<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>log</span><span class="token punctuation"${_scopeId}>(</span><span class="token string"${_scopeId}>&#39;\u7528\u6237\u70B9\u51FB\u53D6\u6D88&#39;</span><span class="token punctuation"${_scopeId}>)</span>
              <span class="token punctuation"${_scopeId}>}</span>
            <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
          <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
        <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
    <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
  <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
<span class="token punctuation"${_scopeId}>}</span>

<span class="token comment"${_scopeId}>// \u5224\u65AD\u7528\u6237\u662F\u5426\u6388\u6743</span>
<span class="token keyword"${_scopeId}>function</span> <span class="token function"${_scopeId}>getUserInfo</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
  <span class="token keyword"${_scopeId}>return</span> <span class="token keyword"${_scopeId}>new</span> <span class="token class-name"${_scopeId}>Promise</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>resolve<span class="token punctuation"${_scopeId}>,</span> reject</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
    wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>getUserInfo</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
      <span class="token function"${_scopeId}>success</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
        <span class="token function"${_scopeId}>resolve</span><span class="token punctuation"${_scopeId}>(</span>res<span class="token punctuation"${_scopeId}>)</span>
      <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
      <span class="token function"${_scopeId}>fail</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
        <span class="token comment"${_scopeId}>// eslint-disable-next-line prefer-promise-reject-errors</span>
        <span class="token function"${_scopeId}>reject</span><span class="token punctuation"${_scopeId}>(</span><span class="token string"${_scopeId}>&#39;\u6211\u8FD8\u6CA1\u6709\u6388\u6743&#39;</span><span class="token punctuation"${_scopeId}>)</span>
      <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
    <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
  <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
<span class="token punctuation"${_scopeId}>}</span>

<span class="token comment"${_scopeId}>// \u5C01\u88C5\u8BF7\u6C42</span>
<span class="token keyword"${_scopeId}>function</span> <span class="token function"${_scopeId}>request</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>url<span class="token punctuation"${_scopeId}>,</span> method<span class="token punctuation"${_scopeId}>,</span> data<span class="token punctuation"${_scopeId}>,</span> header</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
  <span class="token keyword"${_scopeId}>return</span> <span class="token keyword"${_scopeId}>new</span> <span class="token class-name"${_scopeId}>Promise</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>resolve<span class="token punctuation"${_scopeId}>,</span> reject</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
    wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>request</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
      url<span class="token punctuation"${_scopeId}>,</span>
      data<span class="token punctuation"${_scopeId}>,</span>
      header<span class="token punctuation"${_scopeId}>,</span>
      method<span class="token punctuation"${_scopeId}>,</span>
      <span class="token literal-property property"${_scopeId}>timeout</span><span class="token operator"${_scopeId}>:</span> <span class="token number"${_scopeId}>0</span><span class="token punctuation"${_scopeId}>,</span>
      <span class="token function-variable function"${_scopeId}>success</span><span class="token operator"${_scopeId}>:</span> <span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>result</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
        <span class="token function"${_scopeId}>resolve</span><span class="token punctuation"${_scopeId}>(</span>result<span class="token punctuation"${_scopeId}>)</span>
      <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
      <span class="token function-variable function"${_scopeId}>fail</span><span class="token operator"${_scopeId}>:</span> <span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
        <span class="token function"${_scopeId}>reject</span><span class="token punctuation"${_scopeId}>(</span>res<span class="token punctuation"${_scopeId}>)</span>
      <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
    <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
  <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
<span class="token punctuation"${_scopeId}>}</span>
</code></pre><h2 id="\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548" tabindex="-1"${_scopeId}>\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548 <a class="anchor before" href="#\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><pre class="language-js"${_scopeId}><code class="language-js"${_scopeId}><span class="token comment"${_scopeId}>// \u9A8C\u8BC1\u767B\u5F55\u662F\u5426\u8FC7\u671F</span>
<span class="token keyword"${_scopeId}>function</span> <span class="token function"${_scopeId}>checksession</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
  wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>checkSession</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
    <span class="token function"${_scopeId}>success</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
      console<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>log</span><span class="token punctuation"${_scopeId}>(</span><span class="token string"${_scopeId}>&#39;\u767B\u5F55\u672A\u8FC7\u671F&#39;</span><span class="token punctuation"${_scopeId}>)</span>
    <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
    <span class="token function"${_scopeId}>fail</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
      console<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>log</span><span class="token punctuation"${_scopeId}>(</span><span class="token string"${_scopeId}>&#39;\u767B\u5F55\u8FC7\u671F&#39;</span><span class="token punctuation"${_scopeId}>)</span>
      wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>showModal</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
        <span class="token literal-property property"${_scopeId}>title</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;\u63D0\u793A&#39;</span><span class="token punctuation"${_scopeId}>,</span>
        <span class="token literal-property property"${_scopeId}>content</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;\u4F60\u7684\u767B\u5F55\u4FE1\u606F\u8FC7\u671F\u4E86\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55&#39;</span><span class="token punctuation"${_scopeId}>,</span>
      <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
      <span class="token comment"${_scopeId}>// \u518D\u6B21\u8C03\u7528wxLogin()</span>
      <span class="token function"${_scopeId}>wxLogin</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span><span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>then</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token operator"${_scopeId}>=&gt;</span> <span class="token punctuation"${_scopeId}>{</span>
        <span class="token comment"${_scopeId}>// \u767B\u5F55\u6210\u529F\u5B58\u50A8\u7528\u6237\u4FE1\u606F</span>
        <span class="token function"${_scopeId}>getUserInfo</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span>
      <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
    <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
  <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
<span class="token punctuation"${_scopeId}>}</span>

<span class="token comment"${_scopeId}>// \u83B7\u53D6\u7528\u6237\u7684\u4FE1\u606F</span>
<span class="token keyword"${_scopeId}>function</span> <span class="token function"${_scopeId}>getUserInfo</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
  wx<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>getUserInfo</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
    <span class="token function"${_scopeId}>success</span><span class="token punctuation"${_scopeId}>(</span><span class="token parameter"${_scopeId}>res</span><span class="token punctuation"${_scopeId}>)</span> <span class="token punctuation"${_scopeId}>{</span>
      console<span class="token punctuation"${_scopeId}>.</span><span class="token function"${_scopeId}>log</span><span class="token punctuation"${_scopeId}>(</span>res<span class="token punctuation"${_scopeId}>.</span>userInfo<span class="token punctuation"${_scopeId}>)</span>
      <span class="token function"${_scopeId}>getApp</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span><span class="token punctuation"${_scopeId}>.</span>globalData<span class="token punctuation"${_scopeId}>.</span>city <span class="token operator"${_scopeId}>=</span> res<span class="token punctuation"${_scopeId}>.</span>userInfo<span class="token punctuation"${_scopeId}>.</span>city
      <span class="token function"${_scopeId}>getApp</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span><span class="token punctuation"${_scopeId}>.</span>globalData<span class="token punctuation"${_scopeId}>.</span>country <span class="token operator"${_scopeId}>=</span> res<span class="token punctuation"${_scopeId}>.</span>userInfo<span class="token punctuation"${_scopeId}>.</span>country
      <span class="token function"${_scopeId}>getApp</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span><span class="token punctuation"${_scopeId}>.</span>globalData<span class="token punctuation"${_scopeId}>.</span>nickName <span class="token operator"${_scopeId}>=</span> res<span class="token punctuation"${_scopeId}>.</span>userInfo<span class="token punctuation"${_scopeId}>.</span>nickName
      <span class="token function"${_scopeId}>getApp</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>)</span><span class="token punctuation"${_scopeId}>.</span>globalData<span class="token punctuation"${_scopeId}>.</span>province <span class="token operator"${_scopeId}>=</span> res<span class="token punctuation"${_scopeId}>.</span>userInfo<span class="token punctuation"${_scopeId}>.</span>province
    <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>,</span>
  <span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
<span class="token punctuation"${_scopeId}>}</span>
</code></pre></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("h1", {
                  id: "\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406 "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u6574\u7406",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "\u6D41\u7A0B\u56FE",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u6D41\u7A0B\u56FE "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u6D41\u7A0B\u56FE",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, "![\u6D41\u7A0B\u56FE.jpg][/post/images/xcx-login.png]"),
                vue_cjs_prod.createVNode("h2", {
                  id: "\u4EE3\u7801\u793A\u4F8B",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u4EE3\u7801\u793A\u4F8B "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u4EE3\u7801\u793A\u4F8B",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("pre", { class: "language-js" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-js" }, [
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "function"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "wxLogin"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u8C03\u7528wx.login"),
                    vue_cjs_prod.createTextVNode("\n  wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "login"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token function-variable function" }, "success"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u83B7\u53D6\u5230code"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "const"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token constant" }, "CODE"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(" res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("code\n      wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "showToast"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "title"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u6570\u636E\u52A0\u8F7D\u4E2D'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "icon"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'loading'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u4F7F\u7528code\u548C\u540E\u7AEF\u6362\u53D6openid\uFF0CsessionKey"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "request"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u540E\u7AEF\u63D0\u4F9B\u7684\u63A5\u53E3'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'POST'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "code"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token constant" }, "CODE"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token string-property property" }, "'content-type'"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'application/json'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "then"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n          wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "hideToast"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "if"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("data"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("InfoState "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "==="),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token number" }, "0"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n            "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getUserInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("then\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u6210\u529F\u540E\u7684\u5904\u7406"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("catch\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u5931\u8D25\u540E\u7684\u5904\u7406"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "catch"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "result"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u8BF7\u6C42\u5931\u8D25\u91CD\u65B0\u5904\u7406"),
                    vue_cjs_prod.createTextVNode("\n          wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "showModal"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n            "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "title"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u63D0\u793A'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n            "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "content"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u8BF7\u6C42\u5931\u8D25'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n            "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "confirmText"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u91CD\u65B0\u8BF7\u6C42'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n            "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "success"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "if"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("confirm"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n                "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "request"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("\n                  "),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u540E\u7AEF\u63D0\u4F9B\u7684\u63A5\u53E3'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n                  "),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'POST'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n                  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n                    "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "code"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token constant" }, "CODE"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n                  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n                  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n                    "),
                    vue_cjs_prod.createVNode("span", { class: "token string-property property" }, "'content-type'"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'application/json'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n                  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n                "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "else"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "if"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("cancel"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n                console"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "log"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u7528\u6237\u70B9\u51FB\u53D6\u6D88'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n              "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n            "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n          "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n\n"),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u5224\u65AD\u7528\u6237\u662F\u5426\u6388\u6743"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "function"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getUserInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "return"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "new"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token class-name" }, "Promise"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, [
                      vue_cjs_prod.createTextVNode("resolve"),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                      vue_cjs_prod.createTextVNode(" reject")
                    ]),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n    wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getUserInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "success"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "resolve"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "fail"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// eslint-disable-next-line prefer-promise-reject-errors"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "reject"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u6211\u8FD8\u6CA1\u6709\u6388\u6743'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n\n"),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u5C01\u88C5\u8BF7\u6C42"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "function"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "request"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, [
                      vue_cjs_prod.createTextVNode("url"),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                      vue_cjs_prod.createTextVNode(" method"),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                      vue_cjs_prod.createTextVNode(" data"),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                      vue_cjs_prod.createTextVNode(" header")
                    ]),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "return"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "new"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token class-name" }, "Promise"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, [
                      vue_cjs_prod.createTextVNode("resolve"),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                      vue_cjs_prod.createTextVNode(" reject")
                    ]),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n    wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "request"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n      url"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      data"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      header"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      method"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "timeout"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token number" }, "0"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function-variable function" }, "success"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "result"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "resolve"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("result"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function-variable function" }, "fail"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "reject"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ]),
                vue_cjs_prod.createVNode("h2", {
                  id: "\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548 "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#\u66F4\u65B0\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("pre", { class: "language-js" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-js" }, [
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u9A8C\u8BC1\u767B\u5F55\u662F\u5426\u8FC7\u671F"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "function"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "checksession"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "checkSession"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "success"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n      console"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "log"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u767B\u5F55\u672A\u8FC7\u671F'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "fail"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n      console"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "log"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u767B\u5F55\u8FC7\u671F'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "showModal"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "title"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u63D0\u793A'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "content"),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token string" }, "'\u4F60\u7684\u767B\u5F55\u4FE1\u606F\u8FC7\u671F\u4E86\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55'"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u518D\u6B21\u8C03\u7528wxLogin()"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "wxLogin"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "then"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "=>"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u767B\u5F55\u6210\u529F\u5B58\u50A8\u7528\u6237\u4FE1\u606F"),
                    vue_cjs_prod.createTextVNode("\n        "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getUserInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n\n"),
                    vue_cjs_prod.createVNode("span", { class: "token comment" }, "// \u83B7\u53D6\u7528\u6237\u7684\u4FE1\u606F"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token keyword" }, "function"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getUserInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n  wx"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getUserInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "success"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token parameter" }, "res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode(),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                    vue_cjs_prod.createTextVNode("\n      console"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "log"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createTextVNode("res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("userInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getApp"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("globalData"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("city "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(" res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("userInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("city\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getApp"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("globalData"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("country "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(" res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("userInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("country\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getApp"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("globalData"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("nickName "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(" res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("userInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("nickName\n      "),
                    vue_cjs_prod.createVNode("span", { class: "token function" }, "getApp"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("globalData"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("province "),
                    vue_cjs_prod.createVNode("span", { class: "token operator" }, "="),
                    vue_cjs_prod.createTextVNode(" res"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("userInfo"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "."),
                    vue_cjs_prod.createTextVNode("province\n    "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                    vue_cjs_prod.createTextVNode("\n  "),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                    vue_cjs_prod.createTextVNode("\n"),
                    vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/\u5C0F\u7A0B\u5E8F\u767B\u5F55\u6D41\u7A0B\u4E0E\u5224\u65AD\u767B\u5F55\u4FE1\u606F\u5931\u6548.md");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const ________________ = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter: frontmatter$1,
  "default": _sfc_main$3
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$2 = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { config } = useConfig();
    const { data } = ([__temp, __restore] = vue_cjs_prod.withAsyncContext(() => useFetch(`https://api.github.com/users/${config.value.github.split("/")[3]}/repos`)), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<article${serverRenderer.exports.ssrRenderAttrs(_attrs)}><header><div class="container"><h1>Projects</h1><p class="description"> A few highlights of my open-source projects. View them all <a${serverRenderer.exports.ssrRenderAttr("href", vue_cjs_prod.unref(config).github)}>on GitHub</a>. </p></div></header><section class="projects large container"><!--[-->`);
      serverRenderer.exports.ssrRenderList(vue_cjs_prod.unref(projectsList), (project) => {
        var _a2;
        _push(`<div class="project"><h2>${serverRenderer.exports.ssrInterpolate(project.name)}</h2>`);
        if (project.image) {
          _push(`<img${serverRenderer.exports.ssrRenderAttr("src", project.image)}${serverRenderer.exports.ssrRenderAttr("alt", project.name)}>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="links tags">`);
        if (project.writeup) {
          _push(serverRenderer.exports.ssrRenderComponent(_component_NuxtLink, {
            to: project.writeup
          }, {
            default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Write-up `);
              } else {
                return [
                  vue_cjs_prod.createTextVNode(" Write-up ")
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<a${serverRenderer.exports.ssrRenderAttr("href", `https://github.com/taniarascia/${project.repoName}`)} target="_blank" rel="noreferrer"> Source </a>`);
        if (project.url) {
          _push(`<a href="{project.url}" target="_blank" rel="noreferrer"> Demo </a>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><p class="description">${serverRenderer.exports.ssrInterpolate(project.tagline)}</p><div class="stars"><img${serverRenderer.exports.ssrRenderAttr("src", _imports_0$2)} alt="Stargazers"><span>`);
        if (vue_cjs_prod.unref(data).length > 0) {
          _push(`<a${serverRenderer.exports.ssrRenderAttr("href", `https://github.com/taniarascia/${project.repoName}/stargazers`)}>${serverRenderer.exports.ssrInterpolate(Number(((_a2 = vue_cjs_prod.unref(data).find((repo) => repo.name === project.name)) == null ? void 0 : _a2.stargazers_count) || 0).toLocaleString())}</a>`);
        } else {
          _push(`<!---->`);
        }
        _push(` stars on GitHub </span><span></span></div></div>`);
      });
      _push(`<!--]--></section></article>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/projects.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const projects = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main$2
}, Symbol.toStringTag, { value: "Module" }));
const frontmatter = { "meta": [] };
const _sfc_main$1 = {
  __ssrInlineRender: true,
  setup(__props, { expose }) {
    const head = { "meta": [] };
    useHead(head);
    expose({ frontmatter: { "meta": [] } });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_post = vue_cjs_prod.resolveComponent("post");
      _push(serverRenderer.exports.ssrRenderComponent(_component_post, vue_cjs_prod.mergeProps({ frontmatter }, _attrs), {
        default: vue_cjs_prod.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="container post-content"${_scopeId}><h2 id="layouts" tabindex="-1"${_scopeId}>Layouts <a class="anchor before" href="#layouts" aria-hidden="true"${_scopeId}><svg aria-hidden="true" focusable="false" height="16" version="1.1" viewBox="0 0 16 16" width="16"${_scopeId}><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"${_scopeId}></path></svg></a></h2><p${_scopeId}>Vue components in this dir are used as layouts.</p><p${_scopeId}>By default, <code class="language-text"${_scopeId}>default.vue</code> will be used unless an alternative is specified in the route meta.</p><pre class="language-html"${_scopeId}><code class="language-html"${_scopeId}><span class="token tag"${_scopeId}><span class="token tag"${_scopeId}><span class="token punctuation"${_scopeId}>&lt;</span>script</span> <span class="token attr-name"${_scopeId}>setup</span> <span class="token attr-name"${_scopeId}>lang</span><span class="token attr-value"${_scopeId}><span class="token punctuation attr-equals"${_scopeId}>=</span><span class="token punctuation"${_scopeId}>&quot;</span>ts<span class="token punctuation"${_scopeId}>&quot;</span></span><span class="token punctuation"${_scopeId}>&gt;</span></span><span class="token script"${_scopeId}><span class="token language-javascript"${_scopeId}>
<span class="token function"${_scopeId}>definePageMeta</span><span class="token punctuation"${_scopeId}>(</span><span class="token punctuation"${_scopeId}>{</span>
  <span class="token literal-property property"${_scopeId}>layout</span><span class="token operator"${_scopeId}>:</span> <span class="token string"${_scopeId}>&#39;home&#39;</span><span class="token punctuation"${_scopeId}>,</span>
<span class="token punctuation"${_scopeId}>}</span><span class="token punctuation"${_scopeId}>)</span>
</span></span><span class="token tag"${_scopeId}><span class="token tag"${_scopeId}><span class="token punctuation"${_scopeId}>&lt;/</span>script</span><span class="token punctuation"${_scopeId}>&gt;</span></span>
</code></pre><p${_scopeId}>Learn more on <a href="https://v3.nuxtjs.org/guide/directory-structure/layouts" target="_blank" rel="noopener"${_scopeId}>https://v3.nuxtjs.org/guide/directory-structure/layouts</a></p></div>`);
          } else {
            return [
              vue_cjs_prod.createVNode("div", { class: "container post-content" }, [
                vue_cjs_prod.createVNode("h2", {
                  id: "layouts",
                  tabindex: "-1"
                }, [
                  vue_cjs_prod.createTextVNode("Layouts "),
                  vue_cjs_prod.createVNode("a", {
                    class: "anchor before",
                    href: "#layouts",
                    "aria-hidden": "true"
                  }, [
                    (vue_cjs_prod.openBlock(), vue_cjs_prod.createBlock("svg", {
                      "aria-hidden": "true",
                      focusable: "false",
                      height: "16",
                      version: "1.1",
                      viewBox: "0 0 16 16",
                      width: "16"
                    }, [
                      vue_cjs_prod.createVNode("path", {
                        "fill-rule": "evenodd",
                        d: "M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"
                      })
                    ]))
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, "Vue components in this dir are used as layouts."),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createTextVNode("By default, "),
                  vue_cjs_prod.createVNode("code", { class: "language-text" }, "default.vue"),
                  vue_cjs_prod.createTextVNode(" will be used unless an alternative is specified in the route meta.")
                ]),
                vue_cjs_prod.createVNode("pre", { class: "language-html" }, [
                  vue_cjs_prod.createVNode("code", { class: "language-html" }, [
                    vue_cjs_prod.createVNode("span", { class: "token tag" }, [
                      vue_cjs_prod.createVNode("span", { class: "token tag" }, [
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "<"),
                        vue_cjs_prod.createTextVNode("script")
                      ]),
                      vue_cjs_prod.createTextVNode(),
                      vue_cjs_prod.createVNode("span", { class: "token attr-name" }, "setup"),
                      vue_cjs_prod.createTextVNode(),
                      vue_cjs_prod.createVNode("span", { class: "token attr-name" }, "lang"),
                      vue_cjs_prod.createVNode("span", { class: "token attr-value" }, [
                        vue_cjs_prod.createVNode("span", { class: "token punctuation attr-equals" }, "="),
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, '"'),
                        vue_cjs_prod.createTextVNode("ts"),
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, '"')
                      ]),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ">")
                    ]),
                    vue_cjs_prod.createVNode("span", { class: "token script" }, [
                      vue_cjs_prod.createVNode("span", { class: "token language-javascript" }, [
                        vue_cjs_prod.createTextVNode("\n"),
                        vue_cjs_prod.createVNode("span", { class: "token function" }, "definePageMeta"),
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "("),
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "{"),
                        vue_cjs_prod.createTextVNode("\n  "),
                        vue_cjs_prod.createVNode("span", { class: "token literal-property property" }, "layout"),
                        vue_cjs_prod.createVNode("span", { class: "token operator" }, ":"),
                        vue_cjs_prod.createTextVNode(),
                        vue_cjs_prod.createVNode("span", { class: "token string" }, "'home'"),
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ","),
                        vue_cjs_prod.createTextVNode("\n"),
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "}"),
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ")"),
                        vue_cjs_prod.createTextVNode("\n")
                      ])
                    ]),
                    vue_cjs_prod.createVNode("span", { class: "token tag" }, [
                      vue_cjs_prod.createVNode("span", { class: "token tag" }, [
                        vue_cjs_prod.createVNode("span", { class: "token punctuation" }, "</"),
                        vue_cjs_prod.createTextVNode("script")
                      ]),
                      vue_cjs_prod.createVNode("span", { class: "token punctuation" }, ">")
                    ]),
                    vue_cjs_prod.createTextVNode("\n")
                  ])
                ]),
                vue_cjs_prod.createVNode("p", null, [
                  vue_cjs_prod.createTextVNode("Learn more on "),
                  vue_cjs_prod.createVNode("a", {
                    href: "https://v3.nuxtjs.org/guide/directory-structure/layouts",
                    target: "_blank",
                    rel: "noopener"
                  }, "https://v3.nuxtjs.org/guide/directory-structure/layouts")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/README.md");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const README = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  frontmatter,
  "default": _sfc_main$1
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main = /* @__PURE__ */ vue_cjs_prod.defineComponent({
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const content = vue_cjs_prod.ref();
    vue_cjs_prod.onMounted(() => {
      const navigate = () => {
        var _a2;
        if (location.hash) {
          (_a2 = document.querySelector(decodeURIComponent(location.hash))) == null ? void 0 : _a2.scrollIntoView({ behavior: "smooth" });
        }
      };
      const handleAnchors = (event) => {
        const link = event.target.closest("a");
        if (!event.defaultPrevented && link && event.button === 0 && link.target !== "_blank" && link.rel !== "external" && !link.download && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) {
          const url = new URL(link.href);
          if (url.origin !== window.location.origin)
            return;
          event.preventDefault();
          const { pathname, hash: hash2 } = url;
          if (hash2 && (!pathname || pathname === location.pathname)) {
            window.history.replaceState({}, "", hash2);
            navigate();
          } else {
            router.push({ path: pathname, hash: hash2 });
          }
        }
      };
      useEventListener(window, "hashchange", navigate);
      useEventListener(content.value, "click", handleAnchors, { passive: false });
      navigate();
      setTimeout(navigate, 500);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = _sfc_main$f;
      const _component_Footer = _sfc_main$h;
      _push(`<div${serverRenderer.exports.ssrRenderAttrs(_attrs)}>`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_Header, null, null, _parent));
      _push(`<main><div container mx-auto>`);
      serverRenderer.exports.ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></main>`);
      _push(serverRenderer.exports.ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vue_cjs_prod.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  "default": _sfc_main
}, Symbol.toStringTag, { value: "Module" }));

export { entry$1 as default };
//# sourceMappingURL=server.mjs.map
