globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'http';
import { Server } from 'https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, createError, createApp, createRouter, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ohmyfetch';
import { createRouter as createRouter$1 } from 'radix3';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import { hash } from 'ohash';
import { createStorage } from 'unstorage';
import { withQuery, withLeadingSlash, withoutTrailingSlash, parseURL } from 'ufo';
import { promises } from 'fs';
import { resolve, dirname } from 'pathe';
import { fileURLToPath } from 'url';

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"routes":{},"envPrefix":"NUXT_"},"public":{}};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const getEnv = (key) => {
  const envKey = snakeCase(key).toUpperCase();
  return destr(process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]);
};
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
overrideConfig(_runtimeConfig);
const config = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => config;
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const globalTiming = globalThis.__timing__ || {
  start: () => 0,
  end: () => 0,
  metrics: []
};
function timingMiddleware(_req, res, next) {
  const start = globalTiming.start();
  const _end = res.end;
  res.end = (data, encoding, callback) => {
    const metrics = [["Generate", globalTiming.end(start)], ...globalTiming.metrics];
    const serverTiming = metrics.map((m) => `-;dur=${m[1]};desc="${encodeURIComponent(m[0])}"`).join(", ");
    if (!res.headersSent) {
      res.setHeader("Server-Timing", serverTiming);
    }
    _end.call(res, data, encoding, callback);
  };
  next();
}

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

const useStorage = () => storage;

storage.mount('/assets', assets$1);

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  async function get(key, resolver) {
    const cacheKey = [opts.base, group, name, key].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl;
    const _resolve = async () => {
      if (!pending[key]) {
        pending[key] = Promise.resolve(resolver());
      }
      entry.value = await pending[key];
      entry.mtime = Date.now();
      entry.integrity = integrity;
      delete pending[key];
      useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return Promise.resolve(entry);
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const key = (opts.getKey || getKey)(...args);
    const entry = await get(key, () => fn(...args));
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length ? hash(args, {}) : "";
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: (event) => {
      return event.req.originalUrl || event.req.url;
    },
    group: opts.group || "nitro/handlers",
    integrity: [
      opts.integrity,
      handler
    ]
  };
  const _cachedHandler = cachedFunction(async (incomingEvent) => {
    const reqProxy = cloneWithProxy(incomingEvent.req, { headers: {} });
    const resHeaders = {};
    const resProxy = cloneWithProxy(incomingEvent.res, {
      statusCode: 200,
      getHeader(name) {
        return resHeaders[name];
      },
      setHeader(name, value) {
        resHeaders[name] = value;
        return this;
      },
      getHeaderNames() {
        return Object.keys(resHeaders);
      },
      hasHeader(name) {
        return name in resHeaders;
      },
      removeHeader(name) {
        delete resHeaders[name];
      },
      getHeaders() {
        return resHeaders;
      }
    });
    const event = createEvent(reqProxy, resProxy);
    event.context = incomingEvent.context;
    const body = await handler(event);
    const headers = event.res.getHeaders();
    headers.Etag = `W/"${hash(body)}"`;
    headers["Last-Modified"] = new Date().toUTCString();
    const cacheControl = [];
    if (opts.swr) {
      if (opts.maxAge) {
        cacheControl.push(`s-maxage=${opts.maxAge}`);
      }
      if (opts.staleMaxAge) {
        cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
      } else {
        cacheControl.push("stale-while-revalidate");
      }
    } else if (opts.maxAge) {
      cacheControl.push(`max-age=${opts.maxAge}`);
    }
    if (cacheControl.length) {
      headers["Cache-Control"] = cacheControl.join(", ");
    }
    const cacheEntry = {
      code: event.res.statusCode,
      headers,
      body
    };
    return cacheEntry;
  }, _opts);
  return defineEventHandler(async (event) => {
    const response = await _cachedHandler(event);
    if (event.res.headersSent || event.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["Last-Modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.res.statusCode = response.code;
    for (const name in response.headers) {
      event.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const plugins = [
  
];

function hasReqHeader(req, header, includes) {
  const value = req.headers[header];
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event.req, "accept", "application/json") || hasReqHeader(event.req, "user-agent", "curl/") || hasReqHeader(event.req, "user-agent", "httpie/") || event.req.url?.endsWith(".json") || event.req.url?.includes("/api/");
}
function normalizeError(error) {
  const cwd = process.cwd();
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Route Not Found" : "Internal Server Error");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(_error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(_error);
  const errorObject = {
    url: event.req.url,
    statusCode,
    statusMessage,
    message,
    description: "",
    data: _error.data
  };
  event.res.statusCode = errorObject.statusCode;
  event.res.statusMessage = errorObject.statusMessage;
  if (errorObject.statusCode !== 404) {
    console.error("[nuxt] [request error]", errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    event.res.setHeader("Content-Type", "application/json");
    event.res.end(JSON.stringify(errorObject));
    return;
  }
  const url = withQuery("/__nuxt_error", errorObject);
  const html = await $fetch(url).catch((error) => {
    console.error("[nitro] Error while generating error response", error);
    return errorObject.statusMessage;
  });
  event.res.setHeader("Content-Type", "text/html;charset=UTF-8");
  event.res.end(html);
});

const assets = {
  "/_nuxt/404-f937806d.mjs": {
    "type": "application/javascript",
    "etag": "\"1b5-JOd5OdoLODW1KUXdZdmdXQVWGEE\"",
    "mtime": "2022-05-15T13:47:27.927Z",
    "path": "../public/_nuxt/404-f937806d.mjs"
  },
  "/_nuxt/Footer-022a218e.mjs": {
    "type": "application/javascript",
    "etag": "\"51f-Lwt5Sa7ADA61L419V3kfgeXy4iE\"",
    "mtime": "2022-05-15T13:47:27.926Z",
    "path": "../public/_nuxt/Footer-022a218e.mjs"
  },
  "/_nuxt/Header-e6136707.mjs": {
    "type": "application/javascript",
    "etag": "\"4fa-Aw6tKb/x7eC41EMm6b3u52VjkgE\"",
    "mtime": "2022-05-15T13:47:27.925Z",
    "path": "../public/_nuxt/Header-e6136707.mjs"
  },
  "/_nuxt/Introduce-26ea1d33.mjs": {
    "type": "application/javascript",
    "etag": "\"485f-dkOBbPgRmFH0bFHyf9Kg2Cc5Jkc\"",
    "mtime": "2022-05-15T13:47:27.923Z",
    "path": "../public/_nuxt/Introduce-26ea1d33.mjs"
  },
  "/_nuxt/JavaScript-监听截图-b55bc302.mjs": {
    "type": "application/javascript",
    "etag": "\"1a71-V6Evp4Lz6eQLXSZAtec7U7VgVks\"",
    "mtime": "2022-05-15T13:47:27.921Z",
    "path": "../public/_nuxt/JavaScript-监听截图-b55bc302.mjs"
  },
  "/_nuxt/New-Blog-a5bb647a.mjs": {
    "type": "application/javascript",
    "etag": "\"27dd-7Yp/M/HwtSvOsQ1msxluxBtXNsE\"",
    "mtime": "2022-05-15T13:47:27.920Z",
    "path": "../public/_nuxt/New-Blog-a5bb647a.mjs"
  },
  "/_nuxt/Post-ba8620d1.mjs": {
    "type": "application/javascript",
    "etag": "\"689-0GQT45R14kEJeqRUd8fMseEd9ug\"",
    "mtime": "2022-05-15T13:47:27.919Z",
    "path": "../public/_nuxt/Post-ba8620d1.mjs"
  },
  "/_nuxt/Posts-36de7baf.mjs": {
    "type": "application/javascript",
    "etag": "\"759-/2PMr9HvIl498oK/xnpaQmloITk\"",
    "mtime": "2022-05-15T13:47:27.918Z",
    "path": "../public/_nuxt/Posts-36de7baf.mjs"
  },
  "/_nuxt/README-8a710be8.mjs": {
    "type": "application/javascript",
    "etag": "\"acb-tAU6zQTt08EhN64cH4XBAjWMke4\"",
    "mtime": "2022-05-15T13:47:27.917Z",
    "path": "../public/_nuxt/README-8a710be8.mjs"
  },
  "/_nuxt/Search-fde8b616.mjs": {
    "type": "application/javascript",
    "etag": "\"3ce-dFo0Wpc/5qCvQ7JvSd3H7ckHgNk\"",
    "mtime": "2022-05-15T13:47:27.916Z",
    "path": "../public/_nuxt/Search-fde8b616.mjs"
  },
  "/_nuxt/ToggleTheme-0058d7b3.mjs": {
    "type": "application/javascript",
    "etag": "\"22f-56eev7fVZ4Vw61aQuPgM/pbKHBY\"",
    "mtime": "2022-05-15T13:47:27.915Z",
    "path": "../public/_nuxt/ToggleTheme-0058d7b3.mjs"
  },
  "/_nuxt/UnoIcon-ce990b35.mjs": {
    "type": "application/javascript",
    "etag": "\"96-SqVT6rojvoHe0GsY1PzpiwdFgPc\"",
    "mtime": "2022-05-15T13:47:27.913Z",
    "path": "../public/_nuxt/UnoIcon-ce990b35.mjs"
  },
  "/_nuxt/Vue-Class的显示-662485b8.mjs": {
    "type": "application/javascript",
    "etag": "\"7bc-ZnMNJ75IZbQzjV1V01Gr+KzpK7g\"",
    "mtime": "2022-05-15T13:47:27.910Z",
    "path": "../public/_nuxt/Vue-Class的显示-662485b8.mjs"
  },
  "/_nuxt/about-d793e699.mjs": {
    "type": "application/javascript",
    "etag": "\"1c7a-NleJbyyq833oqsPj+VCWSDTX2zc\"",
    "mtime": "2022-05-15T13:47:27.907Z",
    "path": "../public/_nuxt/about-d793e699.mjs"
  },
  "/_nuxt/articles-3d53325a.mjs": {
    "type": "application/javascript",
    "etag": "\"76a-km++2YGfvQyQtlVn+HquO2xdYFs\"",
    "mtime": "2022-05-15T13:47:27.903Z",
    "path": "../public/_nuxt/articles-3d53325a.mjs"
  },
  "/_nuxt/date-42f38aba.mjs": {
    "type": "application/javascript",
    "etag": "\"130-bVrnwXxATqXVfne+pCSxiBa6HP4\"",
    "mtime": "2022-05-15T13:47:27.901Z",
    "path": "../public/_nuxt/date-42f38aba.mjs"
  },
  "/_nuxt/default-325a9743.mjs": {
    "type": "application/javascript",
    "etag": "\"4f2-LaSiBY/uR83ODPZ+E5AIzoK+YNw\"",
    "mtime": "2022-05-15T13:47:27.899Z",
    "path": "../public/_nuxt/default-325a9743.mjs"
  },
  "/_nuxt/entry-44957252.mjs": {
    "type": "application/javascript",
    "etag": "\"25bcb-OPcKX5vR67vT8kXq8hCf6KYyPEo\"",
    "mtime": "2022-05-15T13:47:27.897Z",
    "path": "../public/_nuxt/entry-44957252.mjs"
  },
  "/_nuxt/entry.ab6b0efa.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"11aaa-GySyLZ1k8jXLiyS2klLhT69tzok\"",
    "mtime": "2022-05-15T13:47:27.891Z",
    "path": "../public/_nuxt/entry.ab6b0efa.css"
  },
  "/_nuxt/fetch-66960b4e.mjs": {
    "type": "application/javascript",
    "etag": "\"1ea9-xo1thBjGu3+A52TW75Dv6bDQD2o\"",
    "mtime": "2022-05-15T13:47:27.887Z",
    "path": "../public/_nuxt/fetch-66960b4e.mjs"
  },
  "/_nuxt/index-11903976.mjs": {
    "type": "application/javascript",
    "etag": "\"f56-edr9QdPnMACix4s3z7es9dsdEhk\"",
    "mtime": "2022-05-15T13:47:27.882Z",
    "path": "../public/_nuxt/index-11903976.mjs"
  },
  "/_nuxt/index-15be988b.mjs": {
    "type": "application/javascript",
    "etag": "\"14e-TKyGfVjiUrElSA0mjGRZR1QdXfw\"",
    "mtime": "2022-05-15T13:47:27.880Z",
    "path": "../public/_nuxt/index-15be988b.mjs"
  },
  "/_nuxt/manifest.json": {
    "type": "application/json",
    "etag": "\"1d50-dNHgecpOnTgg/2Q9D4qDBbaDcZw\"",
    "mtime": "2022-05-15T13:47:27.878Z",
    "path": "../public/_nuxt/manifest.json"
  },
  "/_nuxt/projects-9c9b7cca.mjs": {
    "type": "application/javascript",
    "etag": "\"842-ptxCYZnhyD6Fd4nVUS73vKoRCTY\"",
    "mtime": "2022-05-15T13:47:27.873Z",
    "path": "../public/_nuxt/projects-9c9b7cca.mjs"
  },
  "/_nuxt/px自动转换成rem-56dad86f.mjs": {
    "type": "application/javascript",
    "etag": "\"e2f-TQ0LQHyI+/OH8zByMGb4LiHAMqA\"",
    "mtime": "2022-05-15T13:47:27.870Z",
    "path": "../public/_nuxt/px自动转换成rem-56dad86f.mjs"
  },
  "/_nuxt/test-73476286.mjs": {
    "type": "application/javascript",
    "etag": "\"1f8e-JAg6Jg7LE+vaePI/9ms7ldeokpA\"",
    "mtime": "2022-05-15T13:47:27.866Z",
    "path": "../public/_nuxt/test-73476286.mjs"
  },
  "/_nuxt/小程序登录流程与判断登录信息失效-ac094bda.mjs": {
    "type": "application/javascript",
    "etag": "\"63b8-gw+eQ/18bViNFg5NUhlIYhWq55E\"",
    "mtime": "2022-05-15T13:47:27.863Z",
    "path": "../public/_nuxt/小程序登录流程与判断登录信息失效-ac094bda.mjs"
  },
  "/images/graphql.png": {
    "type": "image/png",
    "etag": "\"5ca-7JtZIBJkCN3Hf+ZB+wWCq85K7Kw\"",
    "mtime": "2022-05-15T13:47:28.010Z",
    "path": "../public/images/graphql.png"
  },
  "/images/logo.jpeg": {
    "type": "image/jpeg",
    "etag": "\"249ac1-m8gMWB7lpBxB2ycUxx6tN2K0MTc\"",
    "mtime": "2022-05-15T13:47:28.006Z",
    "path": "../public/images/logo.jpeg"
  },
  "/images/moon.png": {
    "type": "image/png",
    "etag": "\"1cf-WhhGMllHpd1rPkbzlknLwi5BAnU\"",
    "mtime": "2022-05-15T13:47:27.998Z",
    "path": "../public/images/moon.png"
  },
  "/images/nav-blog.png": {
    "type": "image/png",
    "etag": "\"297-5bx8VLKN8D5wK3bjZHnQr1yPkEs\"",
    "mtime": "2022-05-15T13:47:27.997Z",
    "path": "../public/images/nav-blog.png"
  },
  "/images/nav-dos.png": {
    "type": "image/png",
    "etag": "\"1bf-arQzPH+S2mAE5N5R0AwdwipqYwo\"",
    "mtime": "2022-05-15T13:47:27.996Z",
    "path": "../public/images/nav-dos.png"
  },
  "/images/nav-floppy.png": {
    "type": "image/png",
    "etag": "\"1f9-BRGuqBRIoiVc/IrR6x1onZFlAmk\"",
    "mtime": "2022-05-15T13:47:27.995Z",
    "path": "../public/images/nav-floppy.png"
  },
  "/images/nav-github.png": {
    "type": "image/png",
    "etag": "\"297-VB6drQX7wOfDBoSSrvabgi1tC9Y\"",
    "mtime": "2022-05-15T13:47:27.990Z",
    "path": "../public/images/nav-github.png"
  },
  "/images/nav-search.png": {
    "type": "image/png",
    "etag": "\"245-5rSBwzovbvEo9jf42vPTj0NTaug\"",
    "mtime": "2022-05-15T13:47:27.989Z",
    "path": "../public/images/nav-search.png"
  },
  "/images/nav-twitter.png": {
    "type": "image/png",
    "etag": "\"24d-M6XpaPdULXfpRxLIi9+u74kJ6q0\"",
    "mtime": "2022-05-15T13:47:27.988Z",
    "path": "../public/images/nav-twitter.png"
  },
  "/images/nuxt.png": {
    "type": "image/png",
    "etag": "\"75a-M4iKDzAZbY/+Nm6a2r4T6YdKs4g\"",
    "mtime": "2022-05-15T13:47:27.987Z",
    "path": "../public/images/nuxt.png"
  },
  "/images/vite.png": {
    "type": "image/png",
    "etag": "\"1e05-nnbd6qdEZhIbAw/SmCEauQrW4PI\"",
    "mtime": "2022-05-15T13:47:27.982Z",
    "path": "../public/images/vite.png"
  },
  "/images/vue.png": {
    "type": "image/png",
    "etag": "\"3a4-RxyOqLtgF1SyTvPOhSyxJZqUrBk\"",
    "mtime": "2022-05-15T13:47:27.980Z",
    "path": "../public/images/vue.png"
  },
  "/post/images/xcx-login.png": {
    "type": "image/png",
    "etag": "\"20cfe-DQY3o8IXGpsRtSIaHpny2Bdhktg\"",
    "mtime": "2022-05-15T13:47:27.974Z",
    "path": "../public/post/images/xcx-login.png"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = ["/_nuxt"];

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return
  }
  for (const base of publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = ["HEAD", "GET"];
const _152570 = eventHandler(async (event) => {
  if (event.req.method && !METHODS.includes(event.req.method)) {
    return;
  }
  let id = decodeURIComponent(withLeadingSlash(withoutTrailingSlash(parseURL(event.req.url).pathname)));
  let asset;
  for (const _id of [id, id + "/index.html"]) {
    const _asset = getAsset(_id);
    if (_asset) {
      asset = _asset;
      id = _id;
      break;
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.res.statusCode = 304;
    event.res.end("Not Modified (etag)");
    return;
  }
  const ifModifiedSinceH = event.req.headers["if-modified-since"];
  if (ifModifiedSinceH && asset.mtime) {
    if (new Date(ifModifiedSinceH) >= new Date(asset.mtime)) {
      event.res.statusCode = 304;
      event.res.end("Not Modified (mtime)");
      return;
    }
  }
  if (asset.type) {
    event.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag) {
    event.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime) {
    event.res.setHeader("Last-Modified", asset.mtime);
  }
  const contents = await readAsset(id);
  event.res.end(contents);
});

const _lazy_288600 = () => import('../pageview.mjs');
const _lazy_132137 = () => import('../handlers/renderer.mjs').then(function (n) { return n.a; });

const handlers = [
  { route: '', handler: _152570, lazy: false, middleware: true, method: undefined },
  { route: '/api/pageview', handler: _lazy_288600, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_132137, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_132137, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  h3App.use(config.app.baseURL, timingMiddleware);
  const router = createRouter();
  const routerOptions = createRouter$1({ routes: config.nitro.routes });
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    const referenceRoute = h.route.replace(/:\w+|\*\*/g, "_");
    const routeOptions = routerOptions.lookup(referenceRoute) || {};
    if (routeOptions.swr) {
      handler = cachedEventHandler(handler, {
        group: "nitro/routes"
      });
    }
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(/\/+/g, "/");
      h3App.use(middlewareBase, handler);
    } else {
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const localCall = createCall(h3App.nodeHandler);
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({ fetch: localFetch, Headers, defaults: { baseURL: config.app.baseURL } });
  globalThis.$fetch = $fetch;
  const app = {
    hooks,
    h3App,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, nitroApp.h3App.nodeHandler) : new Server$1(nitroApp.h3App.nodeHandler);
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const hostname = process.env.NITRO_HOST || process.env.HOST || "0.0.0.0";
server.listen(port, hostname, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  console.log(`Listening on ${protocol}://${hostname}:${port}${useRuntimeConfig().app.baseURL}`);
});
{
  process.on("unhandledRejection", (err) => console.error("[nitro] [dev] [unhandledRejection] " + err));
  process.on("uncaughtException", (err) => console.error("[nitro] [dev] [uncaughtException] " + err));
}
const nodeServer = {};

export { nodeServer as n, useRuntimeConfig as u };
//# sourceMappingURL=node-server.mjs.map
